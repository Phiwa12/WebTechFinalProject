<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Check database connection
if (!$db) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Debug session
error_log("Session data: " . print_r($_SESSION, true));


// Modify the auth check to include debugging
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    error_log("Authentication failed - user_id or role not set");
    error_log("Session data: " . print_r($_SESSION, true));
    header('Location: ../index.php');
    exit();
}

if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'super_admin') {
    error_log("Authentication failed - insufficient privileges: " . $_SESSION['role']);
    header('Location: ../index.php');
    exit();
}

$query = "SELECT 
    id, email, full_name, role, status, 
    DATE_FORMAT(last_login, '%Y-%m-%d %H:%i') as last_login,
    DATE_FORMAT(created_at, '%Y-%m-%d') as created_at
FROM style_users 
ORDER BY created_at DESC";

$result = mysqli_query($db, $query);
if (!$result) {
    die("Query failed: " . mysqli_error($db));
}

$users = mysqli_fetch_all($result, MYSQLI_ASSOC);
if ($users === false) {
    die("Failed to fetch users: " . mysqli_error($db));
}

// Calculate user statistics
$userStats = [
    'total' => 0,
    'active' => 0,
    'admin' => 0,
    'super_admin' => 0,
    'inactive' => 0
];

foreach ($users as $user) {
    $userStats['total']++;
    if ($user['status'] === 'active') $userStats['active']++;
    if ($user['status'] === 'inactive') $userStats['inactive']++;
    if ($user['role'] === 'admin') $userStats['admin']++;
    if ($user['role'] === 'super_admin') $userStats['super_admin']++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - StyleSense Admin</title>
    <?php
    $cssFiles = [
        '../assets/css/main.css',
        '../assets/css/admin_users.css',
        '../assets/css/admin_nav.css'
    ];
    foreach ($cssFiles as $css) {
        if (!file_exists($css)) {
            echo "<!-- Warning: CSS file not found: $css -->\n";
        }
    }
    ?>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/admin_users.css">
    <link rel="stylesheet" href="../assets/css/admin_nav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .btn-icon {
    cursor: pointer;
    padding: 8px;
    border: none;
    background: transparent;
    transition: opacity 0.3s;
}


.btn-icon:hover {
    opacity: 0.8;
}

.btn-icon.danger {
    color: #dc3545;
}

.edit-user-btn {
    color: #007bff;
}
    </style>
</head>
<body>
<?php include '../components/admin_nav.php'; ?>
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>User Management</h1>
            <div class="header-actions">
                <div class="search-box">
                    <input type="text" id="userSearch" placeholder="Search users...">
                    <i class="fas fa-search"></i>
                </div>
                <?php if ($_SESSION['role'] === 'super_admin'): ?>
                    <button class="btn primary" onclick="showAddUserModal()">
                        <i class="fas fa-plus"></i> Add User
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-details">
                    <h3>Total Users</h3>
                    <p><?php echo $userStats['total']; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-user-check"></i>
                </div>
                <div class="stat-details">
                    <h3>Active Users</h3>
                    <p><?php echo $userStats['active']; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="stat-details">
                    <h3>Admins</h3>
                    <p><?php echo $userStats['admin']; ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-user-times"></i>
                </div>
                <div class="stat-details">
                    <h3>Inactive Users</h3>
                    <p><?php echo $userStats['inactive']; ?></p>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th>Created</th>
                        <?php if ($_SESSION['role'] === 'super_admin'): ?>
                            <th>Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <span class="role-badge <?php echo $user['role']; ?>">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge <?php echo $user['status']; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td><?php echo $user['last_login'] ?? 'Never'; ?></td>
                            <td><?php echo $user['created_at']; ?></td>
                            <?php if ($_SESSION['role'] === 'super_admin'): ?>
                                <td>
    <button class="btn-icon edit-user-btn" data-userid="<?php echo $user['id']; ?>">
        <i class="fas fa-edit"></i>
    </button>
    <?php if ($user['id'] !== $_SESSION['user_id']): ?>
        <button class="btn-icon danger delete-user-btn" data-userid="<?php echo $user['id']; ?>">
            <i class="fas fa-trash"></i>
        </button>
    <?php endif; ?>
</td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Edit User</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <form id="userForm" onsubmit="return handleSubmit(event)">
                <input type="hidden" id="userId" name="id">
                
                <div class="form-group">
                    <label for="fullName">Full Name</label>
                    <input type="text" id="fullName" name="full_name" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="role">Role</label>
                    <select id="role" name="role" required>
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                        <option value="super_admin">Super Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password">
                    <small>Leave blank to keep current password when editing</small>
                </div>

                <div class="form-actions">
                    <button type="button" class="btn" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

   
<script>
// Define users globally
window.users = <?php echo json_encode($users); ?>;

// Error handling
try {
    if (!window.users) {
        console.error('No user data available');
    }
} catch (e) {
    console.error('Error loading user data:', e);
}

// Add error handling for script load 
window.addEventListener('error', function(e) {
    console.error('Script error:', e);
}, true);
</script>

<script src="../assets/js/admin_users.js" onerror="console.error('Failed to load admin_users.js')"></script>
</body>
</html>