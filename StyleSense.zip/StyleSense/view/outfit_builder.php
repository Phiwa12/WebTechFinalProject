<?php
session_start();
require_once '../db/config.php';

// Security checks
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// CSRF Protection
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function getWardrobeItems($db, $userId) {
    try {
        $sql = "SELECT * FROM style_wardrobe_items
                WHERE user_id = ? AND status = 'active'
                ORDER BY category, created_at DESC";
               
        $stmt = $db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Database prepare failed");
        }
       
        $stmt->bind_param('i', $userId);
        if (!$stmt->execute()) {
            throw new Exception("Database execute failed");
        }
       
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        error_log("Error in getWardrobeItems: " . $e->getMessage());
        return [];
    }
}

function getSavedOutfits($db, $userId) {
    try {
        $sql = "SELECT o.*, COUNT(oi.item_id) as item_count
                FROM style_outfits o
                LEFT JOIN style_outfit_items oi ON o.id = oi.outfit_id
                WHERE o.user_id = ?
                GROUP BY o.id
                ORDER BY o.created_at DESC";
               
        $stmt = $db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Database prepare failed");
        }
       
        $stmt->bind_param('i', $userId);
        if (!$stmt->execute()) {
            throw new Exception("Database execute failed");
        }
       
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        error_log("Error in getSavedOutfits: " . $e->getMessage());
        return [];
    }
}

// Get data with error handling
try {
    $wardrobeItems = getWardrobeItems($db, $_SESSION['user_id']);
    $savedOutfits = getSavedOutfits($db, $_SESSION['user_id']);

    // Organize items by category with validation
    $itemsByCategory = [];
    foreach ($wardrobeItems as $item) {
        $category = htmlspecialchars($item['category']);
        if (!isset($itemsByCategory[$category])) {
            $itemsByCategory[$category] = [];
        }
        // Sanitize item data
        $item = array_map('htmlspecialchars', $item);
        $itemsByCategory[$category][] = $item;
    }

    // Categories configuration
    $categories = [
        'tops' => ['name' => 'Tops', 'icon' => 'tshirt'],
        'bottoms' => ['name' => 'Bottoms', 'icon' => 'socks'],
        'dresses' => ['name' => 'Dresses', 'icon' => 'female'],
        'outerwear' => ['name' => 'Outerwear', 'icon' => 'vest'],
        'shoes' => ['name' => 'Shoes', 'icon' => 'shoe-prints'],
        'accessories' => ['name' => 'Accessories', 'icon' => 'gem']
    ];

    // Outfit types with validation
    $outfitTypes = [
        'casual' => 'Casual',
        'formal' => 'Formal',
        'business' => 'Business',
        'party' => 'Party'
    ];

} catch (Exception $e) {
    error_log("Error in outfit builder main: " . $e->getMessage());
    $error_message = "An error occurred while loading your wardrobe. Please try again later.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outfit Builder - StyleSense</title>
    <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; ?>">
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/outfit_builder.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .saved-outfits-section {
            margin-top: 2rem;
            padding: 2rem;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .saved-outfits-section .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .saved-outfits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            padding: 1rem 0;
        }

        .saved-outfit-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease;
        }

        .saved-outfit-card:hover {
            transform: translateY(-2px);
        }

        .outfit-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .outfit-header h3 {
            margin: 0;
            font-size: 1.1rem;
            color: #333;
        }

        .outfit-category {
            background-color: #e9ecef;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.9rem;
            color: #495057;
        }

        .outfit-details {
            margin-bottom: 1rem;
        }

        .outfit-description {
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }

        .outfit-date {
            color: #adb5bd;
            font-size: 0.8rem;
        }

        .outfit-items-count {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #6c757d;
            font-size: 0.9rem;
        }

        .outfit-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        .outfit-actions button {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .view-outfit {
            background-color: #FF69B4;
            color: white;
        }

        .delete-outfit {
            background-color: #dc3545;
            color: white;
        }

        .no-outfits-message {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
            grid-column: 1 / -1;
        }

        #viewOutfitModal .modal-content {
            max-width: 800px;
        }

        .outfit-preview {
            padding: 1.5rem;
        }

        .outfit-info {
            margin-bottom: 2rem;
            text-align: center;
        }

        .outfit-info h3 {
            margin: 0 0 0.5rem 0;
            color: #333;
        }

        .outfit-items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            padding: 1rem;
        }

        .saved-outfit-item {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 0.5rem;
            text-align: center;
        }

        .saved-outfit-item img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 0.5rem;
        }

        .saved-outfit-item .item-info {
            padding: 0.5rem;
        }

        .saved-outfit-item .item-name {
            display: block;
            font-weight: 500;
            margin-bottom: 0.25rem;
        }

        .saved-outfit-item .item-category {
            display: block;
            font-size: 0.9rem;
            color: #6c757d;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 4px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
        }

        .notification.success {
            background-color: #28a745;
            color: white;
        }

        .notification.error {
            background-color: #dc3545;
            color: white;
        }

        .notification.warning {
            background-color: #ffc107;
            color: #333;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .page-header h1 {
            color: #FF69B4;
        }

        .fas.fa-shopping-bag {
            color: #FF69B4;
        }

        .guide-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .guide-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            color: #2c3e50;
        }

        .guide-card h4 {
            color: #FF1493;
            margin: 10px 0;
            font-size: 18px;
        }

        .guide-card p {
            color: #555;
            line-height: 1.5;
            margin: 8px 0;
        }

        .guide-icon {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .analyze-btn {
            background-color: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
        }

        .latest-analysis {
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .analysis-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .measurements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }

        .new-analysis-btn {
            background: #FF1493;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .body-type-name {
            font-size: 24px;
            color: #FF1493;
            font-weight: bold;
            margin: 15px 0;
        }

        .save-result-btn {
            background: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .measurement-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .input-group input[type="number"],
        .input-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($error_message)): ?>
        <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <nav class="navbar">
        <div class="navbar-container">
            <div class="logo">StyleSense</div>
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="lni lni-menu"></i>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="../index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="body_analysis.php" class="active">Body Analysis</a>
                <a href="wardrobe.php">My Wardrobe</a>
                <a href="trends.php">Trends</a>
                <a href="outfit_builder.php">Outfit Builder</a>
                <a href="style_quiz.php">Style Quiz</a>
                <a href="color_palette.php">Color Palette</a>
                <a href="shop.php">Shop</a>
                <a href="community.php">Community</a>
            </div>
            <div class="user-menu" id="userMenu">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                <a href="../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>

    <main class="outfit-builder-page">
        <div class="page-header">
            <h1>Outfit Builder</h1>
            <p>Create and save your perfect outfits</p>
        </div>

        <div class="outfit-builder-container">
            <div class="wardrobe-section">
                <div class="section-header">
                    <h2>My Wardrobe</h2>
                    <a href="shop.php" class="shop-link">
                        <i class="fas fa-shopping-bag"></i> Shop More Items
                    </a>
                </div>

                <div class="category-tabs">
                    <?php foreach ($categories as $categoryId => $category): ?>
                        <button class="category-tab <?php echo $categoryId === 'tops' ? 'active' : ''; ?>"
                                data-category="<?php echo htmlspecialchars($categoryId); ?>">
                            <i class="fas fa-<?php echo htmlspecialchars($category['icon']); ?>"></i>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div class="items-container">
                    <?php foreach ($categories as $categoryId => $category): ?>
                        <div class="category-items" id="<?php echo htmlspecialchars($categoryId); ?>-items"
                             style="display: <?php echo $categoryId === 'tops' ? 'grid' : 'none'; ?>">
                            <?php if (empty($itemsByCategory[$categoryId])): ?>
                                <div class="no-items-message">
                                    <p>No <?php echo htmlspecialchars(strtolower($category['name'])); ?> in your wardrobe</p>
                                    <a href="shop.php?category=<?php echo urlencode($categoryId); ?>" class="btn">
                                        Shop <?php echo htmlspecialchars($category['name']); ?>
                                    </a>
                                </div>
                            <?php else: ?>
                                <?php foreach ($itemsByCategory[$categoryId] as $item): ?>
                                    <div class="wardrobe-item"
                                         draggable="true"
                                         data-item-id="<?php echo htmlspecialchars($item['id']); ?>"
                                         data-category="<?php echo htmlspecialchars($categoryId); ?>">
                                        <img src="<?php echo htmlspecialchars($item['image_url']); ?>"
                                             alt="<?php echo htmlspecialchars($item['name']); ?>">
                                        <div class="item-details">
                                            <span class="item-name"><?php echo htmlspecialchars($item['name']); ?></span>
                                            <span class="item-type"><?php echo htmlspecialchars($item['type']); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="outfit-canvas">
                <div class="canvas-header">
                    <h2>Create Your Outfit</h2>
                    <div class="canvas-actions">
                        <button id="saveOutfit" class="btn primary">
                            <i class="fas fa-save"></i> Save Outfit
                        </button>
                        <button id="clearOutfit" class="btn">
                            <i class="fas fa-trash"></i> Clear
                        </button>
                    </div>
                </div>
                <div class="outfit-grid">
                    <?php foreach ($categories as $categoryId => $category): ?>
                        <div class="grid-zone <?php echo htmlspecialchars($categoryId); ?>-zone">
                            <div class="zone-header">
                                <i class="fas fa-<?php echo htmlspecialchars($category['icon']); ?>"></i>
                                <span><?php echo htmlspecialchars($category['name']); ?></span>
                            </div>
                            <div class="zone-content" data-zone="<?php echo htmlspecialchars($categoryId); ?>">
                                <div class="zone-placeholder">Drop <?php echo htmlspecialchars(strtolower($category['name'])); ?> here</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="outfit-summary">
                    <div class="color-harmony">
                        <h3><i class="fas fa-palette"></i> Color Harmony</h3>
                        <div class="color-preview"></div>
                    </div>
                    <div class="missing-items">
                        <h3><i class="fas fa-exclamation-circle"></i> Missing Items</h3>
                        <div class="missing-items-list"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="saved-outfits-section">
            <div class="section-header">
                <h2>My Saved Outfits</h2>
            </div>

            <div class="saved-outfits-grid">
                <?php if (empty($savedOutfits)): ?>
                    <div class="no-outfits-message">
                        <p>You haven't saved any outfits yet.</p>
                        <p>Create and save your first outfit above!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($savedOutfits as $outfit): ?>
                        <div class="saved-outfit-card" data-outfit-id="<?php echo htmlspecialchars($outfit['id']); ?>">
                            <div class="outfit-header">
                                <h3><?php echo htmlspecialchars($outfit['name']); ?></h3>
                                <span class="outfit-category"><?php echo htmlspecialchars($outfit['category']); ?></span>
                            </div>
                            <div class="outfit-details">
                                <p class="outfit-description"><?php echo htmlspecialchars($outfit['description'] ?? ''); ?></p>
                                <p class="outfit-date">Created: <?php echo date('M d, Y', strtotime($outfit['created_at'])); ?></p>
                                <div class="outfit-items-count">
                                    <i class="fas fa-tshirt"></i> <?php echo (int)$outfit['item_count']; ?> items
                                </div>
                            </div>
                            <div class="outfit-actions">
                                <button class="btn view-outfit" onclick="outfitBuilder.viewOutfit(<?php echo (int)$outfit['id']; ?>)">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                <button class="btn delete-outfit" onclick="outfitBuilder.deleteOutfit(<?php echo (int)$outfit['id']; ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Modals -->
        <div id="saveOutfitModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Save Your Outfit</h2>
                    <button class="close-modal">&times;</button>
                </div>
                <form id="saveOutfitForm">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <div class="form-group">
                        <label for="outfitName">Outfit Name</label>
                        <input type="text" id="outfitName" name="name" required maxlength="100">
                    </div>
                    <div class="form-group">
                        <label for="outfitType">Outfit Type</label>
                        <select id="outfitType" name="type" required>
                            <?php foreach ($outfitTypes as $value => $label): ?>
                                <option value="<?php echo htmlspecialchars($value); ?>">
                                    <?php echo htmlspecialchars($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="outfitNotes">Notes</label>
                        <textarea id="outfitNotes" name="notes" maxlength="500"></textarea>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn" onclick="outfitBuilder.closeModal()">Cancel</button>
                        <button type="submit" class="btn primary">Save Outfit</button>
                    </div>
                </form>
            </div>
        </div>

        <div id="viewOutfitModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Saved Outfit</h2>
                    <button class="close-modal">&times;</button>
                </div>
                <div class="outfit-preview">
                    <div class="outfit-info">
                        <h3 class="outfit-name"></h3>
                        <p class="outfit-category"></p>
                        <p class="outfit-description"></p>
                    </div>
                    <div class="outfit-items-grid">
                        <!-- Items will be populated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/outfit_builder.js"></script>
</body>
</html>