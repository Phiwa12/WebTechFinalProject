<?php
if (isset($_GET['reset']) && $_GET['reset'] === 'success') {
    echo '<div class="success-message">Password has been successfully reset. You can now login with your new password.</div>';
}
?>

<?php
session_start();
require_once('../db/config.php');

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: services.php');
    exit();
}

// Process login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_error = '';
    
    if (isset($_POST['email']) && isset($_POST['password'])) {
        $email = mysqli_real_escape_string($db, $_POST['email']);
        $password = $_POST['password'];

        // Get user with role and status
        $query = "SELECT id, email, password_hash, full_name, role, status 
                 FROM style_users 
                 WHERE email = ?";
                 
        $stmt = $db->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Check if account is active
            if ($user['status'] !== 'active') {
                $login_error = 'This account has been deactivated. Please contact support.';
            }
            // Verify password
            else if (password_verify($password, $user['password_hash'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role'];

                // Update last login timestamp
                $updateStmt = $db->prepare("UPDATE style_users SET last_login = NOW() WHERE id = ?");
                $updateStmt->bind_param('i', $user['id']);
                $updateStmt->execute();

                header('Location: services.php');
                exit();
            } else {
                $login_error = 'Invalid email or password';
            }
        } else {
            $login_error = 'Invalid email or password';
        }
    }
}

$login_features = [
    ['icon' => 'bullseye', 'text' => 'Personalized Style Tips'],
    ['icon' => 'tshirt', 'text' => 'Wardrobe Management'],
    ['icon' => 'palette', 'text' => 'Color Analysis']
];

$social_logins = [
    'google' => ['icon' => 'google', 'text' => 'Google'],
    'facebook' => ['icon' => 'facebook-f', 'text' => 'Facebook']
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - StyleSense</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* Main Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: #FFE4E1;
        }

        .navbar {
            background-color: #ffffff;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.5rem;
            color: #FF1493;
            font-weight: bold;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-links a {
            text-decoration: none;
            color: #4b5563;
            font-weight: 500;
        }

        .signup-btn {
            background-color: #FF1493;
            color: white;
            padding: 0.5rem 1.5rem;
            border-radius: 0.5rem;
            text-decoration: none;
            font-weight: 500;
        }

        /* Login Container Styles */
        .login-container {
            max-width: 400px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .brand-logo {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo-text {
            font-size: 2rem;
            color: #FF1493;
            font-weight: bold;
        }

        .welcome-text {
            text-align: center;
            color: #2d3748;
            margin-bottom: 0.5rem;
            font-size: 1.5rem;
        }

        .login-subtitle {
            text-align: center;
            color: #718096;
            margin-bottom: 2rem;
        }

        .input-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #a0aec0;
        }

        input[type="email"],
        input[type="password"],
        input[type="tel"] {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.5rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s;
        }

        input:focus {
            outline: none;
            border-color: #FF1493;
            box-shadow: 0 0 0 3px rgba(255, 20, 147, 0.1);
        }

        .toggle-password {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #a0aec0;
            cursor: pointer;
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #4a5568;
        }

        .forgot-password {
            color: #FF1493;
            text-decoration: none;
            font-size: 0.875rem;
        }

        .login-btn {
            width: 100%;
            padding: 0.75rem;
            background: #FF1493;
            color: white;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
        }

        .login-btn:hover {
            background: #ff1493d3;
        }

        .divider {
            text-align: center;
            margin: 1.5rem 0;
            position: relative;
        }

        .divider::before,
        .divider::after {
            content: "";
            position: absolute;
            top: 50%;
            width: 45%;
            height: 1px;
            background: #e2e8f0;
        }

        .divider::before {
            left: 0;
        }

        .divider::after {
            right: 0;
        }

        .social-login {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .social-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.75rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            background: white;
            color: #4a5568;
            cursor: pointer;
            transition: all 0.3s;
        }

        .social-btn:hover {
            background: #f7fafc;
        }

        .signup-prompt {
            text-align: center;
            color: #4a5568;
        }

        .signup-link {
            color: #FF1493;
            text-decoration: none;
            font-weight: 500;
        }

        .error-message {
            background: #fed7d7;
            color: #c53030;
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            text-align: center;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 2rem;
            border-radius: 1rem;
            width: 90%;
            max-width: 400px;
        }

        .close-modal {
            position: absolute;
            right: 1rem;
            top: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #a0aec0;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <i class="fas fa-tshirt"></i>
            <span>StyleSense</span>
        </div>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="aboutUs.php">About Us</a>
            <a href="contactUs.php">Contact Us</a>
        </div>
        <div class="auth-buttons">
            <a href="signup.php" class="signup-btn">Sign Up</a>
        </div>
    </nav>

    <div class="login-container">
        <div class="brand-logo">
            <span class="logo-text">StyleSense</span>
        </div>

        <h2 class="welcome-text">Welcome Back!</h2>
        <p class="login-subtitle">Continue your style journey</p>

        <?php if(isset($login_error)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($login_error); ?>
            </div>
        <?php endif; ?>

        <form id="loginForm" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <div class="input-group">
                <div class="input-icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="input-group">
                <div class="input-icon">
                    <i class="fas fa-lock"></i>
                </div>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                <button type="button" class="toggle-password">
                    <i class="fas fa-eye"></i>
                </button>
            </div>

            <div class="remember-forgot">
                <label class="remember-me">
                <input type="checkbox" id="remember" name="remember">
                    Remember me
                </label>
                <a href="#" class="forgot-password">Forgot Password?</a>
            </div>

            <button type="submit" class="login-btn">Log In</button>

            
        </form>

        <div class="signup-prompt">
            <p>Don't have an account? <a href="signup.php" class="signup-link">Join Now</a></p>
        </div>
    </div>

    <!-- Forgot Password Modal -->
    <div class="modal" id="forgotPasswordModal">
        <div class="modal-content">
            <button class="close-modal">
                <i class="fas fa-times"></i>
            </button>
            <h3>Reset Password</h3>
            <p>Enter your email to receive reset instructions</p>
            <form id="resetForm" method="POST" action="../actions/reset_password.php">
                <div class="input-group">
                    <div class="input-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <input type="email" name="reset_email" required placeholder="Your email address">
                </div>
                <button type="submit" class="login-btn">Send Reset Link</button>
            </form>
        </div>
    </div>

    <script>
        // Toggle password visibility
        document.querySelector('.toggle-password').addEventListener('click', function() {
            const passwordInput = document.querySelector('#password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });

        // Forgot password modal
        const forgotPasswordLink = document.querySelector('.forgot-password');
        const modal = document.querySelector('#forgotPasswordModal');
        const closeModal = document.querySelector('.close-modal');

        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            modal.style.display = 'block';
        });

        closeModal.addEventListener('click', function() {
            modal.style.display = 'none';
        });

        window.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    </script>
</body>
</html>