
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About StyleSense - Your Fashion Journey Partner</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/aboutUs.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<style>/* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }</style>
<body>
    <?php
    // Navigation
    $nav_links = [
        'Home' => '../index.php',
        'Body Type Analysis' => 'body_analysis.php',
        'Color Palette' => 'color_palette.php',
        'Outfit Builder' => 'outfit_builder.php',
        'My Wardrobe' => 'wardrobe.php'
    ];
    ?>
    <nav class="navbar">
        <div class="logo">StyleSense</div>
        <div class="nav-links">
            <?php foreach($nav_links as $title => $link): ?>
                <a href="<?php echo $link; ?>" <?php echo basename($_SERVER['PHP_SELF']) == $link ? 'class="active"' : ''; ?>>
                    <?php echo $title; ?>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="auth-buttons">
            <button class="login-btn" onclick="openAuthModal('login.php')">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
            <button class="signup-btn" onclick="openAuthModal('signup.php')">
                <i class="fas fa-user-plus"></i> Sign Up
            </button>
        </div>
    </nav>

    <main class="about-container">
        <!-- Hero Section -->
        <section class="about-hero">
            <div class="hero-content">
                <h1>About StyleSense</h1>
                <p>Empowering women to discover and embrace their unique style</p>
            </div>
        </section>

        <!-- Our Story -->
        <section class="our-story">
            <div class="story-content">
                <h2>Our Story</h2>
                <p class="story-text">
                    <?php
                    $story_text = "StyleSense was born from a simple yet powerful idea: fashion should be accessible and empowering for women. 
                    Founded in 2024, we've made it our mission to help our beautiful women discover and embrace their unique style, 
                    regardless of their body type, age, or fashion experience.";
                    echo $story_text;
                    ?>
                </p>
                <?php
                $stats = [
                    ['number' => '50K+', 'label' => 'Happy Users'],
                    ['number' => '100+', 'label' => 'Style Guides'],
                    ['number' => '1M+', 'label' => 'Outfit Ideas']
                ];
                ?>
                <div class="story-stats">
                    <?php foreach($stats as $stat): ?>
                        <div class="stat-item">
                            <span class="stat-number"><?php echo $stat['number']; ?></span>
                            <span class="stat-label"><?php echo $stat['label']; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- Our Mission -->
        <section class="our-mission">
            <div class="mission-content">
                <div class="mission-text">
                    <h2>Our Mission</h2>
                    <p><?php echo "To revolutionize the way women approach fashion by providing personalized style guidance and building a 
                       supportive community where women feel confident in their clothing choices."; ?></p>
                </div>
            </div>
        </section>

        <!-- Our Values -->
        <?php
        $values = [
            ['icon' => 'heart', 'title' => 'Inclusivity', 'text' => 'Fashion and style guidance for women, regardless of size, shape, or style preferences.'],
            ['icon' => 'lightbulb', 'title' => 'Innovation', 'text' => 'Continuously improving our platform to provide the best style recommendations.'],
            ['icon' => 'users', 'title' => 'Community', 'text' => 'Building a supportive community where users can share and inspire each other.'],
            ['icon' => 'leaf', 'title' => 'Sustainability', 'text' => 'Promoting sustainable fashion choices and conscious consumption.']
        ];
        ?>
        <section class="our-values">
            <h2>Our Values</h2>
            <div class="values-grid">
                <?php foreach($values as $value): ?>
                    <div class="value-card">
                        <div class="value-icon">
                            <i class="fas fa-<?php echo $value['icon']; ?>"></i>
                        </div>
                        <h3><?php echo $value['title']; ?></h3>
                        <p><?php echo $value['text']; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Meet the Team -->
        <section class="our-team">
            <h2>Meet Our Team</h2>
            <div class="team-grid">
                <div class="team-member">
                    <div class="member-photo">
                        <img src="/assets/images/ceo.jpg" alt="Phiwayinkhosi Precious Lukhele">
                        <div class="social-links">
                            <a href="#" aria-label="LinkedIn Profile"><i class="fab fa-linkedin"></i></a>
                            <a href="#" aria-label="Twitter Profile"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                    <h3>Phiwayinkhosi Precious Lukhele</h3>
                    <span class="member-role">Founder & CEO</span>
                    <p>Fashion industry veteran with 5 years of experience</p>
                </div>
            </div>
        </section>

        <!-- Testimonials -->
        <section class="testimonials">
            <h2>What Our Users Say</h2>
            <div class="testimonials-carousel">
                <!-- Testimonials will be added dynamically via JavaScript -->
            </div>
        </section>

        <!-- Partners & Recognition -->
        <section class="recognition">
            <h2>Partners & Recognition</h2>
            <div class="partners-grid">
                <div class="partner-logo">
                    <img src="/assets/images/Vault.png" alt="Fashion Weekly Magazine">
                </div>
            </div>
            <div class="awards">
                <div class="award-item">
                    <img src="https://th.bing.com/th/id/OIP.r8i8cbecdMBP3O8W_fA8cQAAAA?rs=1&pid=ImgDetMain" alt="Best Fashion Tech 2024">
                    <span>Best Fashion Tech Platform 2024</span>
                </div>
            </div>
        </section>

        <!-- Join Us Banner -->
        <section class="join-banner">
            <div class="banner-content">
                <h2>Be Part of Our Journey</h2>
                <p>Join thousands of fashion enthusiasts and discover your perfect style</p>
                <div class="banner-actions">
                    <a href="signup.php" class="cta-button">Get Started</a>
                    <a href="contactUs.php" class="secondary-button">Contact Us</a>
                </div>
            </div>
        </section>
    </main>

    <!-- Video Modal -->
    <div class="modal" id="videoModal">
        <div class="modal-content">
            <button class="close-modal">
                <i class="fas fa-times"></i>
            </button>
            <div class="video-container">
                
            </div>
        </div>
    </div>
    <script>
    function openAuthModal(page) {
        // Redirect to the appropriate authentication page
        window.location.href = page;
    }
</script>

    <script src="../assets/js/aboutUs.js"></script>
</body>
</html>