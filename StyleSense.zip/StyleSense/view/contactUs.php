<?php
session_start();
require_once('../db/config.php');

// Enable error logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('error_log', '../logs/email_errors.log'); // Make sure this directory exists and is writable

// FAQ data structure
$faqs = [
    [
        'question' => 'How do I get started with StyleSense?',
        'answer' => 'Sign up for an account and complete your style profile to receive personalized recommendations.'
    ],
    [
        'question' => 'Is StyleSense free to use?',
        'answer' => 'Yes, our basic features are free. We also offer premium features for enhanced styling options.'
    ]
];

// Business hours data
$business_hours = [
    'Monday - Friday' => '9:00 AM - 6:00 PM',
    'Saturday' => '10:00 AM - 4:00 PM',
    'Sunday' => 'Closed'
];

// Contact card data
$contact_cards = [
    [
        'icon' => 'comments',
        'title' => 'Chat With Us',
        'description' => 'Get instant help from our style experts',
        'action_type' => 'button',
        'action_text' => 'Start Chat',
        'action_class' => 'chat-btn'
    ],
    [
        'icon' => 'envelope',
        'title' => 'Email Us',
        'description' => 'Send us your queries anytime',
        'action_type' => 'link',
        'action_text' => 'support@stylesense.com',
        'action_href' => 'mailto:support@stylesense.com',
        'action_class' => 'email-btn'
    ],
    [
        'icon' => 'phone',
        'title' => 'Call Us',
        'description' => 'Mon-Fri from 9am to 6pm',
        'action_type' => 'link',
        'action_text' => '+1 (234) 567-890',
        'action_href' => 'tel:+1234567890',
        'action_class' => 'phone-btn'
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/contactUs.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="logo">StyleSense</div>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="aboutUs.php">About Us</a>
        </div>
        <div class="auth-buttons">
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="services.php" class="nav-link">Services</a>
                <a href="../actions/logout.php" class="logout-btn">Logout</a>
            <?php else: ?>
                <button class="login-btn" onclick="openAuthModal('login.php')">Login</button>
                <button class="signup-btn" onclick="openAuthModal('signup.php')">Sign Up</button>
            <?php endif; ?>
        </div>
    </nav>

    <main class="contact-container">
        <!-- Hero Section -->
        <section class="contact-hero">
            <div class="hero-content">
                <h1>Get in Touch</h1>
                <p>We'd love to hear from you! Reach out for any questions, feedback, or collaboration opportunities.</p>
            </div>
        </section>

        <!-- Quick Contact Cards -->
        <section class="quick-contact">
            <div class="contact-cards">
                <?php foreach($contact_cards as $card): ?>
                    <div class="contact-card">
                        <div class="card-icon">
                            <i class="fas fa-<?php echo htmlspecialchars($card['icon']); ?>"></i>
                        </div>
                        <h3><?php echo htmlspecialchars($card['title']); ?></h3>
                        <p><?php echo htmlspecialchars($card['description']); ?></p>
                        <?php if($card['action_type'] === 'button'): ?>
                            <button class="<?php echo htmlspecialchars($card['action_class']); ?>">
                                <?php echo htmlspecialchars($card['action_text']); ?>
                            </button>
                        <?php else: ?>
                            <a href="<?php echo htmlspecialchars($card['action_href']); ?>" 
                               class="<?php echo htmlspecialchars($card['action_class']); ?>">
                                <?php echo htmlspecialchars($card['action_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

                <!-- Contact Info -->
                <div class="contact-info">
                    <div class="info-section office-info">
                        <h3>Our Office</h3>
                        <p>
                            <i class="fas fa-map-marker-alt"></i>
                            123 Fashion Street, Design District
                            <br>New York, NY 10001
                        </p>
                    </div>

                    <div class="info-section hours-info">
                        <h3>Business Hours</h3>
                        <ul class="hours-list">
                            <?php foreach($business_hours as $day => $hours): ?>
                                <li>
                                    <span><?php echo htmlspecialchars($day); ?></span>
                                    <span><?php echo htmlspecialchars($hours); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="info-section social-info">
                        <h3>Connect With Us</h3>
                        <div class="social-links">
                            <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- FAQ Section -->
        <section class="faq-section">
            <h2>Frequently Asked Questions</h2>
            <div class="faq-container">
                <?php foreach($faqs as $faq): ?>
                    <div class="faq-item">
                        <h3><?php echo htmlspecialchars($faq['question']); ?></h3>
                        <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
            <button class="view-all-faq">
                View All FAQs
                <i class="fas fa-arrow-right"></i>
            </button>
        </section>
    </main>

    <script>
    function openAuthModal(page) {
        // Redirect to the appropriate authentication page
        window.location.href = page;
    }
</script>

    <script src="../assets/js/contactUs.js"></script>
</body>
</html>
