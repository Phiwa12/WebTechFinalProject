<?php
// verify_reset_code.php - Verifies the reset code
session_start();
require_once('../db/config.php');

if (!isset($_SESSION['reset_email'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['reset_code'];
    $email = $_SESSION['reset_email'];
    
    // Verify code
    $query = "SELECT pr.user_id 
              FROM password_resets pr 
              JOIN style_users u ON pr.user_id = u.id 
              WHERE u.email = ? AND pr.reset_code = ? AND pr.expiry > NOW() 
              AND pr.used = 0";
    
    $stmt = $db->prepare($query);
    $stmt->bind_param('ss', $email, $code);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $_SESSION['reset_code_verified'] = true;
        header('Location: new_password.php');
        exit();
    } else {
        $error = "Invalid or expired code";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verify Reset Code - StyleSense</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: #FFE4E1;
        }

        .navbar {
            background-color: #ffffff;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .navbar .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.5rem;
            color: #FF1493;
            font-weight: bold;
        }

        .container {
            max-width: 400px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .brand-logo {
            text-align: center;
            margin-bottom: 2rem;
        }

        .logo-text {
            font-size: 2rem;
            color: #FF1493;
            font-weight: bold;
        }

        h2 {
            text-align: center;
            color: #2d3748;
            margin-bottom: 0.5rem;
            font-size: 1.5rem;
        }

        .subtitle {
            text-align: center;
            color: #718096;
            margin-bottom: 2rem;
        }

        .input-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #a0aec0;
        }

        input {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 2.5rem;
            border: 1px solid #e2e8f0;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s;
        }

        input:focus {
            outline: none;
            border-color: #FF1493;
            box-shadow: 0 0 0 3px rgba(255, 20, 147, 0.1);
        }

        button {
            width: 100%;
            padding: 0.75rem;
            background: #FF1493;
            color: white;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 1rem;
        }

        button:hover {
            background: #ff1493d3;
        }

        .error {
            background: #fed7d7;
            color: #c53030;
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            text-align: center;
        }

        .success {
            background: #c6f6d5;
            color: #2f855a;
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Enter Reset Code</h2>
        <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
        <form method="POST">
            <input type="text" name="reset_code" required placeholder="Enter 6-digit code">
            <button type="submit">Verify Code</button>
        </form>
    </div>
</body>
</html>