<?php
session_start();
require_once '../db/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Initialize cart and wishlist in session if they don't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Pagination settings
$items_per_page = 12;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $items_per_page;

// Function to get products with filters and pagination
function getProducts($db, $filters = [], $limit = 12, $offset = 0) {
    $sql = "SELECT * FROM shop_products WHERE 1=1";
    $params = [];
    $types = '';

    if (!empty($filters['category'])) {
        $sql .= " AND category = ?";
        $params[] = $filters['category'];
        $types .= 's';
    }
    
    if (!empty($filters['type'])) {
        $sql .= " AND type = ?";
        $params[] = $filters['type'];
        $types .= 's';
    }
    
    if (!empty($filters['price_min'])) {
        $sql .= " AND price >= ?";
        $params[] = $filters['price_min'];
        $types .= 'd';
    }
    
    if (!empty($filters['price_max'])) {
        $sql .= " AND price <= ?";
        $params[] = $filters['price_max'];
        $types .= 'd';
    }

    // Add sorting
    $sql .= " ORDER BY name ASC";
    
    // Add pagination
    $sql .= " LIMIT ? OFFSET ?";
    $params[] = $limit;
    $types .= 'i';
    $params[] = $offset;
    $types .= 'i';

    $stmt = $db->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Function to get total number of products (for pagination)
function getTotalProducts($db, $filters = []) {
    $sql = "SELECT COUNT(*) as total FROM shop_products WHERE 1=1";
    $params = [];
    $types = '';

    if (!empty($filters['category'])) {
        $sql .= " AND category = ?";
        $params[] = $filters['category'];
        $types .= 's';
    }
    
    if (!empty($filters['type'])) {
        $sql .= " AND type = ?";
        $params[] = $filters['type'];
        $types .= 's';
    }
    
    if (!empty($filters['price_min'])) {
        $sql .= " AND price >= ?";
        $params[] = $filters['price_min'];
        $types .= 'd';
    }
    
    if (!empty($filters['price_max'])) {
        $sql .= " AND price <= ?";
        $params[] = $filters['price_max'];
        $types .= 'd';
    }

    $stmt = $db->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

// Get filter values
$category = $_GET['category'] ?? '';
$type = $_GET['type'] ?? '';
$price_min = $_GET['price_min'] ?? '';
$price_max = $_GET['price_max'] ?? '';

// Get filtered products
$filters = [
    'category' => $category,
    'type' => $type,
    'price_min' => $price_min,
    'price_max' => $price_max
];

$products = getProducts($db, $filters, $items_per_page, $offset);
$total_products = getTotalProducts($db, $filters);
$total_pages = ceil($total_products / $items_per_page);

// Categories and types for filters
$categories = [
    'tops' => 'Tops',
    'bottoms' => 'Bottoms',
    'dresses' => 'Dresses',
    'shoes' => 'Shoes',
    'accessories' => 'Accessories',
    'outerwear' => 'Outerwear'
];

$types = [
    'casual' => 'Casual',
    'formal' => 'Formal',
    'business' => 'Business',
    'party' => 'Party'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/shop.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<style>.guide-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .guide-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            color: #2c3e50;
        }

        .guide-card h4 {
            color: #FF1493;
            margin: 10px 0;
            font-size: 18px;
        }

        .guide-card p {
            color: #555;
            line-height: 1.5;
            margin: 8px 0;
        }

        .guide-icon {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .analyze-btn {
            background-color: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
        }

        .latest-analysis {
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .analysis-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .measurements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }

        .new-analysis-btn {
            background: #FF1493;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .body-type-name {
            font-size: 24px;
            color: #FF1493;
            font-weight: bold;
            margin: 15px 0;
        }

        .save-result-btn {
            background: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .measurement-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .input-group input[type="number"],
        .input-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }</style>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="logo">StyleSense</div>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="services.php">Services</a>
            <a href="body_analysis.php">Body Analysis</a>
            <a href="wardrobe.php">My Wardrobe</a>
            <a href="trends.php">Trends</a>
            <a href="outfit_builder.php">Outfit Builder</a>
            <a href="style_quiz.php">Style Quiz</a>
            <a href="color_palette.php">Color Palette</a>
            <a href="shop.php" class="active">Shop</a>
            <a href="community.php">
                    <i class="lni lni-archive"></i> Community
                </a>
           
        </div>
        <div class="user-menu">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
            <a href="#" class="cart-icon" id="cartIcon">
                <i class="fas fa-shopping-cart"></i>
                <span class="cart-count"><?php echo count($_SESSION['cart']); ?></span>
            </a>
            <a href="../actions/logout.php" class="logout-btn">Logout</a>
        </div>
    </nav>

    <main class="shop-container">
        <!-- Shop Header -->
        <section class="shop-header">
            <h1>Shop Our Collection</h1>
            <p>Discover pieces that match your style</p>
        </section>

        <!-- Shop Grid -->
        <div class="shop-grid">
            <!-- Filters Sidebar -->
            <aside class="filters-sidebar">
                <h2>Filters</h2>
                <form id="filterForm" action="shop.php" method="GET">
                    <!-- Categories -->
                    <div class="filter-section">
                        <h3>Categories</h3>
                        <div class="filter-options">
                            <?php foreach($categories as $value => $label): ?>
                                <label class="filter-option">
                                    <input type="radio" name="category" value="<?php echo $value; ?>"
                                           <?php echo $category === $value ? 'checked' : ''; ?>>
                                    <?php echo $label; ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Types -->
                    <div class="filter-section">
                        <h3>Types</h3>
                        <div class="filter-options">
                            <?php foreach($types as $value => $label): ?>
                                <label class="filter-option">
                                    <input type="radio" name="type" value="<?php echo $value; ?>"
                                           <?php echo $type === $value ? 'checked' : ''; ?>>
                                    <?php echo $label; ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Price Range -->
                    <div class="filter-section">
                        <h3>Price Range</h3>
                        <div class="price-inputs">
                            <input type="number" name="price_min" placeholder="Min" 
                                   value="<?php echo $price_min; ?>">
                            <span>to</span>
                            <input type="number" name="price_max" placeholder="Max"
                                   value="<?php echo $price_max; ?>">
                        </div>
                    </div>

                    <button type="submit" class="apply-filters-btn">Apply Filters</button>
                    <a href="shop.php" class="clear-filters-btn">Clear Filters</a>
                </form>
            </aside>

            <!-- Products Grid -->
            <section class="products-grid">
                <?php if (empty($products)): ?>
                    <div class="no-products">
                        <i class="fas fa-search"></i>
                        <p>No products found matching your criteria</p>
                    </div>
                <?php else: ?>
                    <?php foreach($products as $product): ?>
                        <article class="product-card" data-id="<?php echo $product['id']; ?>">
                        <div class="product-image">
    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
         alt="<?php echo htmlspecialchars($product['name']); ?>">
</div>
                            <div class="product-info">
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-price">$<?php echo number_format($product['price'], 2); ?></p>
                                <div class="product-actions">
                                    <button class="add-to-cart-btn" data-id="<?php echo $product['id']; ?>">
                                        Add to Cart
                                    </button>
                                    
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="?page=<?php echo $i; ?><?php echo !empty($category) ? '&category='.$category : ''; ?><?php echo !empty($type) ? '&type='.$type : ''; ?><?php echo !empty($price_min) ? '&price_min='.$price_min : ''; ?><?php echo !empty($price_max) ? '&price_max='.$price_max : ''; ?>" 
                                   class="<?php echo $page === $i ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        </div>
    </main>

    <!-- Shopping Cart Sidebar -->
    <div class="cart-sidebar" id="cartSidebar">
        <div class="cart-header">
            <h2>Shopping Cart</h2>
            <button class="close-cart" id="closeCart">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="cart-items" id="cartItems">
            <?php if (empty($_SESSION['cart'])): ?>
                <p class="empty-cart">Your cart is empty</p>
            <?php else: ?>
                <?php foreach($_SESSION['cart'] as $item): ?>
                    <div class="cart-item">
                        <div class="cart-item-image">
                            <img src="<?php echo htmlspecialchars($item['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($item['name']); ?>">
                        </div>
                        <div class="cart-item-details">
                            <div class="cart-item-title"><?php echo htmlspecialchars($item['name']); ?></div>
                            <div class="cart-item-price">$<?php echo number_format($item['price'], 2); ?></div>
                            <div class="cart-item-quantity">
                                <button class="quantity-btn minus" data-id="<?php echo $item['id']; ?>">-</button>
                                <span><?php echo $item['quantity'] ?? 1; ?></span>
                                <button class="quantity-btn plus" data-id="<?php echo $item['id']; ?>">+</button>
                            </div>
                        </div>
                        <button class="cart-item-remove" data-id="<?php echo $item['id']; ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="cart-footer">
            <div class="cart-total">
                <span>Total:</span>
                <span class="total-amount">$<?php 
                    echo number_format(array_reduce($_SESSION['cart'], function($carry, $item) {
                        return $carry + ($item['price'] * ($item['quantity'] ?? 1));
                    }, 0), 2);
                ?></span>
            </div>
            <button class="checkout-btn">Proceed to Checkout</button>
        </div>
    </div>

    <script>
    // Pass PHP data to JavaScript
    const shopData = <?php echo json_encode([
        'userId' => $_SESSION['user_id'],
        'categories' => $categories,
        'types' => $types,
        'cart' => $_SESSION['cart'],
        'wishlist' => $_SESSION['wishlist']
    ]); ?>;
    </script>
    <script src="../assets/js/shop.js"></script>
</body>
</html>