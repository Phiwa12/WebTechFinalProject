<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Verify admin access
requireAdmin();

// Fetch total users count
$query = "SELECT 
    COUNT(*) as total_users,
    SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as regular_users,
    SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admin_users,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_users
FROM style_users";
$result = mysqli_query($db, $query);
$user_stats = mysqli_fetch_assoc($result);

// Fetch body measurements statistics
$query = "SELECT 
    COUNT(*) as total_measurements,
    COUNT(DISTINCT user_id) as users_with_measurements,
    COUNT(DISTINCT body_type) as unique_body_types
FROM body_measurements";
$result = mysqli_query($db, $query);
$body_stats = mysqli_fetch_assoc($result);

// Fetch color palette statistics
$query = "SELECT 
    COUNT(*) as total_palettes,
    COUNT(DISTINCT user_id) as users_with_palettes,
    COUNT(DISTINCT season) as seasons_used
FROM style_color_palettes";
$result = mysqli_query($db, $query);
$palette_stats = mysqli_fetch_assoc($result);

// Fetch product statistics
$query = "SELECT 
    COUNT(*) as total_products,
    COUNT(DISTINCT category) as categories,
    COUNT(DISTINCT type) as types
FROM shop_products";
$result = mysqli_query($db, $query);
$product_stats = mysqli_fetch_assoc($result);

// Fetch wardrobe statistics
$query = "SELECT 
    COUNT(*) as total_items,
    COUNT(DISTINCT user_id) as users_with_items,
    COUNT(DISTINCT category) as unique_categories,
    AVG(times_worn) as avg_times_worn
FROM style_wardrobe_items";
$result = mysqli_query($db, $query);
$wardrobe_stats = mysqli_fetch_assoc($result);

// Fetch quiz statistics
$query = "SELECT 
    COUNT(*) as total_quiz_attempts,
    COUNT(DISTINCT user_id) as users_taken_quiz,
    COUNT(DISTINCT dominant_style) as unique_styles
FROM style_quiz_results";
$result = mysqli_query($db, $query);
$quiz_stats = mysqli_fetch_assoc($result);

// Get activity statistics over time
$query = "SELECT 
    DATE(created_at) as date,
    COUNT(*) as activity_count,
    activity_type
FROM style_activity_log
GROUP BY DATE(created_at), activity_type
ORDER BY date DESC
LIMIT 30";
$result = mysqli_query($db, $query);
$activity_data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $activity_data[] = $row;
}

$query = "SELECT 
    body_type,
    COUNT(*) as count 
FROM body_measurements 
GROUP BY body_type";
$result = mysqli_query($db, $query);
$body_types_data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $body_types_data[] = $row;
}

$query = "SELECT 
    CASE 
        WHEN dominant_style IS NULL OR dominant_style = '' 
        THEN 'Not Specified' 
        ELSE dominant_style 
    END as dominant_style,
    COUNT(*) as count 
FROM style_quiz_results 
WHERE quiz_answers IS NOT NULL 
GROUP BY dominant_style
HAVING dominant_style IS NOT NULL
ORDER BY count DESC";
$result = mysqli_query($db, $query);
$styles_data = [];
while ($row = mysqli_fetch_assoc($result)) {
    if ($row['dominant_style'] !== 'Not Specified') {
        $styles_data[] = $row;
    }
}

// If no results, provide some default data
if (empty($styles_data)) {

    $query = "SELECT DISTINCT 
        JSON_EXTRACT(quiz_answers, '$.*.selectedStyle') as style
    FROM style_quiz_results 
    WHERE quiz_answers IS NOT NULL";
    $result = mysqli_query($db, $query);
    $styles_data = [];
    $processed_styles = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $styles = json_decode($row['style'], true);
        if ($styles) {
            foreach ($styles as $style) {
                if (!isset($processed_styles[$style])) {
                    $processed_styles[$style] = 0;
                }
                $processed_styles[$style]++;
            }
        }
    }
    
    foreach ($processed_styles as $style => $count) {
        $styles_data[] = [
            'dominant_style' => $style,
            'count' => $count
        ];
    }
}


// Fetch product categories distribution
$query = "SELECT 
    category,
    COUNT(*) as count 
FROM shop_products 
GROUP BY category";
$result = mysqli_query($db, $query);
$categories_data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $categories_data[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/admin_dashboard.css">
    <link rel="stylesheet" href="../assets/css/admin_nav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include '../components/admin_nav.php'; ?>
    

    <div class="admin-container">
        <h1>Admin Dashboard</h1>
        
        <!-- Quick Stats -->
        <div class="stats-grid">
            <div class="stat-card primary">
                <i class="fas fa-users"></i>
                <div>
                    <h3>Total Users</h3>
                    <p><?php echo $user_stats['total_users']; ?></p>
                    <small><?php echo $user_stats['active_users']; ?> active</small>
                </div>
            </div>
            
            <div class="stat-card success">
                <i class="fas fa-palette"></i>
                <div>
                    <h3>Color Palettes</h3>
                    <p><?php echo $palette_stats['total_palettes']; ?></p>
                    <small><?php echo $palette_stats['users_with_palettes']; ?> users</small>
                </div>
            </div>
            
            <div class="stat-card warning">
                <i class="fas fa-tshirt"></i>
                <div>
                    <h3>Wardrobe Items</h3>
                    <p><?php echo $wardrobe_stats['total_items']; ?></p>
                    <small><?php echo $wardrobe_stats['users_with_items']; ?> users</small>
                </div>
            </div>
            
            <div class="stat-card info">
                <i class="fas fa-shopping-bag"></i>
                <div>
                    <h3>Products</h3>
                    <p><?php echo $product_stats['total_products']; ?></p>
                    <small><?php echo $product_stats['categories']; ?> categories</small>
                </div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-grid">
            <!-- User Activity Chart -->
            <div class="chart-card">
                <h3>User Activity</h3>
                <canvas id="activityChart"></canvas>
            </div>

            <!-- Body Types Distribution -->
            <div class="chart-card">
                <h3>Body Types Distribution</h3>
                <canvas id="bodyTypesChart"></canvas>
            </div>

            <!-- Style Quiz Results -->
            <div class="chart-card">
                <h3>Dominant Styles</h3>
                <canvas id="stylesChart"></canvas>
            </div>

            <!-- Product Categories -->
            <div class="chart-card">
                <h3>Product Categories</h3>
                <canvas id="categoriesChart"></canvas>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="recent-activity">
            <h3>Recent Activity</h3>
            <div class="activity-list">
                <?php
                $query = "SELECT 
                    al.activity_type,
                    al.details,
                    al.created_at,
                    u.full_name
                FROM style_activity_log al
                LEFT JOIN style_users u ON al.user_id = u.id
                ORDER BY al.created_at DESC
                LIMIT 10";
                $result = mysqli_query($db, $query);
                while ($activity = mysqli_fetch_assoc($result)) {
                    echo '<div class="activity-item">';
                    echo '<span class="activity-time">' . date('M d, H:i', strtotime($activity['created_at'])) . '</span>';
                    echo '<span class="activity-user">' . htmlspecialchars($activity['full_name'] ?? 'System') . '</span>';
                    echo '<span class="activity-type">' . htmlspecialchars($activity['activity_type']) . '</span>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>

    <script>
        // Activity Chart
        const activityData = <?php echo json_encode($activity_data); ?>;
        new Chart(document.getElementById('activityChart'), {
            type: 'line',
            data: {
                labels: [...new Set(activityData.map(item => item.date))],
                datasets: [{
                    label: 'Daily Activity',
                    data: activityData.map(item => item.activity_count),
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Daily User Activity'
                    }
                }
            }
        });

        // Body Types Chart
    const bodyTypesData = <?php echo json_encode($body_types_data); ?>;
    new Chart(document.getElementById('bodyTypesChart'), {
        type: 'pie',
        data: {
            labels: bodyTypesData.map(item => item.body_type),
            datasets: [{
                data: bodyTypesData.map(item => item.count),
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                },
                title: {
                    display: true,
                    text: 'Body Types Distribution'
                }
            }
        }
    });

    // Dominant Styles Chart
    const stylesData = <?php echo json_encode($styles_data); ?>;
new Chart(document.getElementById('stylesChart'), {
    type: 'doughnut',
    data: {
        labels: stylesData.map(item => 
            item.dominant_style.charAt(0).toUpperCase() + 
            item.dominant_style.slice(1).toLowerCase()
        ),
        datasets: [{
            data: stylesData.map(item => item.count),
            backgroundColor: [
                '#FF6B6B',  // Red
                '#4ECDC4',  // Teal
                '#45B7D1',  // Blue
                '#96CEB4',  // Green
                '#FFEEAD',  // Yellow
                '#D4A5A5',  // Pink
                '#9B786F'   // Brown
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'right',
                labels: {
                    font: {
                        size: 12
                    }
                }
            },
            title: {
                display: true,
                text: 'Style Preferences Distribution',
                font: {
                    size: 16,
                    weight: 'bold'
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.raw || 0;
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = Math.round((value / total) * 100);
                        return `${label}: ${value} (${percentage}%)`;
                    }
                }
            }
        }
    }
});

    // Product Categories Chart
    const categoriesData = <?php echo json_encode($categories_data); ?>;
    new Chart(document.getElementById('categoriesChart'), {
        type: 'bar',
        data: {
            labels: categoriesData.map(item => item.category),
            datasets: [{
                label: 'Number of Products',
                data: categoriesData.map(item => item.count),
                backgroundColor: '#FF1493',
                borderColor: '#388E3C',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Products by Category'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    </script>
</body>
</html>