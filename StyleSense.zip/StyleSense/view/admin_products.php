<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Verify admin access
requireAdmin();

// Add error checking for database connection
if (!$db) {
    die("Database connection failed: " . mysqli_connect_error());
}


$query = "SELECT 
    p.id, p.name, p.description, p.price, p.category, p.type,
    p.color, p.image_url
FROM shop_products p 
ORDER BY p.id DESC";

// Add error checking for query execution
$result = mysqli_query($db, $query);
if (!$result) {
    die("Query failed: " . mysqli_error($db));
}

$products = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_free_result($result);

// Calculate product statistics
$productStats = [
    'total' => count($products),
    'active' => 0,
    'out_of_stock' => 0,
    'low_stock' => 0
];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management - StyleSense Admin</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/admin_products.css">
    <link rel="stylesheet" href="../assets/css/admin_nav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
<?php include '../components/admin_nav.php'; ?>

    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>Product Management</h1>
            <div class="header-actions">
                <div class="search-box">
                    <input type="text" id="productSearch" placeholder="Search products...">
                    <i class="fas fa-search"></i>
                </div>
                <?php if (isSuperAdmin()): ?>
                    <button class="btn primary" onclick="showAddProductModal()">
                        <i class="fas fa-plus"></i> Add Product
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-cards">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-box"></i>
                </div>
                <div class="stat-details">
                    <h3>Total Products</h3>
                    <p><?php echo $productStats['total']; ?></p>
                </div>
            </div>
        </div>

        <!-- Products Table -->
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Color</th>
                        <?php if (isSuperAdmin()): ?>
                            <th>Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo htmlspecialchars($product['category']); ?></td>
                            <td><?php echo htmlspecialchars($product['type']); ?></td>
                            <td>$<?php echo number_format($product['price'], 2); ?></td>
                            <td>
                                <span style="background-color: <?php echo htmlspecialchars($product['color']); ?>; 
                                           width: 20px; 
                                           height: 20px; 
                                           display: inline-block; 
                                           border-radius: 50%;">
                                </span>
                            </td>
                            <?php if (isSuperAdmin()): ?>
                                <td>
                                    <button class="btn-icon" onclick="editProduct(<?php echo $product['id']; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn-icon danger" onclick="deleteProduct(<?php echo $product['id']; ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

   <!-- Product Modal -->
<?php if (isSuperAdmin()): ?>
<div id="productModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Edit Product</h2>
            <button class="close-modal" onclick="closeModal()">&times;</button>
        </div>
        <form id="productForm" onsubmit="return handleSubmit(event)">
            <input type="hidden" id="productId" name="id">
            
            <div class="form-group">
                <label for="name">Product Name</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" required></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" id="price" name="price" step="0.01" required>
            </div>

            <div class="form-group">
                <label for="category">Category</label>
                <select id="category" name="category" required>
                    <option value="tops">Tops</option>
                    <option value="bottoms">Bottoms</option>
                    <option value="dresses">Dresses</option>
                    <option value="shoes">Shoes</option>
                    <option value="accessories">Accessories</option>
                    <option value="outerwear">Outerwear</option>
                </select>
            </div>

            <div class="form-group">
                <label for="type">Type</label>
                <select id="type" name="type" required>
                    <option value="casual">Casual</option>
                    <option value="formal">Formal</option>
                    <option value="business">Business</option>
                    <option value="party">Party</option>
                </select>
            </div>

            <!-- Added Image URL field -->
            <div class="form-group">
                <label for="image_url">Image URL</label>
                <input type="text" id="image_url" name="image_url">
                <img id="productImagePreview" class="image-preview" alt="Product preview">
            </div>

            <!-- Added Color picker field -->
            <div class="form-group">
                <label for="color">Color</label>
                <div class="color-input-group">
                    <input type="color" id="color" name="color" value="#000000">
                    <div id="colorPreview" class="color-preview"></div>
                </div>
            </div>

            <div class="form-actions">
                <button type="button" class="btn" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<script>
    // Debug the products data
    console.log('Raw Products Data:', <?php echo json_encode($products); ?>);
    
    // Initialize products data
    window.products = <?php echo json_encode($products); ?>;
</script>
<script src="../assets/js/admin_products.js" defer></script>
</body>
</html>