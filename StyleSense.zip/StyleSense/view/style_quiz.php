<?php
session_start();
require_once '../db/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Function to load quiz questions from database
function loadQuizQuestions($db) {
    try {
        $stmt = $db->prepare("
            SELECT id, question_text, category, options 
            FROM style_quiz_questions 
            WHERE active = 1 
            ORDER BY category, id
            LIMIT 12
        ");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        error_log("Error loading quiz questions: " . $e->getMessage());
        return [];
    }
}

// Function to load user's quiz history
function loadQuizHistory($db, $userId) {
    try {
        $stmt = $db->prepare("
            SELECT * FROM style_quiz_results 
            WHERE user_id = ? 
            ORDER BY taken_at DESC 
            LIMIT 5
        ");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        error_log("Error loading quiz history: " . $e->getMessage());
        return [];
    }
}

// Get quiz questions and history
$quiz_questions = loadQuizQuestions($db);
$quiz_history = loadQuizHistory($db, $_SESSION['user_id']);
$total_questions = count($quiz_questions);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Style Quiz - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/style_quiz.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>.guide-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .guide-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            color: #2c3e50;
        }

        .guide-card h4 {
            color: #FF1493;
            margin: 10px 0;
            font-size: 18px;
        }

        .guide-card p {
            color: #555;
            line-height: 1.5;
            margin: 8px 0;
        }

        .guide-icon {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .analyze-btn {
            background-color: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
        }

        .latest-analysis {
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .analysis-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .measurements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }

        .new-analysis-btn {
            background: #FF1493;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .body-type-name {
            font-size: 24px;
            color: #FF1493;
            font-weight: bold;
            margin: 15px 0;
        }

        .save-result-btn {
            background: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .measurement-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .input-group input[type="number"],
        .input-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }
        
        .page-header h1{
            color:#ff006a;
        }
        </style>

</head>
<body>
<nav class="navbar">
        <div class="navbar-container">
            <div class="logo">StyleSense</div>
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="lni lni-menu"></i>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="../index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="body_analysis.php" class="active">Body Analysis</a>
                <a href="wardrobe.php">My Wardrobe</a>
                <a href="trends.php">Trends</a>
                <a href="outfit_builder.php">Outfit Builder</a>
                <a href="style_quiz.php">Style Quiz</a>
                <a href="color_palette.php">Color Palette</a>
                <a href="shop.php">Shop</a>
                <a href="community.php">Community</a>
            </div>
            <div class="user-menu" id="userMenu">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                <a href="../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>
    
    <main class="quiz-container">
        <!-- Page Header with Tabs -->
        <div class="page-header">
            <h1>Style Quiz</h1>
            <div class="tab-navigation">
                <button class="tab-button active" data-tab="quiz">Take Quiz</button>
                <button class="tab-button" data-tab="history">Quiz History</button>
            </div>
        </div>

        <!-- Quiz Section -->
        <section class="tab-content" id="quizSection">
            <!-- Quiz Intro -->
            <div class="quiz-intro" id="quizIntro">
                <h2>Discover Your Style Personality</h2>
                <p>Take our interactive quiz to uncover your unique style profile!</p>
                <div class="quiz-info">
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <span>Takes about 5 minutes</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-question-circle"></i>
                        <span><?php echo $total_questions; ?> questions</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-tshirt"></i>
                        <span>Personal style analysis</span>
                    </div>
                </div>
                <button type="button" class="start-quiz-btn">Start Quiz</button>
            </div>

            <!-- Quiz Questions -->
            <div class="quiz-content" id="quizContent" style="display: none;">
                <div class="progress-container">
                    <div class="progress-info">
                        <span class="question-counter">Question 1 of <?php echo $total_questions; ?></span>
                        <span class="category"></span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress" style="width: 0%"></div>
                    </div>
                </div>
                
                <div class="question-container">
                    <!-- Questions will be loaded here -->
                </div>

                <div class="options-container">
                    <!-- Options will be loaded here -->
                </div>
            </div>

            <!-- Quiz Results -->
            <div class="quiz-result" id="quizResult" style="display: none;">
                <div class="results-wrapper">
                    <div class="result-content">
                        <!-- Results will be loaded here -->
                    </div>
                    <div class="action-buttons">
                        <button class="save-results-btn">Save Results</button>
                        <button class="share-results-btn">Share Results</button>
                        <a href="outfit_builder.php" class="build-outfit-btn">Build an Outfit</a>
                    </div>
                </div>
            </div>
        </section>

        <!-- History Section -->
        <section class="tab-content" id="historySection" style="display: none;">
            <div class="history-content">
                <?php if (!empty($quiz_history)): ?>
                    <?php foreach ($quiz_history as $result): ?>
                        <div class="history-item">
                            <div class="history-date">
                                <?php echo date('M d, Y h:i A', strtotime($result['taken_at'])); ?>
                            </div>
                            <div class="history-details">
                                <?php 
                                    $profile = json_decode($result['style_profile'], true);
                                    $recommendations = json_decode($result['recommendations'], true);
                                    $dominantStyle = isset($profile['dominant_style']) ? ucfirst($profile['dominant_style']) : 'Unknown';
                                ?>
                                <h3><?php echo $dominantStyle; ?> Style</h3>
                                <?php if (isset($profile['style_scores'])): ?>
                                    <div class="style-scores">
                                        <?php foreach ($profile['style_scores'] as $style => $score): ?>
                                            <div class="score-bar">
                                                <div class="score-label"><?php echo ucfirst($style); ?></div>
                                                <div class="score-value" style="width: <?php echo $score; ?>%">
                                                    <?php echo $score; ?>%
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if (isset($recommendations['general'])): ?>
                                    <div class="recommendations">
                                        <h4>Recommendations</h4>
                                        <ul>
                                            <?php foreach ($recommendations['general'] as $rec): ?>
                                                <li><?php echo htmlspecialchars($rec); ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="no-history">
                        <p>You haven't taken any style quizzes yet.</p>
                        <button class="take-quiz-btn" onclick="showQuizTab()">Take Your First Quiz</button>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <script>
    // Pass PHP data to JavaScript
    const quizData = {
        questions: <?php echo json_encode($quiz_questions); ?>,
        totalQuestions: <?php echo $total_questions; ?>
    };

    // Tab Navigation
    function showQuizTab() {
        document.querySelector('[data-tab="quiz"]').click();
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Tab switching logic
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', function() {
                // Update active tab button
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('active');
                });
                this.classList.add('active');

                // Show corresponding section
                const tabName = this.getAttribute('data-tab');
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.style.display = 'none';
                });
                if (tabName === 'quiz') {
                    document.getElementById('quizSection').style.display = 'block';
                } else {
                    document.getElementById('historySection').style.display = 'block';
                }
            });
        });
    });
    </script>
    <script src="../assets/js/style_quiz.js"></script>
</body>
</html>