<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Define data structures
$filters = [
    'all' => 'All Trends',
    'casual' => 'Casual Wear',
    'formal' => 'Formal Wear',
    'seasonal' => 'Seasonal',
    'accessories' => 'Accessories'
];

$trending_items = [
    [
        'image' => 'https://images.pexels.com/photos/2043590/pexels-photo-2043590.jpeg',
        'title' => 'Monochrome Magic',
        'description' => 'Head-to-toe single color looks are making a major comeback',
        'category' => 'formal'
    ],
    [
        'image' => 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg',
        'title' => 'Oversized Blazers',
        'description' => 'The perfect blend of comfort and sophistication',
        'category' => 'casual'
    ],
    [
        'image' => 'https://images.pexels.com/photos/2755612/pexels-photo-2755612.jpeg',
        'title' => 'Sustainable Fashion',
        'description' => 'Eco-friendly materials and ethical production',
        'category' => 'casual'
    ],
    [
        'image' => 'https://images.pexels.com/photos/914668/pexels-photo-914668.jpeg',
        'title' => 'Statement Accessories',
        'description' => 'Bold pieces that elevate any outfit',
        'category' => 'accessories'
    ],
    [
        'image' => 'https://images.pexels.com/photos/1375736/pexels-photo-1375736.jpeg',
        'title' => 'Winter Essentials',
        'description' => 'Must-have pieces for the cold season',
        'category' => 'seasonal'
    ],
    [
        'image' => 'https://images.pexels.com/photos/1021693/pexels-photo-1021693.jpeg',
        'title' => 'Evening Wear',
        'description' => 'Elegant options for special occasions',
        'category' => 'formal'
    ]
];

$body_types = [
    'hourglass' => [
        'image' => 'https://hips.hearstapps.com/hbz.h-cdn.co/assets/15/43/hbz-best-hourglass-gettyimages-181720440_1.jpg',
        'title' => 'Hourglass',
        'description' => 'Styles that complement curves'
    ],
    'pear' => [
        'image' => 'https://th.bing.com/th/id/OIP.qf35yHXhjqtIH1tYIhHOswHaSK',
        'title' => 'Pear',
        'description' => 'Balance-focused styles'
    ],
    'apple' => [
        'image' => 'https://media.stunningstyle.com/wp-content/uploads/2021/04/13100506/26-1-683x1024.jpg',
        'title' => 'Apple',
        'description' => 'Flattering fits and styles'
    ],
    'rectangle' => [
        'image' => 'https://th.bing.com/th/id/OIP.muYhflFE1PbwjmGsezrR5wHaJ7',
        'title' => 'Rectangle',
        'description' => 'Creating curves with style'
    ]
];

$style_tips = [
    ['icon' => 'palette', 'title' => 'Color Coordination', 'description' => 'Learn how to mix and match colors for any occasion'],
    ['icon' => 'ruler', 'title' => 'Perfect Fit Guide', 'description' => 'Tips for finding clothes that fit perfectly'],
    ['icon' => 'tshirt', 'title' => 'Wardrobe Essentials', 'description' => 'Must-have pieces for every closet'],
    ['icon' => 'magic', 'title' => 'Style Hacks', 'description' => 'Quick tips to elevate any outfit']
];

$seasonal_trends = [
    [
        'image' => 'https://images.pexels.com/photos/2887766/pexels-photo-2887766.jpeg',
        'title' => 'Cozy Winter Coats',
        'description' => 'Stay warm and stylish'
    ],
    [
        'image' => 'https://images.pexels.com/photos/1446521/pexels-photo-1446521.jpeg',
        'title' => 'Winter Boots',
        'description' => 'Perfect for cold weather'
    ],
    [
        'image' => 'https://images.pexels.com/photos/1126993/pexels-photo-1126993.jpeg',
        'title' => 'Winter Accessories',
        'description' => 'Complete your winter look'
    ]
];

// Handle newsletter subscription
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    // Process newsletter subscription
    $subscription_success = true;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fashion Trends - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/trends.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>/* Seasonal Trends */
.seasonal-trends {
    padding: 60px 0;
}

.season-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

.season-card {
    position: relative;
    border-radius: 15px;
    overflow: hidden;
    height: 400px; 
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

.season-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.season-card:hover .season-image {
    transform: scale(1.1);
}

.season-content {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 20px; 
    background: linear-gradient(transparent, rgba(0,0,0,0.8));
    color: white;
}

.season-content h3 {
    font-size: 1.2rem; /* Reduced font size */
    margin-bottom: 5px;
}

.season-content p {
    font-size: 0.9rem; /* Reduced font size */
    margin: 0;
}

h2{

    color:#FF1493;
}
.guide-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .guide-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            color: #2c3e50;
        }

        .guide-card h4 {
            color: #FF1493;
            margin: 10px 0;
            font-size: 18px;
        }

        .guide-card p {
            color: #555;
            line-height: 1.5;
            margin: 8px 0;
        }

        .guide-icon {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .analyze-btn {
            background-color: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
        }

        .latest-analysis {
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .analysis-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .measurements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }

        .new-analysis-btn {
            background: #FF1493;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .body-type-name {
            font-size: 24px;
            color: #FF1493;
            font-weight: bold;
            margin: 15px 0;
        }

        .save-result-btn {
            background: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .measurement-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .input-group input[type="number"],
        .input-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }
        .trends-hero{
            background-color:rgb(255, 4, 138);
        }

</style>

</head>
<body>
<nav class="navbar">
        <div class="navbar-container">
            <div class="logo">StyleSense</div>
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="lni lni-menu"></i>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="../index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="body_analysis.php" class="active">Body Analysis</a>
                <a href="wardrobe.php">My Wardrobe</a>
                <a href="trends.php">Trends</a>
                <a href="outfit_builder.php">Outfit Builder</a>
                <a href="style_quiz.php">Style Quiz</a>
                <a href="color_palette.php">Color Palette</a>
                <a href="shop.php">Shop</a>
                <a href="community.php">Community</a>
            </div>
            <div class="user-menu" id="userMenu">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                <a href="../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>

    <main class="trends-container">
        <!-- Hero Section -->
        <section class="trends-hero">
            <div class="hero-content">
                <h1>Discover Latest Fashion Trends</h1>
                <p>Stay inspired with the latest styles and fashion inspirations for every body type</p>
                <div class="hero-actions">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <a href="style_quiz.php" class="primary-btn">
                            <i class="fas fa-magic"></i>
                            Find Your Style
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="primary-btn">
                            <i class="fas fa-sign-in-alt"></i>
                            Login to Start
                        </a>
                    <?php endif; ?>
                    <a href="style_tips.php" class="secondary-btn">
                        <i class="fas fa-book"></i>
                        Style Tips
                    </a>
                </div>
            </div>
        </section>

        <!-- Quick Filter Section -->
        <section class="quick-filters">
            <?php foreach($filters as $key => $label): ?>
                <button class="filter-pill <?php echo $key === 'all' ? 'active' : ''; ?>" 
                        data-filter="<?php echo $key; ?>">
                    <?php echo $label; ?>
                </button>
            <?php endforeach; ?>
        </section>

        <!-- Trending Now Section -->
        <section class="trending-now">
            <div class="section-header">
                <h2>Trending Now</h2>
                <p>Discover what's hot in fashion right now</p>
            </div>
            <div class="trends-grid">
                <?php foreach($trending_items as $item): ?>
                    <div class="trend-card" data-category="<?php echo $item['category']; ?>">
                        <div class="trend-image">
                            <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['title']; ?>">
                        </div>
                        <div class="trend-content">
                            <h3><?php echo $item['title']; ?></h3>
                            <p><?php echo $item['description']; ?></p>
                            
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Style Guides Section -->
        <section class="style-guides">
            <div class="section-header">
                <h2>Style Guides For Every Body Type</h2>
                <p>Find the perfect style that complements your unique shape</p>
            </div>
            <div class="guides-grid">
                <?php foreach($body_types as $type => $data): ?>
                    <div class="guide-card <?php echo $type; ?>">
                        <img src="<?php echo htmlspecialchars($data['image']); ?>" 
                             alt="<?php echo htmlspecialchars($data['title']); ?> body type">
                        <h3><?php echo htmlspecialchars($data['title']); ?></h3>
                        <p><?php echo htmlspecialchars($data['description']); ?></p>
                        <a href="view_guide.php?type=<?php echo $type; ?>" class="guide-link">View Guide</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Seasonal Trends -->
        <section class="seasonal-trends">
            <div class="season-header">
                <h2>This Season's Must-Haves</h2>
                <p>Essential pieces for the current season</p>
            </div>
            <div class="season-grid">
                <?php foreach($seasonal_trends as $trend): ?>
                    <div class="season-card">
                        <img src="<?php echo $trend['image']; ?>" 
                             alt="<?php echo $trend['title']; ?>"
                             class="season-image">
                        <div class="season-content">
                            <h3><?php echo $trend['title']; ?></h3>
                            <p><?php echo $trend['description']; ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Style Tips -->
        <section class="style-tips">
            <div class="section-header">
                <h2>Universal Style Tips</h2>
                <p>Fashion advice that works for everyone</p>
            </div>
            <div class="tips-grid">
                <?php foreach($style_tips as $tip): ?>
                    <div class="tip-card">
                        <i class="fas fa-<?php echo $tip['icon']; ?>"></i>
                        <h3><?php echo htmlspecialchars($tip['title']); ?></h3>
                        <p><?php echo htmlspecialchars($tip['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Newsletter Section -->
        <section class="newsletter">
            <div class="newsletter-content">
                <h2>Stay Trendy!</h2>
                <p>Get weekly style updates and fashion tips delivered to your inbox</p>
                <?php if(isset($subscription_success)): ?>
                    <div class="success-message">
                        Thanks for subscribing! Check your email to confirm.
                    </div>
                <?php else: ?>
                    <form class="newsletter-form" method="POST" action="subscribe.php">
                        <input type="email" name="email" placeholder="Enter your email" required>
                        <button type="submit" class="primary-btn">Subscribe</button>
                    </form>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <script>
    // Pass PHP data to JavaScript
    const trendData = <?php echo json_encode([
        'filters' => $filters,
        'isLoggedIn' => isset($_SESSION['user_id'])
    ]); ?>;
    </script>
    <script src="../assets/js/trends.js"></script>
</body>
</html>