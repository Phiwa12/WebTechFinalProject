<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once '../db/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Add CSRF Protection
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function validateInput($data) {
    global $db;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($db, $data);
}

function isValidImageUrl($url) {
    if (filter_var($url, FILTER_VALIDATE_URL) === false) {
        return false;
    }
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $extension = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
    return in_array($extension, $allowed_extensions);
}

// Fetch posts
try {
    $sql = "SELECT p.*, u.full_name, 
           (SELECT COUNT(*) FROM style_community_comments WHERE post_id = p.id) as comment_count,
           (SELECT COUNT(*) FROM style_community_likes WHERE post_id = p.id) as like_count
           FROM style_community_posts p
           JOIN style_users u ON p.user_id = u.id
           ORDER BY p.created_at DESC";
    
    $result = mysqli_query($db, $sql);
    if (!$result) {
        throw new Exception("Database query failed: " . mysqli_error($db));
    }
    $posts = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_free_result($result);
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    $error_message = "An error occurred while loading posts.";
}

// Handle post actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('CSRF token validation failed');
    }

    try {
        switch ($_POST['action']) {
            case 'create_post':
                $title = validateInput($_POST['title']);
                if (empty($title) || strlen($title) > 100) {
                    throw new Exception("Invalid title length");
                }
                
                $content = validateInput($_POST['content']);
                if (empty($content) || strlen($content) > 1000) {
                    throw new Exception("Invalid content length");
                }
                
                $image_url = '';
                if (!empty($_POST['image_url'])) {
                    $image_url = validateInput($_POST['image_url']);
                    if (!isValidImageUrl($image_url)) {
                        throw new Exception("Invalid image URL");
                    }
                }
                
                $stmt = mysqli_prepare($db, "INSERT INTO style_community_posts (user_id, title, content, image_url) VALUES (?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "isss", $_SESSION['user_id'], $title, $content, $image_url);
                
                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception("Failed to create post: " . mysqli_error($db));
                }
                mysqli_stmt_close($stmt);
                header('Location: community.php');
                exit();
                
            case 'add_comment':
                $post_id = filter_var($_POST['post_id'], FILTER_VALIDATE_INT);
                if ($post_id === false || $post_id < 1) {
                    throw new Exception("Invalid post ID");
                }
                
                $comment = validateInput($_POST['comment']);
                if (empty($comment) || strlen($comment) > 500) {
                    throw new Exception("Invalid comment length");
                }
                
                $stmt = mysqli_prepare($db, "INSERT INTO style_community_comments (post_id, user_id, comment) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "iis", $post_id, $_SESSION['user_id'], $comment);
                
                if (!mysqli_stmt_execute($stmt)) {
                    throw new Exception("Failed to add comment: " . mysqli_error($db));
                }
                mysqli_stmt_close($stmt);
                header('Location: community.php');
                exit();
                
            case 'like_post':
                $post_id = filter_var($_POST['post_id'], FILTER_VALIDATE_INT);
                if ($post_id === false || $post_id < 1) {
                    throw new Exception("Invalid post ID");
                }
                
                $check_stmt = mysqli_prepare($db, "SELECT id FROM style_community_likes WHERE post_id = ? AND user_id = ?");
                mysqli_stmt_bind_param($check_stmt, "ii", $post_id, $_SESSION['user_id']);
                mysqli_stmt_execute($check_stmt);
                mysqli_stmt_store_result($check_stmt);
                
                if (mysqli_stmt_num_rows($check_stmt) > 0) {
                    mysqli_stmt_close($check_stmt);
                    throw new Exception("Already liked this post");
                }
                mysqli_stmt_close($check_stmt);
                
                mysqli_begin_transaction($db);
                
                try {
                    $like_stmt = mysqli_prepare($db, "INSERT INTO style_community_likes (post_id, user_id) VALUES (?, ?)");
                    mysqli_stmt_bind_param($like_stmt, "ii", $post_id, $_SESSION['user_id']);
                    mysqli_stmt_execute($like_stmt);
                    mysqli_stmt_close($like_stmt);
                    
                    $update_stmt = mysqli_prepare($db, "UPDATE style_community_posts SET likes = likes + 1 WHERE id = ?");
                    mysqli_stmt_bind_param($update_stmt, "i", $post_id);
                    mysqli_stmt_execute($update_stmt);
                    mysqli_stmt_close($update_stmt);
                    
                    mysqli_commit($db);
                } catch (Exception $e) {
                    mysqli_rollback($db);
                    throw $e;
                }
                
                header('Location: community.php');
                exit();
        }
    } catch (Exception $e) {
        error_log("Error in post handling: " . $e->getMessage());
        $error_message = "An error occurred: " . htmlspecialchars($e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StyleSense Community</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root {
            --primary-pink: #FF69B4;
            --light-pink: #FFC0CB;
            --dark-pink: #FF1493;
            --background-pink: #FFF5F7;
        }

        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: var(--background-pink);
        }

        .container {
            max-width: 800px;
            margin: 80px auto 20px;
            padding: 0 20px;
        }

        .create-post {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .create-post h2 {
            color: var(--primary-pink);
            margin-bottom: 15px;
        }

        .post-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input[type="text"],
        textarea {
            padding: 12px;
            border: 1px solid var(--light-pink);
            border-radius: 4px;
            font-size: 14px;
            width: 100%;
            box-sizing: border-box;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        button {
            background-color: var(--primary-pink);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: var(--dark-pink);
        }

        .post {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .post-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            border-bottom: 1px solid var(--light-pink);
            padding-bottom: 10px;
        }

        .post-image {
            width: 100%;
            max-height: 400px;
            object-fit: cover;
            border-radius: 4px;
            margin: 10px 0;
        }

        .post-actions {
            display: flex;
            gap: 15px;
            margin: 15px 0;
            padding: 10px 0;
            border-top: 1px solid var(--light-pink);
        }

        .comments {
            margin-top: 15px;
        }

        .comment {
            padding: 10px;
            background-color: #f8f8f8;
            border-radius: 4px;
            margin: 8px 0;
        }

        .comment-form {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .comment-form input {
            flex: 1;
        }

        .error-message {
            background-color: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .container {
                padding: 0 15px;
            }
            
            .post-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .comment-form {
                flex-direction: column;
            }
        }

        .guide-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .guide-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            color: #2c3e50;
        }

        .guide-card h4 {
            color: #FF1493;
            margin: 10px 0;
            font-size: 18px;
        }

        .guide-card p {
            color: #555;
            line-height: 1.5;
            margin: 8px 0;
        }

        .guide-icon {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .analyze-btn {
            background-color: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
        }

        .latest-analysis {
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .analysis-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .measurements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }

        .new-analysis-btn {
            background: #FF1493;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .body-type-name {
            font-size: 24px;
            color: #FF1493;
            font-weight: bold;
            margin: 15px 0;
        }

        .save-result-btn {
            background: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .measurement-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .input-group input[type="number"],
        .input-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }
    </style>
</head>
<body>
<nav class="navbar">
        <div class="navbar-container">
            <div class="logo">StyleSense</div>
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="lni lni-menu"></i>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="../index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="body_analysis.php" class="active">Body Analysis</a>
                <a href="wardrobe.php">My Wardrobe</a>
                <a href="trends.php">Trends</a>
                <a href="outfit_builder.php">Outfit Builder</a>
                <a href="style_quiz.php">Style Quiz</a>
                <a href="color_palette.php">Color Palette</a>
                <a href="shop.php">Shop</a>
                <a href="community.php">Community</a>
            </div>
            <div class="user-menu" id="userMenu">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                <a href="../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <div class="create-post">
            <h2><i class="fas fa-pen"></i> Share with the Community</h2>
            <form class="post-form" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" name="action" value="create_post">
                <input type="text" name="title" placeholder="Post Title" required>
                <textarea name="content" placeholder="What's on your mind?" required></textarea>
                <input type="text" name="image_url" placeholder="Image URL (optional)">
                <button type="submit"><i class="fas fa-paper-plane"></i> Post</button>
            </form>
        </div>

        <div class="posts">
            <?php if (empty($posts)): ?>
                <div class="post">
                    <p class="text-center">
                        <i class="fas fa-comments"></i>
                        No posts yet. Be the first to share something!
                    </p>
                </div>
            <?php else: ?>
                <?php foreach ($posts as $post): ?>
                    <div class="post">
                        <div class="post-header">
                            <h3><?php echo htmlspecialchars($post['title']); ?></h3>
                            <small>
                                <i class="fas fa-user"></i> 
                                Posted by <?php echo htmlspecialchars($post['full_name']); ?>
                            </small>
                        </div>
                        
                        <p><?php echo htmlspecialchars($post['content']); ?></p>
                        
                        <?php if ($post['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($post['image_url']); ?>" 
                                 alt="Post image" 
                                 class="post-image"
                                 onerror="this.style.display='none'">
                        <?php endif; ?>
                        
                        <div class="post-actions">
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="action" value="like_post">
                                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                <button type="submit">
                                    <i class="fas fa-heart"></i> 
                                    <?php echo $post['like_count']; ?>
                                </button>
                            </form>
                            <span>
                                <i class="fas fa-comment"></i> 
                                <?php echo $post['comment_count']; ?>
                            </span>
                        </div>

                        <div class="comments">
                            <?php
                            $comment_stmt = mysqli_prepare($db, 
                                "SELECT c.*, u.full_name 
                                 FROM style_community_comments c
                                 JOIN style_users u ON c.user_id = u.id
                                 WHERE c.post_id = ?
                                 ORDER BY c.created_at DESC"
                            );
                            mysqli_stmt_bind_param($comment_stmt, "i", $post['id']);
                            mysqli_stmt_execute($comment_stmt);
                            $comments_result = mysqli_stmt_get_result($comment_stmt);
                            $comments = mysqli_fetch_all($comments_result, MYSQLI_ASSOC);
                            mysqli_stmt_close($comment_stmt);
                            ?>
                            
                            <?php foreach ($comments as $comment): ?>
                                <div class="comment">
                                    <small>
                                        <i class="fas fa-user-circle"></i>
                                        <?php echo htmlspecialchars($comment['full_name']); ?>:
                                    </small>
                                    <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                                </div>
                            <?php endforeach; ?>

                            <form class="comment-form" method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                <input type="hidden" name="action" value="add_comment">
                                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                <input type="text" name="comment" placeholder="Add a comment..." required>
                                <button type="submit">
                                    <i class="fas fa-reply"></i> Comment
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
