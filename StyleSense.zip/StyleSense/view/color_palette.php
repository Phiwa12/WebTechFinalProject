<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';
require_once '../functions/color_functions.php';


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Color Palette - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/color_palette.css">
<style>/* color_palette.css */
.saved-palettes {
    margin-top: 30px;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.saved-palette {
    display: flex;
    align-items: center;
    padding: 15px;
    margin-bottom: 15px;
    border: 1px solid #eee;
    border-radius: 8px;
    background: #f8f9fa;
}

.palette-info {
    flex: 1;
}

.palette-name {
    font-weight: bold;
    display: block;
}

.palette-date {
    font-size: 0.8em;
    color: #666;
}

.palette-colors {
    display: flex;
    gap: 10px;
    margin: 0 20px;
}

.color-bubble {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 2px solid #fff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    position: relative;
}

.remove-color {
    position: absolute;
    top: -5px;
    right: -5px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #ff4444;
    color: white;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
}

.combination-card {
    background: white;
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    margin-bottom: 15px;
}

.color-strips {
    display: flex;
    flex-direction: column;
    gap: 5px;
    margin: 10px 0;
}

.color-strip {
    height: 30px;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-shadow: 0 0 2px rgba(0,0,0,0.5);
}

.use-combo-btn, .load-palette-btn {
    width: 100%;
    padding: 8px;
    border: none;
    border-radius: 4px;
    background: #FF1493;
    color: white;
    cursor: pointer;
    margin-top: 10px;
    transition: background 0.3s ease;
}

.use-combo-btn:hover, .load-palette-btn:hover {
    background: #ff0080;
}

.save-palette-btn {
    background: #FF1493;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top: 20px;
    width: 100%;
}

.save-palette-btn:disabled {
    background: #ccc;
    cursor: not-allowed;
}

.guide-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .guide-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            color: #2c3e50;
        }

        .guide-card h4 {
            color: #FF1493;
            margin: 10px 0;
            font-size: 18px;
        }

        .guide-card p {
            color: #555;
            line-height: 1.5;
            margin: 8px 0;
        }

        .guide-icon {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .analyze-btn {
            background-color: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
        }

        .latest-analysis {
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .analysis-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .measurements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
        }

        .new-analysis-btn {
            background: #FF1493;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .body-type-name {
            font-size: 24px;
            color: #FF1493;
            font-weight: bold;
            margin: 15px 0;
        }

        .save-result-btn {
            background: #FF1493;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .measurement-inputs {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .input-group {
            margin-bottom: 15px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .input-group input[type="number"],
        .input-group select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        /* Navigation Styles */
        .navbar {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 0 1rem;
        }

        .navbar-container {
            max-width: 1280px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 4rem;
        }

        .logo {
            color: #FF1493;
            font-size: 1.25rem;
            font-weight: bold;
            flex-shrink: 0;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0 1rem;
            flex-wrap: nowrap;
            overflow-x: auto;
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        .nav-links::-webkit-scrollbar {
            display: none;
        }

        .nav-links a {
            color: #4a5568;
            text-decoration: none;
            font-size: 0.875rem;
            padding: 0.5rem 0.75rem;
            white-space: nowrap;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: #FF1493;
        }

        .nav-links a.active {
            color: #FF1493;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-shrink: 0;
        }

        .user-menu span {
            color: #4a5568;
            font-size: 0.875rem;
        }

        .logout-btn {
            background: #FF1493;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            text-decoration: none;
            transition: background-color 0.2s;
            white-space: nowrap;
        }

        .logout-btn:hover {
            background: #ff006a;
        }

        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: #4a5568;
            cursor: pointer;
            padding: 0.5rem;
        }

        @media (max-width: 1024px) {
            .mobile-menu-btn {
                display: block;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 4rem;
                left: 0;
                right: 0;
                background: white;
                flex-direction: column;
                padding: 1rem;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }

            .nav-links.active {
                display: flex;
            }

            .user-menu {
                display: none;
            }

            .user-menu.active {
                display: flex;
                flex-direction: column;
                padding: 1rem;
                background: white;
                position: absolute;
                top: 4rem;
                right: 0;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                z-index: 1000;
            }
        }
        .palette-container h3{
            color:#FF1493;
        }

        .color-combinations h3{
            color:#FF1493;
        }

</style>
</head>
<body>
<nav class="navbar">
        <div class="navbar-container">
            <div class="logo">StyleSense</div>
            <button class="mobile-menu-btn" onclick="toggleMobileMenu()">
                <i class="lni lni-menu"></i>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="../index.php">Home</a>
                <a href="services.php">Services</a>
                <a href="body_analysis.php" class="active">Body Analysis</a>
                <a href="wardrobe.php">My Wardrobe</a>
                <a href="trends.php">Trends</a>
                <a href="outfit_builder.php">Outfit Builder</a>
                <a href="style_quiz.php">Style Quiz</a>
                <a href="color_palette.php">Color Palette</a>
                <a href="shop.php">Shop</a>
                <a href="community.php">Community</a>
            </div>
            <div class="user-menu" id="userMenu">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
                <a href="../actions/logout.php" class="logout-btn">Logout</a>
            </div>
        </div>
    </nav>
    
    <main class="color-tool-container">
        <section class="color-picker-section">
            <h2>Find Your Perfect Colors</h2>
            <div class="season-selector">
                <button class="season-btn" data-season="spring">Spring</button>
                <button class="season-btn" data-season="summer">Summer</button>
                <button class="season-btn" data-season="autumn">Autumn</button>
                <button class="season-btn" data-season="winter">Winter</button>
            </div>
            
            <div class="color-wheel-container">
                <canvas id="colorWheel"></canvas>
                <div class="selected-color-info">
                    <div class="color-preview"></div>
                    <span class="color-hex">#000000</span>
                </div>
            </div>

            <div class="palette-container">
    <h3>Your Personal Color Palette</h3>
    <div class="saved-colors"></div>
    <button class="save-palette-btn">Save Palette</button>
</div>
<div class="saved-palettes"></div>
        </section>

        <section class="color-combinations">
            <h3>Suggested Combinations</h3>
            <div class="combination-cards"></div>
        </section>

        <section class="saved-palettes-history">
    <h3>Your Palette History</h3>
    <div class="palettes-container"></div>
</section>
    </main>

    <script src="../assets/js/color_palette.js"></script>
</body>
</html>