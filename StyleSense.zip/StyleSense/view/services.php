<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get user data from session
$userName = htmlspecialchars($_SESSION['full_name'] ?? 'Guest');
$userRole = $_SESSION['role'] ?? 'user';
$isAdmin = $userRole === 'admin' || $userRole === 'super_admin';
$isSuperAdmin = $userRole === 'super_admin';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StyleSense Services</title>
    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #FFE4E1;
        }

        .welcome-message {
            text-align: center;
            color: #FF1493;
            margin-bottom: 30px;
            font-size: 32px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .role-badge {
            font-size: 14px;
            padding: 5px 10px;
            border-radius: 20px;
            background-color: #FFF;
            color: #FF1493;
            font-weight: 500;
        }

        .section-title {
            text-align: center;
            color: #FF1493;
            margin: 40px 0 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .layout {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .layout div {
            background-color: white;
            height: 70px;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border: 1px solid #e1e4e8;
        }

        .layout div:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .layout a {
            text-decoration: none;
            color: #2c3e50;
            font-size: 16px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
            justify-content: center;
        }

        .layout a i {
            font-size: 24px;
            color: pink;
        }

        .layout a:hover {
            color: pink;
        }

        .admin-section .layout div {
            background-color: #FFF5FA;
        }

        .admin-section .layout a i {
            color: #FF1493;
        }

        .super-admin-section .layout div {
            background-color: #FCE4EC;
        }

        .navigation-buttons {
            margin-top: 30px;
        }

        .logout-btn {
            background-color: #fff5f5 !important;
        }

        .logout-btn a {
            color: #e74c3c !important;
        }

        .logout-btn a i {
            color: #e74c3c !important;
        }

        .home-btn {
            background-color: #f0f9ff !important;
        }

        .home-btn a i {
            color: #3498db !important;
        }
    </style>
</head>
<body>
    <div class="welcome-message">
        Welcome <?php echo $userName; ?>!
        <?php if ($isAdmin): ?>
            <span class="role-badge"><?php echo ucfirst($userRole); ?></span>
        <?php endif; ?>
    </div>

    <!-- Main Services Section -->
    <section class="user-section">
        <div class="layout">
            <div>
                <a href="body_analysis.php">
                    <i class="lni lni-ruler-alt"></i> Body Analysis
                </a>
            </div>
            
            <div>
                <a href="color_palette.php">
                    <i class="lni lni-palette"></i> Color Palette
                </a>
            </div>
            
            <div>
                <a href="outfit_builder.php">
                    <i class="lni lni-tshirt"></i> Outfit Builder
                </a>
            </div>
            
            <div>
                <a href="style_quiz.php">
                    <i class="lni lni-graduation"></i> Style Quiz
                </a>
            </div>
            
            <div>
                <a href="shop.php">
                    <i class="lni lni-bulb"></i> Shop
                </a>
            </div>

            <div>
                <a href="trends.php">
                    <i class="lni lni-graph"></i> Trends
                </a>
            </div>

            <div>
                <a href="wardrobe.php">
                    <i class="lni lni-archive"></i> Wardrobe
                </a>
            </div>

            <div>
                <a href="community.php">
                    <i class="lni lni-archive"></i> Community
                </a>
            </div>
        </div>
    </section>

    <?php if ($isAdmin): ?>
    <!-- Admin Services Section -->
    <section class="admin-section">
        <h2 class="section-title">Admin Services</h2>
        <div class="layout">
            <div>
                <a href="admin_users.php">
                    <i class="lni lni-users"></i> User Management
                </a>
            </div>
            
            <div>
                <a href="admin_products.php">
                    <i class="lni lni-shopping-basket"></i> Product Management
                </a>
            </div>
            
            <div>
                <a href="admin_dashboard.php">
                    <i class="lni lni-stats-up"></i> Dashboard
                </a>
            </div>

        </div>
    </section>
    <?php endif; ?>

    <!-- Navigation Buttons -->
    <section class="layout navigation-buttons">
        <div class="home-btn">
            <a href="../index.php">
                <i class="lni lni-home"></i> Home
            </a>
        </div>

        <div class="logout-btn">
            <a href="../actions/logout.php">
                <i class="lni lni-exit"></i> Logout
            </a>
        </div>
    </section>
</body>
</html>