<?php
session_start();
require_once '../db/config.php';

// Get guide type from URL
$guide_type = isset($_GET['type']) ? $_GET['type'] : '';

// Simulate guide data
function getGuideData($type) {
    $guides = [
        'hourglass' => [
            'title' => 'Hourglass Body Type Style Guide',
            'description' => 'Make the most of your balanced proportions with these style tips',
            'characteristics' => [
                'Shoulders align with hips',
                'Defined waistline',
                'Proportional top and bottom',
                'Curved hip line'
            ],
            'style_tips' => [
                'Emphasize your waist with fitted clothing',
                'Choose V-neck and scoop necklines',
                'Opt for wrap dresses and belted styles',
                'Try high-waisted bottoms'
            ],
            'what_to_wear' => [
                [
                    'image' => 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg',
                    'title' => 'Wrap Dresses',
                    'description' => 'Perfect for accentuating your waist'
                ],
                [
                    'image' => 'https://images.pexels.com/photos/1484808/pexels-photo-1484808.jpeg',
                    'title' => 'Fitted Blazers',
                    'description' => 'Creates a polished, structured look'
                ],
                [
                    'image' => 'https://images.pexels.com/photos/1485031/pexels-photo-1485031.jpeg',
                    'title' => 'High-Waisted Pants',
                    'description' => 'Elongates legs while defining waist'
                ]
            ],
            'what_to_avoid' => [
                'Boxy, shapeless garments',
                'Oversized clothing that hides your waist',
                'Bulky layers that add volume',
                'Unstructured pieces'
            ]
        ],
        'pear' => [
            'title' => 'Pear Body Type Style Guide',
            'description' => 'Balance your proportions and highlight your best features',
            'characteristics' => [
                'Shoulders narrower than hips',
                'Defined waist',
                'Fuller hips and thighs',
                'Proportionally smaller bust'
            ],
            'style_tips' => [
                'Draw attention to your upper body',
                'Choose A-line skirts and dresses',
                'Opt for darker colors on bottom',
                'Select structured shoulders'
            ],
            'what_to_wear' => [
                [
                    'image' => 'https://images.pexels.com/photos/1721558/pexels-photo-1721558.jpeg',
                    'title' => 'A-Line Skirts',
                    'description' => 'Flattering fit that skims over hips'
                ],
                [
                    'image' => 'https://images.pexels.com/photos/1759622/pexels-photo-1759622.jpeg',
                    'title' => 'Statement Tops',
                    'description' => 'Draws attention upward'
                ],
                [
                    'image' => 'https://images.pexels.com/photos/1040424/pexels-photo-1040424.jpeg',
                    'title' => 'Boot Cut Pants',
                    'description' => 'Creates balanced proportions'
                ]
            ],
            'what_to_avoid' => [
                'Skinny or tapered pants',
                'Clingy fabrics on bottom',
                'Heavy patterns on lower body',
                'Crop tops'
            ]
        ],
        
    
    
    // Add these entries inside the $guides array in getGuideData function
'apple' => [
    'title' => 'Apple Body Type Style Guide',
    'description' => 'Enhance your silhouette and create balanced proportions with these flattering styles',
    'characteristics' => [
        'Fuller midsection',
        'Broad shoulders',
        'Less defined waistline',
        'Slender legs'
    ],
    'style_tips' => [
        'Create vertical lines to elongate the body',
        'Choose flowing fabrics that don\'t cling',
        'Emphasize legs and arms',
        'Focus on structured pieces that create shape'
    ],
    'what_to_wear' => [
        [
            'image' => 'https://images.pexels.com/photos/1390600/pexels-photo-1390600.jpeg',
            'title' => 'Empire Line Dresses',
            'description' => 'Creates a high waistline and flattering flow'
        ],
        [
            'image' => 'https://images.pexels.com/photos/1808140/pexels-photo-1808140.jpeg',
            'title' => 'Open Necklines',
            'description' => 'Draws attention to your neckline and elongates'
        ],
        [
            'image' => 'https://images.pexels.com/photos/1642228/pexels-photo-1642228.jpeg',
            'title' => 'A-Line Skirts',
            'description' => 'Provides balance and comfortable fit'
        ]
    ],
    'what_to_avoid' => [
        'Clingy fabrics around the midsection',
        'Belts at the natural waistline',
        'Bulky materials that add volume',
        'Tight-fitting tops'
    ]
],
'rectangle' => [
    'title' => 'Rectangle Body Type Style Guide',
    'description' => 'Create curves and definition while celebrating your balanced proportions',
    'characteristics' => [
        'Straight up and down figure',
        'Similar measurements for shoulders, waist, and hips',
        'Athletic build',
        'Long, lean limbs'
    ],
    'style_tips' => [
        'Add curves with strategic styling',
        'Layer to create dimension',
        'Use belts to define the waist',
        'Mix fitted and loose pieces'
    ],
    'what_to_wear' => [
        [
            'image' => 'https://images.pexels.com/photos/1374910/pexels-photo-1374910.jpeg',
            'title' => 'Peplum Tops',
            'description' => 'Creates curves and defines waist'
        ],
        [
            'image' => 'https://images.pexels.com/photos/1755385/pexels-photo-1755385.jpeg',
            'title' => 'Wrap Dresses',
            'description' => 'Adds feminine curves to your silhouette'
        ],
        [
            'image' => 'https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg',
            'title' => 'Layered Looks',
            'description' => 'Creates visual interest and dimension'
        ]
    ],
    'what_to_avoid' => [
        'Shapeless, boxy garments',
        'Outfits without waist definition',
        'Overly baggy clothing',
        'Straight shift dresses'
    ]
]
    ];

    return isset($guides[$type]) ? $guides[$type] : null;
}

$guide = getGuideData($guide_type);

// If guide not found, redirect to trends page
if (!$guide) {
    header('Location: trends.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $guide['title']; ?> - StyleSense</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/style_guide.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="logo">StyleSense</div>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="services.php">Services</a>
            <a href="body_analysis.php">Body Analysis</a>
            <a href="wardrobe.php">My Wardrobe</a>
            <a href="style_tips.php">Style Tips</a>
            <a href="trends.php" class="active">Trends</a>
            <a href="outfit_builder.php">Outfit Builder</a>
            <a href="style_quiz.php">Style Quiz</a>
            <a href="color_palette.php">Color Palette</a>
        </div>
        <div class="user-menu">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'User'); ?></span>
            <a href="../actions/logout.php" class="logout-btn">Logout</a>
        </div>
    </nav>

    <main class="guide-container">
        <!-- Guide Header -->
        <header class="guide-header">
            <h1><?php echo $guide['title']; ?></h1>
            <p><?php echo $guide['description']; ?></p>
        </header>

        <!-- Characteristics Section -->
        <section class="guide-section">
            <h2>Body Characteristics</h2>
            <div class="characteristics-grid">
                <?php foreach ($guide['characteristics'] as $characteristic): ?>
                    <div class="characteristic-item">
                        <i class="fas fa-check-circle"></i>
                        <span><?php echo $characteristic; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Style Tips Section -->
        <section class="guide-section">
            <h2>Style Tips</h2>
            <div class="tips-grid">
                <?php foreach ($guide['style_tips'] as $tip): ?>
                    <div class="tip-item">
                        <i class="fas fa-star"></i>
                        <p><?php echo $tip; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- What to Wear Section -->
        <section class="guide-section">
            <h2>What to Wear</h2>
            <div class="wear-grid">
                <?php foreach ($guide['what_to_wear'] as $item): ?>
                    <div class="wear-item">
                        <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['title']; ?>">
                        <h3><?php echo $item['title']; ?></h3>
                        <p><?php echo $item['description']; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- What to Avoid Section -->
        <section class="guide-section">
            <h2>What to Avoid</h2>
            <div class="avoid-grid">
                <?php foreach ($guide['what_to_avoid'] as $item): ?>
                    <div class="avoid-item">
                        <i class="fas fa-times-circle"></i>
                        <span><?php echo $item; ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
</body>
</html>