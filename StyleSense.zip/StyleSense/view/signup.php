<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Define style options
$style_options = [
    'classic' => ['icon' => '👗', 'label' => 'Classic & Elegant'],
    'casual' => ['icon' => '👚', 'label' => 'Casual & Comfy'],
    'bold' => ['icon' => '💃', 'label' => 'Bold & Creative'],
    'minimalist' => ['icon' => '🎯', 'label' => 'Minimalist']
];

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $signup_error = '';
    // Add your signup logic here
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join StyleSense - Your Personal Fashion Guide</title>
    <link rel="stylesheet" href="../assets/css/main.css">
    <link rel="stylesheet" href="../assets/css/signup.css">
</head>
<body>
<div class="nav-links">
    <?php
    // Navigation links
    $nav_links = [
        'Home' => '../index.php',
        'About us' => 'aboutUs.php',  
        'Contact Us' => 'contactUs.php'  ];
    ?>
    </div>
    <nav class="navbar">
    <div class="logo">
        <i class="fas fa-tshirt"></i>
        <span>StyleSense</span>
    </div>
    <div class="nav-links">
        <?php foreach($nav_links as $title => $link): ?>
            <a href="<?php echo $link; ?>" <?php echo basename($_SERVER['PHP_SELF']) == basename($link) ? 'class="active"' : ''; ?>>
                <?php echo $title; ?>
            </a>
        <?php endforeach; ?>
    </div>
    <div class="auth-buttons">
        <a href="login.php" class="login-btn">Log in</a>
    </div>
</nav>
    <div class="signup-container">
        <div class="signup-wrapper">
            <div class="signup-visual">
                <div class="fashion-slideshow">
                    <!-- Animated fashion illustrations will be added via JS -->
                </div>
                <div class="testimonials-slider">
                    <!-- Dynamic testimonials will be added via JS -->
                </div>
            </div>
            
            <div class="signup-form-container">
                <div class="form-header">
                    <h2>Join StyleSense</h2>
                    <p>Start your style journey today!</p>
                </div>

                <?php if(isset($signup_error)): ?>
                    <div class="error-message">
                        <?php echo htmlspecialchars($signup_error); ?>
                    </div>
                <?php endif; ?>

                <form id="signupForm" class="signup-form" method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                    <div class="form-progress">
                        <?php
                        $steps = ['Profile', 'Style', 'Finish'];
                        foreach($steps as $index => $step):
                            $step_num = $index + 1;
                        ?>
                            <div class="progress-step <?php echo $step_num === 1 ? 'active' : ''; ?>" 
                                 data-step="<?php echo $step_num; ?>">
                                <?php echo $step; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Step 1: Basic Info -->
<div class="form-step" data-step="1">
    <div class="input-group">
        <input type="text" id="fullName" name="fullName" required 
               value="<?php echo $_POST['fullName'] ?? ''; ?>">
        <label for="fullName">Full Name</label>
        <div class="input-highlight"></div>
    </div>

    <div class="input-group">
        <input type="email" id="email" name="email" required
               value="<?php echo $_POST['email'] ?? ''; ?>">
        <label for="email">Email Address</label>
        <div class="input-highlight"></div>
    </div>

    <div class="input-group">
        <input type="password" id="password" name="password" required>
        <label for="password">Password</label>
        <div class="password-strength"></div>
        <div class="input-highlight"></div>
    </div>

    <div class="input-group">
        <input type="password" id="confirm_password" name="confirm_password" required>
        <label for="confirm_password">Confirm Password</label>
        <div class="input-highlight"></div>
    </div>

    <button type="button" class="next-btn">Next: Style Preferences</button>
</div>

                    <!-- Step 2: Style Preferences -->
                    <div class="form-step" data-step="2" style="display: none;">
                        <div class="style-preferences">
                            <h3>What's your style vibe?</h3>
                            <div class="style-options">
                                <?php foreach($style_options as $value => $style): ?>
                                    <div class="style-option">
                                        <input type="checkbox" id="style_<?php echo $value; ?>" 
                                               name="style[]" value="<?php echo $value; ?>"
                                               <?php echo isset($_POST['style']) && in_array($value, $_POST['style']) ? 'checked' : ''; ?>>
                                        <label for="style_<?php echo $value; ?>">
                                            <span class="style-icon"><?php echo $style['icon']; ?></span>
                                            <?php echo $style['label']; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="navigation-buttons">
                            <button type="button" class="back-btn">Back</button>
                            <button type="button" class="next-btn">Final Step</button>
                        </div>
                    </div>

                    <!-- Step 3: Finishing Up -->
                    <div class="form-step" data-step="3" style="display: none;">
                        <div class="preferences">
                            <h3>Customize Your Experience</h3>
                            
                            <div class="preference-option">
                                <label>
                                    <input type="checkbox" name="notifications" checked>
                                    Receive style tips & updates
                                </label>
                            </div>
                            
                            <div class="preference-option">
                                <label>
                                    <input type="checkbox" name="personalization" checked>
                                    Allow personalized recommendations
                                </label>
                            </div>
                        </div>

                        <div class="terms">
                            <label>
                                <input type="checkbox" name="terms" required>
                                I agree to the <a href="#">Terms & Conditions</a>
                            </label>
                        </div>

                        <div class="navigation-buttons">
                            <button type="button" class="back-btn">Back</button>
                            <button type="submit" class="submit-btn">Create Account</button>
                        </div>
                    </div>
                </form>

                <div class="social-signup">
                    <span>Or sign up with</span>
                    <div class="social-buttons">
                        <button type="button" onclick="socialSignup('google')" class="google-btn">Google</button>
                        <button type="button" onclick="socialSignup('facebook')" class="facebook-btn">Facebook</button>
                    </div>
                </div>

                <div class="login-link">
                    Already have an account? <a href="login.php">Log in</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Pass any PHP variables needed in JavaScript
        const formData = <?php echo json_encode([
            'steps' => $steps,
            'styleOptions' => $style_options
        ]); ?>;
    </script>
    <script src="../assets/js/signup.js"></script>
</body>
</html>