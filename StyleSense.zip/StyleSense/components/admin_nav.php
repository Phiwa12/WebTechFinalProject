<?php
// components/admin_nav.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current page for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>

<nav class="admin-navbar">
    <div class="nav-left">
        <div class="logo">StyleSense</div>
        <div class="nav-links">
            <a href="../index.php" class="nav-link">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="services.php" class="nav-link">
                <i class="fas fa-concierge-bell"></i> Services
            </a>
            <a href="admin_dashboard.php" class="nav-link <?php echo $current_page === 'admin_dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-chart-line"></i> Dashboard
            </a>
            <a href="admin_products.php" class="nav-link <?php echo $current_page === 'admin_products.php' ? 'active' : ''; ?>">
                <i class="fas fa-box"></i> Products
            </a>
            <?php if (isSuperAdmin()): ?>
            <a href="admin_users.php" class="nav-link <?php echo $current_page === 'admin_users.php' ? 'active' : ''; ?>">
                <i class="fas fa-users-cog"></i> Users
            </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="nav-right">
        <div class="welcome-message">
            <i class="fas fa-user-circle"></i>
            Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Admin'); ?>
        </div>
        <a href="../actions/logout.php" class="logout-btn">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>
</nav>