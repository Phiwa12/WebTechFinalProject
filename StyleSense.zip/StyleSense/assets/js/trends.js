// public-trends.js
class PublicTrendsManager {
    constructor() {
        this.currentFilter = 'all';
        this.trends = [];
        this.isLoading = false;
        this.init();
    }

    init() {
        this.loadTrends();
        this.attachEventListeners();
        this.initializeAccessibility();
    }

    attachEventListeners() {
        // Filter pills
        document.querySelectorAll('.filter-pill').forEach(pill => {
            pill.addEventListener('click', () => this.handleFilter(pill));
            // Keyboard navigation
            pill.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.handleFilter(pill);
                }
            });
        });

        // Newsletter form
        const newsletterForm = document.querySelector('.newsletter-form');
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', (e) => this.handleNewsletterSignup(e));
        }

        // Add resize observer for responsive adjustments
        this.setupResizeObserver();
    }

    initializeAccessibility() {
        // Add ARIA labels and roles
        document.querySelectorAll('.trend-card').forEach(card => {
            card.setAttribute('role', 'article');
            card.setAttribute('tabindex', '0');
        });

        // Add keyboard navigation for interactive elements
        this.setupKeyboardNavigation();

        // Add screen reader announcements
        this.setupScreenReaderAnnouncements();

        // Setup focus trap for modals
        this.setupFocusTraps();
    }

    setupKeyboardNavigation() {
        const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                this.handleTabNavigation(e);
            }
        });
    }

    async loadTrends() {
        try {
            this.isLoading = true;
            this.showLoadingState();

            // Simulate API call
            const response = await this.fetchTrends();
            this.trends = response.trends;
            this.renderTrends();

        } catch (error) {
            this.showError('Failed to load trends. Please try again later.');
        } finally {
            this.isLoading = false;
            this.hideLoadingState();
        }
    }

    async fetchTrends() {
        // Simulating API call
        return new Promise(resolve => {
            setTimeout(() => {
                resolve({
                    trends: Array.from({ length: 12 }, (_, i) => ({
                        id: i + 1,
                        title: `Trend ${i + 1}`,
                        description: `Description for trend ${i + 1}`,
                        image: `https://picsum.photos/500/300?random=${i}`,
                        category: this.getRandomCategory(),
                        tags: this.getRandomTags(),
                        accessibility: {
                            imageAlt: `Fashion trend example ${i + 1}`,
                            description: `Detailed description for screen readers about trend ${i + 1}`
                        }
                    }))
                });
            }, 1000);
        });
    }

    renderTrends() {
        const grid = document.querySelector('.trends-grid');
        const filteredTrends = this.getFilteredTrends();

        grid.innerHTML = filteredTrends.map(trend => `
            <article class="trend-card" 
                     role="article" 
                     tabindex="0"
                     aria-labelledby="trend-title-${trend.id}">
                <div class="trend-image" 
                     style="background-image: url('${trend.image}')"
                     role="img" 
                     aria-label="${trend.accessibility.imageAlt}">
                </div>
                <div class="trend-content">
                    <h3 id="trend-title-${trend.id}">${trend.title}</h3>
                    <div class="trend-tags" role="list">
                        ${trend.tags.map(tag => `
                            <span class="trend-tag" role="listitem">${tag}</span>
                        `).join('')}
                    </div>
                    <p>${trend.description}</p>
                    <button class="learn-more-btn" 
                            aria-label="Learn more about ${trend.title}">
                        Learn More
                    </button>
                </div>
            </article>
        `).join('');

        // Announce to screen readers
        this.announceToScreenReader(`Loaded ${filteredTrends.length} trends`);
    }

    handleFilter(pill) {
        // Remove active class from all pills
        document.querySelectorAll('.filter-pill').forEach(p => {
            p.classList.remove('active');
            p.setAttribute('aria-pressed', 'false');
        });

        // Add active class to clicked pill
        pill.classList.add('active');
        pill.setAttribute('aria-pressed', 'true');

        this.currentFilter = pill.dataset.filter;
        this.renderTrends();
    }

    async handleNewsletterSignup(e) {
        e.preventDefault();
        const form = e.target;
        const email = form.querySelector('input[type="email"]').value;

        try {
            // Simulate API call
            await this.submitNewsletter(email);
            this.showSuccess('Successfully subscribed to newsletter!');
            form.reset();
        } catch (error) {
            this.showError('Failed to subscribe. Please try again.');
        }
    }

    showLoadingState() {
        // Add loading indicator
        const grid = document.querySelector('.trends-grid');
        grid.setAttribute('aria-busy', 'true');
        grid.innerHTML = `
            <div class="loading-spinner" role="status">
                <span class="sr-only">Loading trends...</span>
            </div>
        `;
    }

    hideLoadingState() {
        const grid = document.querySelector('.trends-grid');
        grid.setAttribute('aria-busy', 'false');
    }

    announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('role', 'status');
        announcement.setAttribute('aria-live', 'polite');
        announcement.className = 'sr-only';
        announcement.textContent = message;
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }

    setupResizeObserver() {
        const resizeObserver = new ResizeObserver(entries => {
            for (const entry of entries) {
                this.handleResponsiveLayout(entry.contentRect.width);
            }
        });

        resizeObserver.observe(document.querySelector('.trends-container'));
    }

    handleResponsiveLayout(width) {
        const container = document.querySelector('.trends-container');
        if (width < 768) {
            container.classList.add('mobile-layout');
            this.adjustForMobileLayout();
        } else {
            container.classList.remove('mobile-layout');
            this.adjustForDesktopLayout();
        }
    }

    adjustForMobileLayout() {
        // Adjust card layouts for better mobile experience
        document.querySelectorAll('.trend-card').forEach(card => {
            card.classList.add('mobile-view');
        });

        // Make quick filters scrollable horizontally
        const filterContainer = document.querySelector('.quick-filters');
        filterContainer.style.overflowX = 'auto';
        filterContainer.style.webkitOverflowScrolling = 'touch';
    }

    adjustForDesktopLayout() {
        document.querySelectorAll('.trend-card').forEach(card => {
            card.classList.remove('mobile-view');
        });
    }

    setupFocusTraps() {
        document.querySelectorAll('.modal').forEach(modal => {
            const focusableElements = modal.querySelectorAll(
                'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
            );
            const firstFocusable = focusableElements[0];
            const lastFocusable = focusableElements[focusableElements.length - 1];

            modal.addEventListener('keydown', e => {
                if (e.key === 'Tab') {
                    if (e.shiftKey) {
                        if (document.activeElement === firstFocusable) {
                            lastFocusable.focus();
                            e.preventDefault();
                        }
                    } else {
                        if (document.activeElement === lastFocusable) {
                            firstFocusable.focus();
                            e.preventDefault();
                        }
                    }
                }
            });
        });
    }

    initializeSeasonalContent() {
        const currentSeason = this.getCurrentSeason();
        this.loadSeasonalTrends(currentSeason);
        this.updateSeasonalBanner(currentSeason);
    }

    getCurrentSeason() {
        const month = new Date().getMonth();
        if (month >= 2 && month <= 4) return 'spring';
        if (month >= 5 && month <= 7) return 'summer';
        if (month >= 8 && month <= 10) return 'fall';
        return 'winter';
    }

    loadSeasonalTrends(season) {
        const carousel = document.querySelector('.season-carousel');
        // Simulate seasonal trends data
        const seasonalTrends = this.getSeasonalTrends(season);
        
        carousel.innerHTML = seasonalTrends.map(trend => `
            <div class="seasonal-card" 
                 role="article" 
                 tabindex="0"
                 aria-label="${trend.title} - ${trend.description}">
                <img src="${trend.image}" 
                     alt="${trend.accessibility.imageAlt}" 
                     loading="lazy">
                <div class="seasonal-content">
                    <h3>${trend.title}</h3>
                    <p>${trend.description}</p>
                    <button class="view-details-btn" 
                            aria-label="View details for ${trend.title}">
                        View Details
                    </button>
                </div>
            </div>
        `).join('');
    }

    initializeStyleGuides() {
        document.querySelectorAll('.guide-card').forEach(card => {
            card.addEventListener('click', () => this.showStyleGuide(card.dataset.bodyType));
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.showStyleGuide(card.dataset.bodyType);
                }
            });
        });
    }

    showStyleGuide(bodyType) {
        // Simulate loading style guide content
        this.showLoadingState();
        setTimeout(() => {
            const guideContent = this.getStyleGuideContent(bodyType);
            this.renderStyleGuide(guideContent);
            this.hideLoadingState();
        }, 500);
    }

    initializeStyleTips() {
        const tipCards = document.querySelectorAll('.tip-card');
        tipCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
                    card.style.transform = 'translateY(-5px)';
                }
            });
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0)';
            });
        });
    }

    handleNewsletterSubscription(email) {
        // Show loading state
        const form = document.querySelector('.newsletter-form');
        const submitBtn = form.querySelector('button');
        const originalText = submitBtn.textContent;
        submitBtn.innerHTML = '<span class="spinner"></span> Subscribing...';
        submitBtn.disabled = true;

        // Simulate API call
        setTimeout(() => {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            this.showSuccess('Successfully subscribed to newsletter!');
            form.reset();
        }, 1500);
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.setAttribute('role', 'alert');
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                <span>${message}</span>
            </div>
            <button class="notification-close" aria-label="Close notification">
                <i class="fas fa-times"></i>
            </button>
        `;

        document.body.appendChild(notification);
        setTimeout(() => notification.classList.add('show'), 10);

        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        });

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // Utility Methods
    getRandomCategory() {
        const categories = ['casual', 'formal', 'seasonal', 'accessories'];
        return categories[Math.floor(Math.random() * categories.length)];
    }

    getRandomTags() {
        const allTags = ['trending', 'popular', 'new', 'classic', 'modern', 'sustainable'];
        return allTags.filter(() => Math.random() > 0.5).slice(0, 3);
    }

    getFilteredTrends() {
        return this.trends.filter(trend => 
            this.currentFilter === 'all' || trend.category === this.currentFilter
        );
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.trendsManager = new PublicTrendsManager();

    // Check for user preferences
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        document.body.classList.add('reduced-motion');
    }

    if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
        document.body.classList.add('dark-theme');
    }
});

// Handle user preference changes
window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', e => {
    document.body.classList.toggle('reduced-motion', e.matches);
});

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
    document.body.classList.toggle('dark-theme', e.matches);
});