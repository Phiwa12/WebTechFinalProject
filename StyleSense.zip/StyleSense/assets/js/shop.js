class ShopManager {
    constructor() {
        this.init();
    }

    init() {
        this.loadCart();
        this.attachEventListeners();
    }

    attachEventListeners() {
        // Cart toggle
        document.getElementById('cartIcon').addEventListener('click', () => this.toggleCart());
        document.getElementById('closeCart').addEventListener('click', () => this.toggleCart());

        // Add to cart buttons
        document.querySelectorAll('.add-to-cart-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.addToCart(e.target.dataset.id);
            });
        });

        const checkoutBtn = document.querySelector('.checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => this.processCheckout());
    }

        // Cart quantity buttons
        document.querySelectorAll('.quantity-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = e.target.dataset.id;
                if (e.target.classList.contains('plus')) {
                    this.updateQuantity(productId, 1);
                } else {
                    this.updateQuantity(productId, -1);
                }
            });
        });

        // Remove from cart buttons
        document.querySelectorAll('.cart-item-remove').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.removeFromCart(e.target.closest('.cart-item-remove').dataset.id);
            });
        });

        // Filter form
        const filterForm = document.getElementById('filterForm');
        if (filterForm) {
            filterForm.addEventListener('submit', (e) => this.handleFilterSubmit(e));
        }
    }

    async loadCart() {
        try {
            const response = await fetch('../actions/cart_actions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get'
                })
            });

            const data = await response.json();
            if (data.success) {
                this.updateCartUI(data.cart);
            }
        } catch (error) {
            console.error('Error loading cart:', error);
        }
    }

    
async addToCart(productId) {
        try {
            const response = await fetch('../actions/cart_actions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'add',
                    product_id: productId
                })
            });

            const data = await response.json();
            if (data.success) {
                this.updateCartUI(data.cart);
                this.showNotification('Added to cart!', 'success');
            } else {
                throw new Error(data.message || 'Failed to add to cart');
            }
        } catch (error) {
            this.showNotification(error.message || 'Failed to add item to cart', 'error');
        }
    }

    async updateQuantity(productId, change) {
        try {
            const response = await fetch('../actions/cart_actions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'update',
                    product_id: productId,
                    change: change
                })
            });

            const data = await response.json();
            if (data.success) {
                this.updateCartUI(data.cart);
            } else {
                throw new Error(data.message || 'Failed to update quantity');
            }
        } catch (error) {
            this.showNotification(error.message || 'Failed to update quantity', 'error');
        }
    }

    async removeFromCart(productId) {
        try {
            const response = await fetch('../actions/cart_actions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'remove',
                    product_id: productId
                })
            });

            const data = await response.json();
            if (data.success) {
                this.updateCartUI(data.cart);
                this.showNotification('Item removed from cart', 'success');
            } else {
                throw new Error(data.message || 'Failed to remove item');
            }
        } catch (error) {
            this.showNotification(error.message || 'Failed to remove item', 'error');
        }
    }

    

    updateCartUI(cart) {
        const cartItems = document.getElementById('cartItems');
        const cartCount = document.querySelector('.cart-count');
        
        // Update cart count
        cartCount.textContent = cart.length;
        
        // Update cart items
        if (cart.length === 0) {
            cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
            document.querySelector('.cart-total .total-amount').textContent = '$0.00';
            return;
        }

        cartItems.innerHTML = cart.map(item => `
            <div class="cart-item">
                <div class="cart-item-image">
                    <img src="${item.image_url}" alt="${item.name}">
                </div>
                <div class="cart-item-details">
                    <div class="cart-item-title">${item.name}</div>
                    <div class="cart-item-price">$${parseFloat(item.price).toFixed(2)}</div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn minus" data-id="${item.product_id}">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn plus" data-id="${item.product_id}">+</button>
                    </div>
                </div>
                <button class="cart-item-remove" data-id="${item.product_id}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');

        // Update total
        const total = cart.reduce((sum, item) => sum + (parseFloat(item.price) * item.quantity), 0);
        document.querySelector('.cart-total .total-amount').textContent = `$${total.toFixed(2)}`;

        // Reattach event listeners
        this.attachEventListeners();
    }

    toggleCart() {
        const cartSidebar = document.getElementById('cartSidebar');
        const isOpening = !cartSidebar.classList.contains('active');
        
        cartSidebar.classList.toggle('active');
        
        // Reload cart contents when opening the cart
        if (isOpening) {
            this.loadCart();
        }
    }

    handleFilterSubmit(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const queryString = new URLSearchParams(formData).toString();
        window.location.href = `../view/shop.php?${queryString}`;
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            <span>${message}</span>
        `;

        document.body.appendChild(notification);
        setTimeout(() => notification.classList.add('show'), 10);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Add to ShopManager class
async processCheckout() {
    try {
        const response = await fetch('../actions/checkout_process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();
        if (data.success) {
            // Show success modal
            this.showCheckoutSuccess(data.itemCount);
        } else {
            throw new Error(data.message || 'Checkout failed');
        }
    } catch (error) {
        this.showNotification(error.message, 'error');
    }
}

showCheckoutSuccess(itemCount) {
    // Create modal element
    const modal = document.createElement('div');
    modal.className = 'checkout-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <h2>Thank You!</h2>
            <p>${itemCount} item${itemCount !== 1 ? 's' : ''} successfully added to your wardrobe!</p>
            <div class="modal-buttons">
                <a href="wardrobe.php" class="view-wardrobe-btn">View Wardrobe</a>
                <button class="continue-shopping-btn">Continue Shopping</button>
            </div>
        </div>
    `;

    // Add event listeners
    const continueBtn = modal.querySelector('.continue-shopping-btn');
    continueBtn.addEventListener('click', () => {
        modal.remove();
        this.toggleCart(); // Close cart sidebar
    });

    // Add modal to page
    document.body.appendChild(modal);

    // Update cart count
    document.querySelector('.cart-count').textContent = '0';
    // Clear cart UI
    document.getElementById('cartItems').innerHTML = '<p class="empty-cart">Your cart is empty</p>';
    document.querySelector('.total-amount').textContent = '$0.00';
}
}

// Initialize shop
document.addEventListener('DOMContentLoaded', () => {
    window.shopManager = new ShopManager();
});

