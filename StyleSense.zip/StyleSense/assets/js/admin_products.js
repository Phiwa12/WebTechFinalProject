// Remove the products declaration at the top since it's now handled in the PHP file
document.addEventListener('DOMContentLoaded', function() {
    // Search Functionality
    document.getElementById('productSearch').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('.data-table tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });

    // Initialize any tooltips or other UI elements
    const colorInput = document.getElementById('color');
    if (colorInput) {
        colorInput.addEventListener('change', () => handleColorChange(colorInput));
    }

    const imageUrlInput = document.getElementById('image_url');
    if (imageUrlInput) {
        imageUrlInput.addEventListener('change', () => handleImageUrlChange(imageUrlInput));
    }
});

// Make functions global by attaching to window
window.showAddProductModal = function() {
    document.getElementById('modalTitle').textContent = 'Add New Product';
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('productModal').style.display = 'flex';
};

window.editProduct = function(productId) {
    // Convert productId to number for consistent comparison
    const numericId = parseInt(productId);
    const product = window.products.find(p => parseInt(p.id) === numericId);
    
    console.log('Product ID:', numericId);
    console.log('Found Product:', product);
    
    if (!product) {
        console.error('Product not found:', productId);
        return;
    }

    try {
        // Set modal title
        document.getElementById('modalTitle').textContent = 'Edit Product';
        
        // Set form values
        document.getElementById('productId').value = product.id;
        document.getElementById('name').value = product.name || '';
        document.getElementById('description').value = product.description || '';
        document.getElementById('price').value = product.price || 0;
        document.getElementById('category').value = product.category || 'tops';
        document.getElementById('type').value = product.type || 'casual';
        document.getElementById('color').value = product.color || '#000000';
        document.getElementById('image_url').value = product.image_url || '';

        // Preview image if exists
        const previewImg = document.getElementById('productImagePreview');
        if (previewImg) {
            previewImg.src = product.image_url || '';
            previewImg.style.display = product.image_url ? 'block' : 'none';
        }

        // Preview color if exists
        const colorPreview = document.getElementById('colorPreview');
        if (colorPreview) {
            colorPreview.style.backgroundColor = product.color || '#000000';
        }

        // Show modal
        document.getElementById('productModal').style.display = 'flex';
    } catch (error) {
        console.error('Error setting form values:', error);
        showNotification('Error loading product details', 'error');
    }
};

window.deleteProduct = async function(productId) {
    if (!confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
        return;
    }

    try {
        const response = await fetch('../actions/delete_product.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ product_id: productId })
        });

        const data = await response.json();

        if (data.success) {
            showNotification('Product deleted successfully', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification(data.message || 'Error deleting product', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Failed to delete product', 'error');
    }
};


window.closeModal = function() {
    document.getElementById('productModal').style.display = 'none';
    document.getElementById('productForm').reset();
};

window.handleSubmit = async function(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    const isEdit = formData.get('id') !== '';

    try {
        const response = await fetch('../actions/update_product.php', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            showNotification(`Product ${isEdit ? 'updated' : 'added'} successfully`, 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            showNotification(data.message || 'Error saving product', 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Failed to save product', 'error');
    }

    return false;
};

// Helper functions
function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function handleImageUrlChange(input) {
    const previewImg = document.getElementById('productImagePreview');
    if (previewImg && input.value) {
        previewImg.src = input.value;
        previewImg.style.display = 'block';
    }
}

function handleColorChange(input) {
    const previewColor = document.getElementById('colorPreview');
    if (previewColor) {
        previewColor.style.backgroundColor = input.value;
    }
}

// Event Listeners
window.onclick = function(event) {
    const modal = document.getElementById('productModal');
    if (event.target === modal) {
        closeModal();
    }
};

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
    }
});