// Initialize users data
let users = [];

document.addEventListener('DOMContentLoaded', function() {
    console.log('Admin users script loaded');
    
    // Store users data globally if available
    if (typeof window.users !== 'undefined') {
        users = window.users;
        console.log('Users data loaded:', users);
    } else {
        console.error('Users data not available');
    }

    // Initialize all event listeners
    initializeEventListeners();
});

function initializeEventListeners() {
    // Edit button listeners
    document.querySelectorAll('.edit-user-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const userId = parseInt(this.getAttribute('data-userid'));
            if (userId) {
                editUser(userId);
            }
        });
    });

    // Delete button listeners
    document.querySelectorAll('.delete-user-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const userId = parseInt(this.getAttribute('data-userid'));
            if (userId) {
                deleteUser(userId);
            }
        });
    });

    // Search functionality
    const searchInput = document.getElementById('userSearch');
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }

    // Modal close handlers
    const modal = document.getElementById('userModal');
    if (modal) {
        // Close on clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        // Close on ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    }

    // Form submit handler
    const form = document.getElementById('userForm');
    if (form) {
        form.addEventListener('submit', handleSubmit);
    }
}

function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.data-table tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function showAddUserModal() {
    const modal = document.getElementById('userModal');
    const form = document.getElementById('userForm');
    const modalTitle = document.getElementById('modalTitle');
    
    if (!modal || !form || !modalTitle) {
        showNotification('Error loading modal', 'error');
        return;
    }

    modalTitle.textContent = 'Add New User';
    form.reset();
    document.getElementById('userId').value = '';
    modal.style.display = 'flex';
}

function editUser(userId) {
    console.log('Editing user with ID:', userId);
    console.log('Available users:', users);

    if (!userId || !users) {
        showNotification('Error: Invalid user data', 'error');
        return;
    }

    // Convert userId to string for comparison if needed
    const user = users.find(u => parseInt(u.id) === userId);
    console.log('Found user:', user);

    if (!user) {
        showNotification('Error: User not found', 'error');
        return;
    }

    try {
        const modal = document.getElementById('userModal');
        const modalTitle = document.getElementById('modalTitle');
        
        if (!modal || !modalTitle) {
            throw new Error('Modal elements not found');
        }

        // Set form values
        modalTitle.textContent = 'Edit User';
        document.getElementById('userId').value = user.id;
        document.getElementById('fullName').value = user.full_name || '';
        document.getElementById('email').value = user.email || '';
        document.getElementById('role').value = user.role || 'user';
        document.getElementById('status').value = user.status || 'active';
        document.getElementById('password').value = '';

        modal.style.display = 'flex';
    } catch (error) {
        console.error('Error in editUser:', error);
        showNotification('Error loading user data', 'error');
    }
}

function closeModal() {
    const modal = document.getElementById('userModal');
    const form = document.getElementById('userForm');
    
    if (modal && form) {
        modal.style.display = 'none';
        form.reset();
    }
}

async function handleSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const isEdit = formData.get('id') !== '';

    try {
        const response = await fetch('../actions/update_user.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
            showNotification(`User ${isEdit ? 'updated' : 'added'} successfully`, 'success');
            setTimeout(() => window.location.reload(), 1500);
        } else {
            throw new Error(data.message || 'Error saving user');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification(error.message || 'Failed to save user', 'error');
    }
}

async function deleteUser(userId) {
    if (!userId) {
        showNotification('Invalid user ID', 'error');
        return;
    }

    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
        return;
    }

    try {
        const response = await fetch('../actions/delete_user.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ user_id: userId })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        if (data.success) {
            showNotification('User deleted successfully', 'success');
            setTimeout(() => window.location.reload(), 1500);
        } else {
            throw new Error(data.message || 'Error deleting user');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification(error.message || 'Failed to delete user', 'error');
    }
}

function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create new notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(notification);
    
    // Remove notification after delay
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}