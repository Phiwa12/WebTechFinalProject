class WardrobeManager {
    constructor() {
        this.init();
    }

    init() {
        this.attachEventListeners();
    }

    attachEventListeners() {
        // Delete buttons
        document.querySelectorAll('.delete-item-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.deleteItem(e.target.closest('.delete-item-btn').dataset.id);
            });
        });
    }

    async deleteItem(itemId) {
        if (!confirm('Are you sure you want to delete this item?')) {
            return;
        }

        try {
            const response = await fetch('../actions/delete_wardrobe_item.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ item_id: itemId })
            });

            const data = await response.json();
            if (data.success) {
                this.showNotification('Item deleted successfully', 'success');
                // Remove the item from the DOM
                document.querySelector(`.wardrobe-item[data-id="${itemId}"]`).remove();
                // Update stats
                this.updateStats();
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            this.showNotification(error.message, 'error');
        }
    }

    updateStats() {
        // Get current item count
        const itemCount = document.querySelectorAll('.wardrobe-item').length;
        
        // Update total items stat
        const totalStat = document.querySelector('.stat-card:first-child .stat-info p');
        if (totalStat) {
            totalStat.textContent = itemCount;
        }

        // Update category stats
        const categories = ['tops', 'bottoms', 'dresses', 'shoes', 'accessories', 'outerwear'];
        categories.forEach(category => {
            const count = document.querySelectorAll(`.wardrobe-item[data-category="${category}"]`).length;
            const statElement = document.querySelector(`.stat-card[data-category="${category}"] .stat-info p`);
            if (statElement) {
                statElement.textContent = count;
            }
        });

        // If no items left, show empty state
        if (itemCount === 0) {
            const itemsGrid = document.querySelector('.items-grid');
            itemsGrid.innerHTML = `
                <div class="no-items">
                    <i class="fas fa-tshirt"></i>
                    <p>Your wardrobe is empty! Visit the shop to add items.</p>
                    <a href="shop.php" class="shop-btn">Go to Shop</a>
                </div>
            `;
        }
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            <span>${message}</span>
        `;

        document.body.appendChild(notification);
        setTimeout(() => notification.classList.add('show'), 10);
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Initialize wardrobe
document.addEventListener('DOMContentLoaded', () => {
    window.wardrobeManager = new WardrobeManager();
});