class OutfitBuilder {
    constructor() {
        console.log('Initializing OutfitBuilder');
        this.currentOutfit = new Map();
        this.apiBasePath = this.determineApiBasePath();
        this.init();
    }

    determineApiBasePath() {
        const pathParts = window.location.pathname.split('/');
        const styleSenseIndex = pathParts.indexOf('StyleSense');
        if (styleSenseIndex !== -1) {
            return pathParts.slice(0, styleSenseIndex + 1).join('/') + '/actions';
        }
        return '/actions'; // Fallback
    }

    init() {
        this.initializeTabs();
        this.initializeDragAndDrop();
        this.setupEventListeners();
    }

    initializeTabs() {
        document.querySelectorAll('.category-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.category-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                
                document.querySelectorAll('.category-items').forEach(items => {
                    items.style.display = 'none';
                });
                
                const categoryId = tab.dataset.category;
                const categoryItems = document.getElementById(`${categoryId}-items`);
                if (categoryItems) {
                    categoryItems.style.display = 'grid';
                }
            });
        });
    }

    initializeDragAndDrop() {
        // Make items draggable
        document.querySelectorAll('.wardrobe-item').forEach(item => {
            if (!item.dataset.itemId || !item.dataset.category) {
                console.error('Missing required data attributes on wardrobe item:', item);
                return;
            }

            item.addEventListener('dragstart', (e) => {
                const itemData = {
                    id: item.dataset.itemId,
                    category: item.dataset.category,
                    name: item.querySelector('.item-name')?.textContent,
                    imageUrl: item.querySelector('img')?.src
                };
                
                e.dataTransfer.setData('application/json', JSON.stringify(itemData));
                item.classList.add('dragging');
            });

            item.addEventListener('dragend', (e) => {
                e.target.classList.remove('dragging');
            });
        });

        // Setup drop zones
        document.querySelectorAll('.zone-content').forEach(zone => {
            if (!zone.dataset.zone) {
                console.error('Missing zone data attribute on drop zone:', zone);
                return;
            }

            zone.addEventListener('dragover', (e) => {
                e.preventDefault();
                zone.classList.add('drag-over');
            });

            zone.addEventListener('dragleave', (e) => {
                zone.classList.remove('drag-over');
            });

            zone.addEventListener('drop', (e) => {
                e.preventDefault();
                zone.classList.remove('drag-over');

                try {
                    const data = JSON.parse(e.dataTransfer.getData('application/json'));
                    const targetZone = zone.dataset.zone;

                    if (data.category !== targetZone) {
                        this.showNotification(`This item belongs in the ${data.category} section`, 'error');
                        return;
                    }

                    this.addItemToOutfit(data, targetZone, zone);
                } catch (error) {
                    console.error('Drop error:', error);
                    this.showNotification('Error adding item to outfit', 'error');
                }
            });
        });
    }

    setupEventListeners() {
        const saveButton = document.getElementById('saveOutfit');
        if (saveButton) {
            saveButton.addEventListener('click', () => {
                if (this.validateOutfit()) {
                    document.getElementById('saveOutfitModal').style.display = 'flex';
                } else {
                    this.showNotification('Please complete your outfit before saving (top/dress, bottom, shoes)', 'error');
                }
            });
        }

        const clearButton = document.getElementById('clearOutfit');
        if (clearButton) {
            clearButton.addEventListener('click', () => {
                if (confirm('Are you sure you want to clear the outfit?')) {
                    this.clearOutfit();
                }
            });
        }

        const form = document.getElementById('saveOutfitForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveOutfit(e.target);
            });
        }

        // Modal close buttons
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                const modal = btn.closest('.modal');
                if (modal) {
                    modal.style.display = 'none';
                }
            });
        });

        // View outfit modal
        const viewOutfitModal = document.getElementById('viewOutfitModal');
        if (viewOutfitModal) {
            viewOutfitModal.querySelector('.close-modal')?.addEventListener('click', () => {
                viewOutfitModal.style.display = 'none';
            });
        }
    }

    async addItemToOutfit(itemData, category, zone) {
        try {
            console.log('Attempting to add item:', { itemId: itemData.id, category });

            const response = await fetch(`${this.apiBasePath}/outfit_actions.php?action=get_item&id=${itemData.id}`);
            console.log('API Response status:', response.status);
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error('API Error Response:', errorText);
                throw new Error(`Server responded with ${response.status}: ${errorText}`);
            }
            
            const data = await response.json();
            console.log('API Response data:', data);

            if (!data.success) {
                throw new Error(data.message || 'Failed to get item data');
            }

            if (!this.currentOutfit.has(category)) {
                this.currentOutfit.set(category, new Set());
            }

            const items = this.currentOutfit.get(category);
            const isDuplicate = Array.from(items).some(item => item.id === data.item.id);
            
            if (isDuplicate) {
                this.showNotification('This item is already in your outfit', 'warning');
                return;
            }

            items.add(data.item);
            this.renderZone(category, zone);
            this.updateOutfitSummary();
            
        } catch (error) {
            console.error('Error adding item:', error);
            this.showNotification(`Failed to add item: ${error.message}`, 'error');
        }
    }

    removeItem(category, itemId) {
        const items = this.currentOutfit.get(category);
        if (items) {
            const itemToRemove = Array.from(items).find(item => item.id === parseInt(itemId));
            if (itemToRemove) {
                items.delete(itemToRemove);
                if (items.size === 0) {
                    this.currentOutfit.delete(category);
                }
                
                const zone = document.querySelector(`.zone-content[data-zone="${category}"]`);
                if (zone) {
                    this.renderZone(category, zone);
                    this.updateOutfitSummary();
                }
            }
        }
    }

    renderZone(category, zone) {
        const items = this.currentOutfit.get(category);
        
        if (!items || items.size === 0) {
            zone.innerHTML = `
                <div class="zone-placeholder">
                    Drop ${category} here
                </div>
            `;
            return;
        }

        zone.innerHTML = Array.from(items).map(item => `
            <div class="placed-item" data-item-id="${item.id}">
                <img src="${this.escapeHtml(item.image_url)}" alt="${this.escapeHtml(item.name)}">
                <div class="item-info">
                    <span class="item-name">${this.escapeHtml(item.name)}</span>
                    <button class="remove-item" onclick="outfitBuilder.removeItem('${category}', ${item.id})">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    updateOutfitSummary() {
        this.updateColorHarmony();
        this.updateMissingItems();
    }

    updateColorHarmony() {
        const colors = new Set();
        this.currentOutfit.forEach(items => {
            items.forEach(item => {
                if (item.color) colors.add(item.color);
            });
        });

        const colorPreview = document.querySelector('.color-preview');
        if (colorPreview) {
            colorPreview.innerHTML = Array.from(colors).map(color => `
                <div class="color-swatch" style="background-color: ${this.escapeHtml(color)}"></div>
            `).join('');
        }
    }

    updateMissingItems() {
        const hasDress = this.currentOutfit.has('dresses');
        const hasTop = this.currentOutfit.has('tops');
        const hasBottom = this.currentOutfit.has('bottoms');
        const hasShoes = this.currentOutfit.has('shoes');
        
        const missingItems = [];
        if (!hasDress) {
            if (!hasTop) missingItems.push('Top');
            if (!hasBottom) missingItems.push('Bottom');
        }
        if (!hasShoes) missingItems.push('Shoes');

        const missingItemsList = document.querySelector('.missing-items-list');
        if (missingItemsList) {
            if (missingItems.length === 0) {
                missingItemsList.innerHTML = '<div class="complete-outfit"><i class="fas fa-check-circle"></i> Outfit is complete!</div>';
            } else {
                missingItemsList.innerHTML = `
                    <div class="missing-items">
                        <p>You need:</p>
                        <ul>${missingItems.map(item => `<li>${item}</li>`).join('')}</ul>
                    </div>
                `;
            }
        }
    }

    validateOutfit() {
        const hasDress = this.currentOutfit.has('dresses') && this.currentOutfit.get('dresses').size > 0;
        const hasTop = this.currentOutfit.has('tops') && this.currentOutfit.get('tops').size > 0;
        const hasBottom = this.currentOutfit.has('bottoms') && this.currentOutfit.get('bottoms').size > 0;
        const hasShoes = this.currentOutfit.has('shoes') && this.currentOutfit.get('shoes').size > 0;

        if (hasDress && hasShoes) return true;
        if (hasTop && hasBottom && hasShoes) return true;
        return false;
    }

    async saveOutfit(form) {
        try {
            if (!this.validateOutfit()) {
                this.showNotification('Please complete your outfit before saving', 'error');
                return;
            }

            const formData = new FormData(form);
            const outfitData = {
                name: formData.get('name').trim(),
                type: formData.get('type'),
                notes: formData.get('notes').trim(),
                items: Object.fromEntries(
                    Array.from(this.currentOutfit.entries()).map(([category, items]) => [
                        category,
                        Array.from(items).map(item => parseInt(item.id))
                    ])
                )
            };

            console.log('Saving outfit data:', outfitData);

            const response = await fetch(`${this.apiBasePath}/outfit_actions.php?action=save_outfit`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content || ''
                },
                body: JSON.stringify(outfitData)
            });

            const responseText = await response.text();
            console.log('Raw server response:', responseText);

            let result;
            try {
                result = JSON.parse(responseText);
            } catch (e) {
                console.error('Failed to parse server response:', responseText);
                throw new Error('Invalid server response');
            }

            if (!response.ok || !result.success) {
                throw new Error(result.message || 'Failed to save outfit');
            }

            this.showNotification('Outfit saved successfully!', 'success');
            this.closeModal();
            setTimeout(() => window.location.reload(), 1500);
            
        } catch (error) {
            console.error('Save error:', error);
            this.showNotification(`Failed to save outfit: ${error.message}`, 'error');
        }
    }

    async viewOutfit(outfitId) {
        try {
            const response = await fetch(`${this.apiBasePath}/outfit_actions.php?action=get_outfit&id=${outfitId}`);
            if (!response.ok) throw new Error('Failed to fetch outfit');
            
            const data = await response.json();
            if (!data.success) throw new Error(data.message);

            const outfit = data.outfit;
            
            // Update modal content
            const modal = document.getElementById('viewOutfitModal');
            modal.querySelector('.outfit-name').textContent = outfit.name;
            modal.querySelector('.outfit-category').textContent = outfit.category;
            modal.querySelector('.outfit-description').textContent = outfit.description || 'No description';

            // Clear and populate items grid
            const itemsGrid = modal.querySelector('.outfit-items-grid');
            itemsGrid.innerHTML = '';

            for (const item of outfit.items) {
                const itemElement = document.createElement('div');
                itemElement.className = 'saved-outfit-item';
                itemElement.innerHTML = `
                    <img src="${this.escapeHtml(item.image_url)}" alt="${this.escapeHtml(item.name)}">
                    <div class="item-info">
                        <span class="item-name">${this.escapeHtml(item.name)}</span>
                        <span class="item-category">${this.escapeHtml(item.category)}</span>
                    </div>
                `;
                itemsGrid.appendChild(itemElement);
            }

            // Show modal
            modal.style.display = 'flex';

        } catch (error) {
            console.error('Error viewing outfit:', error);
            this.showNotification('Failed to load outfit: ' + error.message, 'error');
        }
    }

    async deleteOutfit(outfitId) {
        if (!confirm('Are you sure you want to delete this outfit?')) {
            return;
        }

        try {
            const response = await fetch(`${this.apiBasePath}/outfit_actions.php?action=delete_outfit&id=${outfitId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content || ''
                }
            });

            if (!response.ok) throw new Error('Failed to delete outfit');
            
            const data = await response.json();
            if (!data.success) throw new Error(data.message);

            this.showNotification('Outfit deleted successfully', 'success');
            
            // ... continuing from the deleteOutfit method

            // Remove the outfit card from the UI
            const outfitCard = document.querySelector(`.saved-outfit-card[data-outfit-id="${outfitId}"]`);
            if (outfitCard) {
                outfitCard.remove();
            }

            // If no outfits left, show the empty message
            const remainingOutfits = document.querySelectorAll('.saved-outfit-card');
            if (remainingOutfits.length === 0) {
                const gridContainer = document.querySelector('.saved-outfits-grid');
                gridContainer.innerHTML = `
                    <div class="no-outfits-message">
                        <p>You haven't saved any outfits yet.</p>
                        <p>Create and save your first outfit above!</p>
                    </div>
                `;
            }

        } catch (error) {
            console.error('Error deleting outfit:', error);
            this.showNotification('Failed to delete outfit: ' + error.message, 'error');
        }
    }

    clearOutfit() {
        this.currentOutfit.clear();
        document.querySelectorAll('.zone-content').forEach(zone => {
            this.renderZone(zone.dataset.zone, zone);
        });
        this.updateOutfitSummary();
    }

    closeModal() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        const form = document.getElementById('saveOutfitForm');
        if (form) form.reset();
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${this.escapeHtml(message)}</span>
        `;
        
        document.body.appendChild(notification);
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    escapeHtml(unsafe) {
        if (typeof unsafe !== 'string') return '';
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
}

// Initialize with error handling
document.addEventListener('DOMContentLoaded', () => {
    try {
        window.outfitBuilder = new OutfitBuilder();
    } catch (error) {
        console.error('Failed to initialize OutfitBuilder:', error);
    }
});