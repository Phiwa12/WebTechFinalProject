// contact.js
class ContactManager {
    constructor() {
        this.formHandler = null;
        this.mapHandler = null;
        this.chatHandler = null;
        this.init();
    }

    init() {
        // Initialize all components
        this.formHandler = new FormHandler();
        this.mapHandler = new MapHandler();
        this.chatHandler = new ChatHandler();
        this.initializeGlobalEventListeners();
    }

    initializeGlobalEventListeners() {
        window.addEventListener('resize', () => {
            this.mapHandler?.handleResize();
            this.chatHandler?.handleResize();
        });
    }
}

class FormHandler {
    constructor() {
        this.form = document.getElementById('contactForm');
        this.fileUploads = [];
        this.init();
    }

    init() {
        if (this.form) {
            this.setupFormValidation();
            this.setupFileUpload();
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
    }

    setupFormValidation() {
        const inputs = this.form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', () => this.validateField(input));
            input.addEventListener('blur', () => this.validateField(input));
        });
    }

    setupFileUpload() {
        const fileInput = this.form.querySelector('input[type="file"]');
        const dropZone = this.form.querySelector('.file-preview');

        if (fileInput && dropZone) {
            dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropZone.classList.add('dragover');
            });

            dropZone.addEventListener('dragleave', () => {
                dropZone.classList.remove('dragover');
            });

            dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                dropZone.classList.remove('dragover');
                this.handleFiles(e.dataTransfer.files);
            });

            fileInput.addEventListener('change', (e) => {
                this.handleFiles(e.target.files);
            });
        }
    }

    handleFiles(files) {
        Array.from(files).forEach(file => {
            if (file.type.match('image.*')) {
                this.previewFile(file);
            }
        });
    }

    previewFile(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.createElement('div');
            preview.className = 'file-preview-item';
            preview.innerHTML = `
                <img src="${e.target.result}" alt="${file.name}">
                <button class="remove-file" title="Remove file">×</button>
            `;

            preview.querySelector('.remove-file').addEventListener('click', () => {
                preview.remove();
                this.fileUploads = this.fileUploads.filter(f => f !== file);
            });

            this.form.querySelector('.file-preview').appendChild(preview);
            this.fileUploads.push(file);
        };
        reader.readAsDataURL(file);
    }

    validateField(field) {
        let isValid = true;
        let errorMessage = '';

        switch (field.type) {
            case 'email':
                isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value);
                errorMessage = 'Please enter a valid email address';
                break;
            case 'text':
                isValid = field.value.trim().length >= 2;
                errorMessage = 'This field is required';
                break;
            case 'textarea':
                isValid = field.value.trim().length >= 10;
                errorMessage = 'Please enter at least 10 characters';
                break;
        }

        this.showFieldValidation(field, isValid, errorMessage);
        return isValid;
    }

    showFieldValidation(field, isValid, message) {
        const container = field.parentElement;
        let errorElement = container.querySelector('.error-message');

        if (!isValid) {
            if (!errorElement) {
                errorElement = document.createElement('div');
                errorElement.className = 'error-message';
                container.appendChild(errorElement);
            }
            errorElement.textContent = message;
            field.classList.add('error');
        } else {
            errorElement?.remove();
            field.classList.remove('error');
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        if (!this.validateForm()) {
            return;
        }

        const submitButton = this.form.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        
        try {
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            
            await this.submitForm();
            this.showSuccess();
            this.form.reset();
            this.clearFilePreview();
            
        } catch (error) {
            this.showError('Failed to send message. Please try again.');
        } finally {
            submitButton.disabled = false;
            submitButton.innerHTML = originalText;
        }
    }

    validateForm() {
        let isValid = true;
        this.form.querySelectorAll('input, textarea').forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });
        return isValid;
    }

    async submitForm() {
        // Simulate API call
        return new Promise(resolve => setTimeout(resolve, 2000));
    }

    showSuccess() {
        const modal = document.createElement('div');
        modal.className = 'success-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <i class="fas fa-check-circle"></i>
                <h3>Message Sent Successfully!</h3>
                <p>We'll get back to you soon.</p>
                <button onclick="this.parentElement.parentElement.remove()">Close</button>
            </div>
        `;
        document.body.appendChild(modal);
    }

    showError(message) {
        const notification = document.createElement('div');
        notification.className = 'error-notification';
        notification.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
        `;
        document.body.appendChild(notification);
        setTimeout(() => notification.remove(), 3000);
    }

    clearFilePreview() {
        const previewContainer = this.form.querySelector('.file-preview');
        if (previewContainer) {
            previewContainer.innerHTML = '';
        }
        this.fileUploads = [];
    }
}

// ... continuing from previous code

class MapHandler {
    constructor() {
        this.map = null;
        this.marker = null;
        this.mapConfig = {
            center: { lat: 40.7128, lng: -74.0060 }, // New York coordinates
            zoom: 15,
            styles: [
                {
                    "featureType": "all",
                    "elementType": "geometry",
                    "stylers": [{"color": "#ffffff"}]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [{"color": "#FFE4E1"}]
                },
                {
                    "featureType": "road",
                    "elementType": "geometry",
                    "stylers": [{"color": "#FFB6C1"}]
                },
                {
                    "featureType": "poi",
                    "elementType": "geometry",
                    "stylers": [{"color": "#FFF0F5"}]
                }
            ]
        };
        this.init();
    }

    init() {
        const mapContainer = document.querySelector('.map-container');
        if (mapContainer && window.google) {
            this.initializeMap(mapContainer);
            this.addMarker();
            this.addInfoWindow();
        }
    }

    initializeMap(container) {
        this.map = new google.maps.Map(container, {
            ...this.mapConfig,
            disableDefaultUI: true,
            zoomControl: true
        });
    }

    addMarker() {
        this.marker = new google.maps.Marker({
            position: this.mapConfig.center,
            map: this.map,
            title: 'StyleSense Office',
            animation: google.maps.Animation.DROP
        });
    }

    addInfoWindow() {
        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div class="map-info">
                    <h3>StyleSense</h3>
                    <p>123 Fashion Street<br>New York, NY 10001</p>
                    <a href="https://maps.google.com/directions?daddr=${this.mapConfig.center.lat},${this.mapConfig.center.lng}" 
                       target="_blank">Get Directions</a>
                </div>
            `
        });

        this.marker.addListener('click', () => {
            infoWindow.open(this.map, this.marker);
        });
    }

    handleResize() {
        if (this.map) {
            google.maps.event.trigger(this.map, 'resize');
            this.map.setCenter(this.mapConfig.center);
        }
    }
}

class ChatHandler {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.responses = this.initializeResponses();
        this.init();
    }

    init() {
        this.createChatWidget();
        this.attachEventListeners();
        this.addWelcomeMessage();
    }

    createChatWidget() {
        const chatWidget = document.createElement('div');
        chatWidget.className = 'chat-widget';
        chatWidget.innerHTML = `
            <button class="chat-toggle">
                <i class="fas fa-comments"></i>
                <span class="notification-badge">1</span>
            </button>
            <div class="chat-window">
                <div class="chat-header">
                    <div class="chat-title">
                        <i class="fas fa-comments"></i>
                        Chat with StyleSense
                    </div>
                    <button class="minimize-chat">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
                <div class="chat-messages"></div>
                <div class="chat-input">
                    <textarea placeholder="Type your message..." rows="1"></textarea>
                    <button class="send-message">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(chatWidget);

        this.elements = {
            widget: chatWidget,
            toggle: chatWidget.querySelector('.chat-toggle'),
            window: chatWidget.querySelector('.chat-window'),
            messages: chatWidget.querySelector('.chat-messages'),
            input: chatWidget.querySelector('textarea'),
            sendButton: chatWidget.querySelector('.send-message')
        };
    }

    initializeResponses() {
        return {
            greetings: {
                patterns: ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening'],
                responses: [
                    "Hi there! Welcome to StyleSense. How can I help you today?",
                    "Hello! Ready to explore some amazing fashion tips?",
                    "Welcome! Looking for style advice or something specific?"
                ]
            },
            style_advice: {
                patterns: ['style', 'fashion', 'outfit', 'wear', 'dress'],
                responses: [
                    "I'd love to help with your style questions! What's the occasion?",
                    "Let's find your perfect look! Are you going for casual or formal?",
                    "I can help you create great outfits! What's your style preference?"
                ]
            },
            contact: {
                patterns: ['contact', 'reach', 'call', 'email', 'phone'],
                responses: [
                    "You can reach us at support@stylesense.com",
                    "Our support team is available Monday to Friday, 9 AM to 6 PM",
                    "Would you like me to help you get in touch with our team?"
                ]
            },
            default: [
                "I'm here to help with all your style questions! Could you be more specific?",
                "That's interesting! Would you like to know more about our services?",
                "Feel free to ask me anything about fashion and style!"
            ]
        };
    }

    attachEventListeners() {
        this.elements.toggle.addEventListener('click', () => this.toggleChat());
        this.elements.input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        this.elements.sendButton.addEventListener('click', () => this.sendMessage());
        this.elements.input.addEventListener('input', () => this.adjustInputHeight());
    }

    toggleChat() {
        this.isOpen = !this.isOpen;
        this.elements.window.style.display = this.isOpen ? 'flex' : 'none';
        if (this.isOpen) {
            this.elements.input.focus();
            const badge = this.elements.toggle.querySelector('.notification-badge');
            if (badge) badge.remove();
        }
    }

    addWelcomeMessage() {
        this.addMessage("Hi there! How can I help you with your style today?", 'bot');
    }

    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}`;
        messageDiv.innerHTML = `<div class="message-content">${text}</div>`;
        
        if (sender === 'bot') {
            messageDiv.innerHTML += `
                <div class="message-actions">
                    <button class="helpful-btn" title="Mark as helpful">
                        <i class="fas fa-thumbs-up"></i>
                    </button>
                </div>
            `;
        }

        this.elements.messages.appendChild(messageDiv);
        this.elements.messages.scrollTop = this.elements.messages.scrollHeight;
        this.messages.push({ text, sender, timestamp: new Date() });
    }

    sendMessage() {
        const text = this.elements.input.value.trim();
        if (!text) return;

        this.addMessage(text, 'user');
        this.elements.input.value = '';
        this.adjustInputHeight();

        // Show typing indicator
        this.showTypingIndicator();

        // Generate response after a delay
        setTimeout(() => {
            this.hideTypingIndicator();
            const response = this.generateResponse(text);
            this.addMessage(response, 'bot');
        }, 1000);
    }

    generateResponse(input) {
        input = input.toLowerCase();
        
        // Check each response category
        for (const [category, data] of Object.entries(this.responses)) {
            if (data.patterns && data.patterns.some(pattern => input.includes(pattern))) {
                return this.getRandomResponse(data.responses);
            }
        }

        // Return default response if no pattern matches
        return this.getRandomResponse(this.responses.default);
    }

    getRandomResponse(responses) {
        return responses[Math.floor(Math.random() * responses.length)];
    }

    showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.innerHTML = '<span></span><span></span><span></span>';
        this.elements.messages.appendChild(indicator);
        this.elements.messages.scrollTop = this.elements.messages.scrollHeight;
    }

    hideTypingIndicator() {
        const indicator = this.elements.messages.querySelector('.typing-indicator');
        if (indicator) indicator.remove();
    }

    adjustInputHeight() {
        const input = this.elements.input;
        input.style.height = 'auto';
        input.style.height = (input.scrollHeight) + 'px';
    }

    handleResize() {
        if (this.isOpen) {
            this.elements.messages.scrollTop = this.elements.messages.scrollHeight;
        }
    }
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.contactManager = new ContactManager();
});

// Export for module usage if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ContactManager,
        FormHandler,
        MapHandler,
        ChatHandler
    };
}