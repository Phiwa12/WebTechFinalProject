// signup.js
class SignupForm {
    constructor() {
        this.currentStep = 1;
        this.form = document.getElementById('signupForm');
        this.steps = document.querySelectorAll('.form-step');
        this.progressSteps = document.querySelectorAll('.progress-step');
        this.passwordInput = document.getElementById('password');
        
        this.init();
    }

    init() {
        this.attachEventListeners();
        this.initializePasswordStrength();
        this.initializeSlideshow();
        this.initializeTestimonials();
    }

    attachEventListeners() {
        // Next buttons
        document.querySelectorAll('.next-btn').forEach(btn => {
            btn.addEventListener('click', () => this.nextStep());
        });

        // Back buttons
        document.querySelectorAll('.back-btn').forEach(btn => {
            btn.addEventListener('click', () => this.previousStep());
        });

        // Form submission
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        // Style options
        document.querySelectorAll('.style-option input').forEach(input => {
            input.addEventListener('change', () => this.handleStyleSelection());
        });

        // Password validation
        const confirmPassword = document.getElementById('confirm_password');
        if (confirmPassword) {
            confirmPassword.addEventListener('input', () => {
                if (this.passwordInput.value !== confirmPassword.value) {
                    confirmPassword.setCustomValidity("Passwords don't match");
                } else {
                    confirmPassword.setCustomValidity('');
                }
            });

            this.passwordInput.addEventListener('input', () => {
                if (confirmPassword.value !== '') {
                    if (this.passwordInput.value !== confirmPassword.value) {
                        confirmPassword.setCustomValidity("Passwords don't match");
                    } else {
                        confirmPassword.setCustomValidity('');
                    }
                }
            });
        }
    }

    initializePasswordStrength() {
        const strengthBar = document.querySelector('.password-strength');
        
        this.passwordInput.addEventListener('input', () => {
            const strength = this.calculatePasswordStrength(this.passwordInput.value);
            strengthBar.style.setProperty('--strength', `${strength}%`);
            strengthBar.style.backgroundColor = this.getStrengthColor(strength);
            
            // Update strength indicator text
            const strengthInfo = this.checkPasswordStrength(this.passwordInput.value);
            strengthBar.className = 'password-strength ' + strengthInfo.className;
            strengthBar.textContent = strengthInfo.message;
        });
    }

    calculatePasswordStrength(password) {
        let strength = 0;
        
        if (password.length >= 8) strength += 25;
        if (password.match(/[A-Z]/)) strength += 25;
        if (password.match(/[a-z]/)) strength += 25;
        if (password.match(/[0-9]/) || password.match(/[^A-Za-z0-9]/)) strength += 25;
        
        return strength;
    }

    checkPasswordStrength(password) {
        const length = password.length;
        const hasLower = /[a-z]/.test(password);
        const hasUpper = /[A-Z]/.test(password);
        const hasNumber = /\d/.test(password);
        
        if (length < 8) {
            return {
                className: 'weak',
                message: 'Too short'
            };
        }
        
        const strength = hasLower + hasUpper + hasNumber;
        
        if (strength < 2) {
            return {
                className: 'weak',
                message: 'Weak'
            };
        } else if (strength === 2) {
            return {
                className: 'medium',
                message: 'Medium'
            };
        } else {
            return {
                className: 'strong',
                message: 'Strong'
            };
        }
    }

    getStrengthColor(strength) {
        if (strength < 25) return '#ff6b6b';
        if (strength < 50) return '#ffd93d';
        if (strength < 75) return '#ffa502';
        return '#6bff6b';
    }

    nextStep() {
        if (this.validateCurrentStep()) {
            const formData = new FormData(this.form);
            formData.append('step', this.currentStep);
            this.submitStep(formData);
        }
    }

    previousStep() {
        if (this.currentStep > 1) {
            this.currentStep--;
            this.updateFormDisplay();
        }
    }

    validateCurrentStep() {
        const currentInputs = this.steps[this.currentStep - 1].querySelectorAll('input[required]');
        let valid = true;
        
        currentInputs.forEach(input => {
            if (!input.value) {
                this.showError(input, 'This field is required');
                valid = false;
            } else if (input.type === 'email' && !this.validateEmail(input.value)) {
                this.showError(input, 'Please enter a valid email');
                valid = false;
            } else if (input.type === 'password' && this.calculatePasswordStrength(input.value) < 50) {
                this.showError(input, 'Password is too weak');
                valid = false;
            }
        });

        return valid;
    }

    validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    showError(input, message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        const existingError = input.parentElement.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        input.parentElement.appendChild(errorDiv);
        input.classList.add('error');

        setTimeout(() => {
            errorDiv.remove();
            input.classList.remove('error');
        }, 3000);
    }

    showErrors(errors) {
        if (Array.isArray(errors)) {
            errors.forEach(error => this.showError(this.form, error));
        } else if (typeof errors === 'string') {
            this.showError(this.form, errors);
        } else {
            this.showError(this.form, 'An unknown error occurred');
        }
    }

    updateFormDisplay() {
        this.steps.forEach(step => step.style.display = 'none');
        this.steps[this.currentStep - 1].style.display = 'block';
        
        this.progressSteps.forEach((step, index) => {
            if (index + 1 <= this.currentStep) {
                step.classList.add('active');
            } else {
                step.classList.remove('active');
            }
        });
    }

    handleStyleSelection() {
        const selectedStyles = document.querySelectorAll('.style-option input:checked');
        const nextBtn = document.querySelector('.form-step[data-step="2"] .next-btn');
        nextBtn.disabled = selectedStyles.length === 0;
    }

    async submitStep(formData) {
        try {
            const response = await fetch('../actions/register_actions.php', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                const text = await response.text();
                console.error('Received non-JSON response:', text);
                throw new Error('Server returned non-JSON response');
            }
            
            const data = await response.json();
            
            if (data.success) {
                if (data.redirect) {
                    window.location.href = data.redirect;
                } else if (data.nextStep) {
                    this.currentStep = data.nextStep;
                    this.updateFormDisplay();
                } else {
                    this.showSuccessMessage();
                }
            } else {
                this.showErrors(data.errors || ['Step submission failed. Please try again.']);
            }
        } catch (error) {
            console.error('Step submission error:', error);
            this.showError(this.form, 'An error occurred. Please try again later.');
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        // Check terms agreement
        const termsCheckbox = document.querySelector('input[name="terms"]');
        if (!termsCheckbox.checked) {
            this.showError(termsCheckbox, 'You must agree to the Terms & Conditions');
            return;
        }
    
        const submitBtn = document.querySelector('.submit-btn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="loading-spinner"></span> Creating Account...';
    
        const formData = new FormData(this.form);
        formData.append('step', '3');
    
        try {
            const response = await fetch('../actions/register_actions.php', {
                method: 'POST',
                body: formData
            });
            
            // Log raw response text for debugging
            const responseText = await response.text();
            console.log('Raw server response:', responseText);
    
            let data;
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('JSON Parse Error:', parseError);
                console.error('Invalid JSON:', responseText);
                throw new Error('Server returned invalid JSON response');
            }
    
            if (data.success) {
                if (data.redirect) {
                    window.location.href = data.redirect;
                } else {
                    this.showSuccessMessage();
                }
            } else {
                this.showErrors(data.errors || ['Registration failed. Please try again.']);
            }
        } catch (error) {
            console.error('Registration error details:', {
                message: error.message,
                stack: error.stack
            });
            this.showError(this.form, 'An error occurred during registration. Please try again later.');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Create Account';
        }
    }
    showSuccessMessage() {
        const successMessage = document.createElement('div');
        successMessage.className = 'success-message';
        successMessage.innerHTML = `
            <h3>Welcome to StyleSense! 🎉</h3>
            <p>Your account has been created successfully.</p>
            <button onclick="window.location.href='dashboard.html'">Go to Dashboard</button>
        `;

        this.form.innerHTML = '';
        this.form.appendChild(successMessage);
    }

    initializeSlideshow() {
        const illustrations = ['👗', '👚', '👜', '👠', '💄', '👒'];
        const slideshow = document.querySelector('.fashion-slideshow');
        let currentIndex = 0;

        const showNextIllustration = () => {
            const illustration = document.createElement('div');
            illustration.className = 'fashion-illustration';
            illustration.textContent = illustrations[currentIndex];
            illustration.style.fontSize = '4rem';
            illustration.style.top = Math.random() * 80 + '%';
            illustration.style.left = Math.random() * 80 + '%';

            slideshow.appendChild(illustration);
            setTimeout(() => illustration.style.opacity = '1', 100);
            setTimeout(() => illustration.remove(), 3000);

            currentIndex = (currentIndex + 1) % illustrations.length;
        };

        setInterval(showNextIllustration, 2000);
    }

    initializeTestimonials() {
        const testimonials = [
            "StyleSense completely transformed my wardrobe! 💕",
            "Finally found my perfect style! ✨",
            "The best fashion companion ever! 👗"
        ];

        const slider = document.querySelector('.testimonials-slider');
        let currentIndex = 0;

        const showNextTestimonial = () => {
            slider.style.opacity = '0';
            setTimeout(() => {
                slider.textContent = testimonials[currentIndex];
                slider.style.opacity = '1';
                currentIndex = (currentIndex + 1) % testimonials.length;
            }, 500);
        };

        showNextTestimonial();
        setInterval(showNextTestimonial, 5000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SignupForm();
});