class AuthManager {
    constructor() {
        this.modal = document.getElementById('authModal');
        this.modalTitle = document.getElementById('modalTitle');
        this.currentAuthType = null;
        this.init();
    }

    init() {
        // Close modal when clicking outside
        window.onclick = (event) => {
            if (event.target === this.modal) {
                this.closeModal();
            }
        };

        // Add escape key listener
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modal.style.display === 'flex') {
                this.closeModal();
            }
        });
    }

    openModal(type) {
        this.currentAuthType = type;
        this.modalTitle.textContent = type === 'login' ? 'Welcome Back!' : 'Join StyleSense';
        this.modal.style.display = 'flex';
        setTimeout(() => {
            this.modal.classList.add('active');
        }, 10);
    }

    closeModal() {
        this.modal.classList.remove('active');
        setTimeout(() => {
            this.modal.style.display = 'none';
        }, 300);
    }

    handleAuthOption(provider) {
        const type = this.currentAuthType; // 'login' or 'signup'
        
        switch(provider) {
            case 'email':
                window.location.href = `view/${type}.php`;  // Changed from view to views
                break;
            case 'google':
                this.handleSocialAuth('google', type);
                break;
            case 'facebook':
                this.handleSocialAuth('facebook', type);
                break;
            default:
                console.error('Unknown provider');
        }
    }

    handleSocialAuth(provider, type) {
        // Show loading state on the button
        const button = this.modal.querySelector(`.auth-option.${provider}`);
        const originalContent = button.innerHTML;
        button.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Connecting...`;
        button.style.pointerEvents = 'none';

        // Make actual social auth request
        fetch(`actions/social_auth.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                provider: provider,
                type: type
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.href = 'view/services.php';  // Changed path
            } else {
                throw new Error(data.message || 'Authentication failed');
            }
        })
        .catch(error => {
            // Reset button
            button.innerHTML = originalContent;
            button.style.pointerEvents = 'auto';
            console.error('Auth error:', error);
        });
    }
}

// Global functions to be called from HTML
let authManager = null;

document.addEventListener('DOMContentLoaded', () => {
    authManager = new AuthManager();
});

function openAuthModal(type) {
    authManager.openModal(type);
}

function closeAuthModal() {
    authManager.closeModal();
}

function redirectToAuth(provider) {
    authManager.handleAuthOption(provider);
}