// color-palette.js

// Color Wheel Class
class ColorWheel {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.radius = Math.min(canvas.width, canvas.height) / 2;
        this.centerX = canvas.width / 2;
        this.centerY = canvas.height / 2;
        this.brightness = 50;
        this.saturation = 100;
        this.drawColorWheel();
    }

    drawColorWheel() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        for(let angle = 0; angle < 360; angle++) {
            for(let r = 0; r < this.radius; r++) {
                const saturation = (r / this.radius) * this.saturation;
                const brightness = this.brightness + (r / this.radius) * 25;
                
                const x = this.centerX + r * Math.cos(angle * Math.PI / 180);
                const y = this.centerY + r * Math.sin(angle * Math.PI / 180);
                
                this.ctx.fillStyle = `hsl(${angle}, ${saturation}%, ${brightness}%)`;
                this.ctx.fillRect(x, y, 2, 2);
            }
        }
    }

    getColorAtPoint(x, y) {
        const imageData = this.ctx.getImageData(x, y, 1, 1).data;
        return `#${[...imageData].slice(0,3).map(x => x.toString(16).padStart(2,'0')).join('')}`;
    }
}

// Color Palette Manager Class
class ColorPaletteManager {
    constructor() {
        this.savedColors = [];
        this.palettes = [];
        this.currentSeason = null;
        this.MAX_COLORS = 8;
        this.colorWheel = null;
        this.seasonPalettes = {
            spring: {
                warm: ['#FFB7C5', '#FF69B4', '#98FF98', '#FFD700', '#FFA07A', '#FF8C00', '#7FFF00', '#F0E68C'],
                light: ['#FFE4E1', '#FFB6C1', '#98FB98', '#F0E68C', '#E6E6FA', '#FFDAB9', '#B0E0E6', '#FFFACD'],
                bright: ['#FF1493', '#FF4500', '#32CD32', '#FFD700', '#FF69B4', '#00FF00', '#FFA500', '#FF6347']
            },
            summer: {
                cool: ['#87CEEB', '#E6E6FA', '#FFC0CB', '#98FB98', '#B0C4DE', '#DDA0DD', '#AFEEEE', '#D8BFD8'],
                light: ['#B0E0E6', '#D8BFD8', '#FFE4E1', '#E0FFFF', '#F0FFF0', '#FFF0F5', '#F0F8FF', '#F5F5DC'],
                soft: ['#778899', '#DDA0DD', '#F08080', '#20B2AA', '#9370DB', '#8FBC8F', '#96CDCD', '#DEB887']
            },
            autumn: {
                warm: ['#CD853F', '#DAA520', '#8B4513', '#D2691E', '#A0522D', '#B8860B', '#6B4423', '#CC7722'],
                deep: ['#8B0000', '#B8860B', '#556B2F', '#A0522D', '#800000', '#8B4513', '#6B4423', '#CC7722'],
                soft: ['#BC8F8F', '#BDB76B', '#696969', '#CD853F', '#B8860B', '#D2B48C', '#DEB887', '#D2691E']
            },
            winter: {
                cool: ['#483D8B', '#4B0082', '#800000', '#2F4F4F', '#000080', '#191970', '#663399', '#36013F'],
                deep: ['#000080', '#8B008B', '#2F4F4F', '#191970', '#4B0082', '#800080', '#36013F', '#2F0147'],
                bright: ['#0000FF', '#FF0000', '#00008B', '#8B0000', '#9400D3', '#8B008B', '#FF1493', '#FF0000']
            }
        };
        this.init();
    }

    init() {
        this.initializeColorWheel();
        this.initializeSeasonButtons();
        this.initializeSaveButton();
        this.attachEventListeners();
        this.loadSavedPalettes();
    }

    initializeColorWheel() {
        const canvas = document.getElementById('colorWheel');
        if (!canvas) return;
        
        canvas.width = 300;
        canvas.height = 300;
        this.colorWheel = new ColorWheel(canvas);

        // Add custom color picker
        const colorPicker = document.createElement('input');
        colorPicker.type = 'color';
        colorPicker.id = 'customColorPicker';
        colorPicker.className = 'custom-color-picker';
        document.querySelector('.color-wheel-container').appendChild(colorPicker);
    }

    initializeSeasonButtons() {
        const buttons = document.querySelectorAll('.season-btn');
        buttons.forEach(btn => {
            btn.addEventListener('click', () => {
                buttons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentSeason = btn.dataset.season;
                this.loadSeasonPalette(btn.dataset.season);
            });
        });
    }

    initializeSaveButton() {
        const saveBtn = document.querySelector('.save-palette-btn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.savePalette());
        }
    }

    attachEventListeners() {
        const canvas = document.getElementById('colorWheel');
        const customColorPicker = document.getElementById('customColorPicker');

        if (canvas) {
            canvas.addEventListener('click', (e) => {
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                const color = this.colorWheel.getColorAtPoint(x, y);
                this.addColor(color);
            });
        }

        if (customColorPicker) {
            customColorPicker.addEventListener('change', (e) => {
                this.addColor(e.target.value);
            });
        }
    }

    addColor(color) {
        if (this.savedColors.length < this.MAX_COLORS && !this.savedColors.includes(color)) {
            this.savedColors.push(color);
            this.updateColorDisplay();
            this.generateCombinations();
        }
    }

    updateColorDisplay() {
        const container = document.querySelector('.saved-colors');
        if (!container) return;

        container.innerHTML = '';
        this.savedColors.forEach((color, index) => {
            const colorDiv = document.createElement('div');
            colorDiv.className = 'color-bubble';
            colorDiv.style.backgroundColor = color;
            colorDiv.setAttribute('data-color', color);
            
            const removeBtn = document.createElement('button');
            removeBtn.className = 'remove-color';
            removeBtn.innerHTML = '×';
            removeBtn.onclick = () => this.removeColor(index);
            
            colorDiv.appendChild(removeBtn);
            container.appendChild(colorDiv);
        });
    }

    removeColor(index) {
        this.savedColors.splice(index, 1);
        this.updateColorDisplay();
        this.generateCombinations();
    }

    loadSeasonPalette(season) {
        const container = document.querySelector('.season-palettes');
        if (!container) return;

        container.innerHTML = '';
        
        Object.entries(this.seasonPalettes[season]).forEach(([variety, colors]) => {
            const paletteDiv = document.createElement('div');
            paletteDiv.className = 'season-palette';
            paletteDiv.innerHTML = `<h4>${variety}</h4>`;

            const colorsDiv = document.createElement('div');
            colorsDiv.className = 'palette-colors';

            colors.forEach(color => {
                const colorDiv = document.createElement('div');
                colorDiv.className = 'color-bubble';
                colorDiv.style.backgroundColor = color;
                colorDiv.setAttribute('data-color', color);
                colorDiv.onclick = () => this.addColor(color);
                colorsDiv.appendChild(colorDiv);
            });

            paletteDiv.appendChild(colorsDiv);
            container.appendChild(paletteDiv);
        });
    }

    // Continuing the ColorPaletteManager class...

    generateCombinations() {
        if (!this.savedColors.length) return;

        const baseColor = this.savedColors[0];
        const combinations = [
            {
                name: 'Monochromatic',
                colors: this.generateMonochromatic(baseColor)
            },
            {
                name: 'Complementary',
                colors: this.generateComplementary(baseColor)
            },
            {
                name: 'Triadic',
                colors: this.generateTriadic(baseColor)
            },
            {
                name: 'Analogous',
                colors: this.generateAnalogous(baseColor)
            },
            {
                name: 'Split Complementary',
                colors: this.generateSplitComplementary(baseColor)
            },
            {
                name: 'Square',
                colors: this.generateSquare(baseColor)
            }
        ];

        this.displayCombinations(combinations);
    }

    displayCombinations(combinations) {
        const container = document.querySelector('.combination-cards');
        if (!container) return;

        container.innerHTML = '';
        combinations.forEach(combo => {
            const card = document.createElement('div');
            card.className = 'combination-card';
            
            const colorStrips = combo.colors.map(color => `
                <div class="color-strip" style="background-color: ${color}">
                    <span class="color-code">${color}</span>
                </div>
            `).join('');

            card.innerHTML = `
                <h4>${combo.name}</h4>
                <div class="color-strips">${colorStrips}</div>
                <button class="use-combo-btn" data-colors='${JSON.stringify(combo.colors)}'>
                    Use This Combination
                </button>
            `;

            const useButton = card.querySelector('.use-combo-btn');
            useButton.addEventListener('click', () => {
                this.useCombination(combo.colors);
            });

            container.appendChild(card);
        });
    }

    useCombination(colors) {
        this.savedColors = []; // Clear existing colors
        colors.forEach(color => this.addColor(color));
    }

    async savePalette() {
        if (this.savedColors.length === 0) {
            alert('Please select at least one color before saving');
            return;
        }

        const saveBtn = document.querySelector('.save-palette-btn');
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving...';
        }

        try {
            const response = await fetch('../actions/save_palette.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    colors: this.savedColors,
                    season: this.currentSeason,
                    name: `My Palette ${new Date().toLocaleString()}`
                })
            });

            const data = await response.json();
            if (data.success) {
                alert('Palette saved successfully!');
                await this.loadSavedPalettes();
            } else {
                throw new Error(data.message || 'Failed to save palette');
            }
        } catch (error) {
            console.error('Error saving palette:', error);
            alert('Failed to save palette. Please try again.');
        } finally {
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.textContent = 'Save Palette';
            }
        }
    }

    displaySavedPalettes() {
        const container = document.querySelector('.palettes-container');
        if (!container) {
            console.error('Palettes container not found');
            return;
        }
    
        container.innerHTML = '';
        
        if (!this.palettes || this.palettes.length === 0) {
            container.innerHTML = `
                <div class="no-palettes-message">
                    No saved palettes yet. Start by selecting colors and saving your first palette!
                </div>`;
            return;
        }
    
        this.palettes.forEach(palette => {
            const paletteCard = document.createElement('div');
            paletteCard.className = 'palette-card';
            
            const colors = Array.isArray(palette.colors) ? palette.colors : JSON.parse(palette.colors);
            const colorsHtml = colors.map(color => `
                <div class="color-sample" 
                     style="background-color: ${color}"
                     data-color="${color}">
                </div>
            `).join('');
    
            const formattedDate = new Date(palette.created_at).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
    
            paletteCard.innerHTML = `
                <div class="palette-header">
                    <span class="palette-name">${palette.palette_name || 'My Palette'}</span>
                    <span class="palette-date">${formattedDate}</span>
                </div>
                <div class="palette-colors-display">
                    ${colorsHtml}
                </div>
                ${palette.season ? `<div class="palette-season">${palette.season} Season</div>` : ''}
                <button class="use-palette-btn">Use This Palette</button>
            `;
    
            // Add click event for the use button
            const useButton = paletteCard.querySelector('.use-palette-btn');
            useButton.addEventListener('click', () => {
                this.useCombination(colors);
                // Scroll to color wheel section
                document.querySelector('.color-wheel-container')?.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            });
    
            container.appendChild(paletteCard);
        });
    }

    async loadSavedPalettes() {
        try {
            const response = await fetch('../actions/get_palettes.php');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Loaded palettes:', data); // Debug log
            
            if (data.success) {
                this.palettes = data.palettes;
                this.displaySavedPalettes();
            } else {
                throw new Error(data.message || 'Failed to load palettes');
            }
        } catch (error) {
            console.error('Error loading palettes:', error);
            const container = document.querySelector('.palettes-container');
            if (container) {
                container.innerHTML = `
                    <div class="error-message">
                        Failed to load palettes. Please try refreshing the page.
                    </div>`;
            }
        }
    }

    displaySavedPalettes() {
        // First, try to find the container in the saved-palettes-history section
        let container = document.querySelector('.saved-palettes-history .palettes-container');
        
        // If it doesn't exist, create the entire section
        if (!container) {
            const historySection = document.createElement('section');
            historySection.className = 'saved-palettes-history';
            historySection.innerHTML = `
                <h3>Your Palette History</h3>
                <div class="palettes-container"></div>
            `;
            
            // Add it after the combination-cards section
            const combinationSection = document.querySelector('.color-combinations');
            if (combinationSection) {
                combinationSection.after(historySection);
            } else {
                document.querySelector('.color-tool-container').appendChild(historySection);
            }
            
            container = historySection.querySelector('.palettes-container');
        }
    
        // Clear existing content
        container.innerHTML = '';
        
        if (!this.palettes || this.palettes.length === 0) {
            container.innerHTML = `
                <div class="no-palettes-message">
                    No saved palettes yet. Start by selecting colors and saving your first palette!
                </div>`;
            return;
        }
    
        this.palettes.forEach(palette => {
            try {
                const paletteCard = document.createElement('div');
                paletteCard.className = 'palette-card';
                
                // Create HTML for each color in the palette
                const colorsHtml = palette.colors.map(color => `
                    <div class="color-sample" 
                         style="background-color: ${color}"
                         data-color="${color}"
                         title="${color}">
                    </div>
                `).join('');
    
                paletteCard.innerHTML = `
        <div class="palette-header">
            <span class="palette-name">${palette.name || 'My Palette'}</span>
            <span class="palette-date">${palette.created_at}</span>
        </div>
        <div class="palette-colors-display">
            ${colorsHtml}
        </div>
        ${palette.season ? `<div class="palette-season">${palette.season} Season</div>` : ''}
        <div class="palette-actions">
            <button class="use-palette-btn">Use Palette</button>
            <button class="edit-palette-btn">Edit</button>
            <button class="delete-palette-btn">Delete</button>
        </div>
    `;
    
    const editBtn = paletteCard.querySelector('.edit-palette-btn');
    const deleteBtn = paletteCard.querySelector('.delete-palette-btn');

    editBtn.addEventListener('click', () => this.editPalette(palette));
    deleteBtn.addEventListener('click', () => this.deletePalette(palette.id));
                // Add event listener for using the palette
                const useButton = paletteCard.querySelector('.use-palette-btn');
                useButton.addEventListener('click', () => {
                    this.useCombination(palette.colors);
                    // Scroll to color wheel
                    document.querySelector('.color-wheel-container')?.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                });
    
                container.appendChild(paletteCard);
            } catch (error) {
                console.error('Error displaying palette:', error, palette);
            }
        });
    }

    // Color conversion utilities
    hexToHSL(hex) {
        let r = parseInt(hex.slice(1, 3), 16) / 255;
        let g = parseInt(hex.slice(3, 5), 16) / 255;
        let b = parseInt(hex.slice(5, 7), 16) / 255;

        let max = Math.max(r, g, b);
        let min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;

        if (max === min) {
            h = s = 0;
        } else {
            let d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }

        return {
            h: Math.round(h * 360),
            s: Math.round(s * 100),
            l: Math.round(l * 100)
        };
    }

    HSLToHex(h, s, l) {
        s /= 100;
        l /= 100;
        
        const k = n => (n + h / 30) % 12;
        const a = s * Math.min(l, 1 - l);
        const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
        
        const rgb = [
            Math.round(255 * f(0)),
            Math.round(255 * f(8)),
            Math.round(255 * f(4))
        ];
        
        return `#${rgb.map(x => x.toString(16).padStart(2, '0')).join('')}`;
    }

    // Color combination generators
    generateMonochromatic(baseColor) {
        const hsl = this.hexToHSL(baseColor);
        return [
            baseColor,
            this.HSLToHex(hsl.h, hsl.s, Math.max(0, hsl.l - 20)),
            this.HSLToHex(hsl.h, hsl.s, Math.min(100, hsl.l + 20))
        ];
    }

    generateComplementary(baseColor) {
        const hsl = this.hexToHSL(baseColor);
        return [
            baseColor,
            this.HSLToHex((hsl.h + 180) % 360, hsl.s, hsl.l)
        ];
    }

    generateTriadic(baseColor) {
        const hsl = this.hexToHSL(baseColor);
        return [
            baseColor,
            this.HSLToHex((hsl.h + 120) % 360, hsl.s, hsl.l),
            this.HSLToHex((hsl.h + 240) % 360, hsl.s, hsl.l)
        ];
    }

    generateAnalogous(baseColor) {
        const hsl = this.hexToHSL(baseColor);
        return [
            this.HSLToHex((hsl.h - 30 + 360) % 360, hsl.s, hsl.l),
            baseColor,
            this.HSLToHex((hsl.h + 30) % 360, hsl.s, hsl.l)
        ];
    }

    generateSplitComplementary(baseColor) {
        const hsl = this.hexToHSL(baseColor);
        return [
            baseColor,
            this.HSLToHex((hsl.h + 150) % 360, hsl.s, hsl.l),
            this.HSLToHex((hsl.h + 210) % 360, hsl.s, hsl.l)
        ];
    }

    generateSquare(baseColor) {
        const hsl = this.hexToHSL(baseColor);
        return [
            baseColor,
            this.HSLToHex((hsl.h + 90) % 360, hsl.s, hsl.l),
            this.HSLToHex((hsl.h + 180) % 360, hsl.s, hsl.l),
            this.HSLToHex((hsl.h + 270) % 360, hsl.s, hsl.l)
        ];
    }

    editPalette(palette) {
        const colors = Array.isArray(palette.colors) ? palette.colors : JSON.parse(palette.colors);
        this.savedColors = colors;
        this.currentSeason = palette.season;
        this.updateColorDisplay();
        this.generateCombinations();
    
        // Show edit mode UI
        const editUI = document.createElement('div');
        editUI.className = 'edit-palette-overlay';
        editUI.innerHTML = `
            <div class="edit-palette-modal">
                <h3>Edit Palette</h3>
                <div class="edit-form">
                    <div class="form-group">
                        <label>Palette Name</label>
                        <input type="text" class="palette-name-input" value="${palette.name || ''}" />
                    </div>
                    <div class="form-group">
                        <label>Season</label>
                        <select class="season-select">
                            <option value="">No Season</option>
                            <option value="spring" ${palette.season === 'spring' ? 'selected' : ''}>Spring</option>
                            <option value="summer" ${palette.season === 'summer' ? 'selected' : ''}>Summer</option>
                            <option value="autumn" ${palette.season === 'autumn' ? 'selected' : ''}>Autumn</option>
                            <option value="winter" ${palette.season === 'winter' ? 'selected' : ''}>Winter</option>
                        </select>
                    </div>
                    <div class="button-group">
                        <button class="save-edit-btn">Save Changes</button>
                        <button class="cancel-edit-btn">Cancel</button>
                    </div>
                </div>
            </div>
        `;
    
        document.body.appendChild(editUI);
    
        // Add event listeners
        const saveBtn = editUI.querySelector('.save-edit-btn');
        const cancelBtn = editUI.querySelector('.cancel-edit-btn');
    
        saveBtn.addEventListener('click', async () => {
            const newName = editUI.querySelector('.palette-name-input').value;
            const newSeason = editUI.querySelector('.season-select').value;
    
            await this.savePaletteEdit(palette.id, newName, newSeason);
            document.body.removeChild(editUI);
        });
    
        cancelBtn.addEventListener('click', () => {
            document.body.removeChild(editUI);
        });
    }

    async deletePalette(paletteId) {
        if (!confirm('Are you sure you want to delete this palette?')) {
            return;
        }
    
        try {
            const response = await fetch('../actions/manage_palette.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'delete',
                    palette_id: paletteId
                })
            });
    
            const data = await response.json();
            
            if (data.success) {
                alert('Palette deleted successfully');
                this.loadSavedPalettes();
            } else {
                throw new Error(data.message || 'Failed to delete palette');
            }
        } catch (error) {
            console.error('Error deleting palette:', error);
            alert('Failed to delete palette. Please try again.');
        }
    }

    async savePaletteEdit(paletteId, name, season) {
        try {
            const response = await fetch('../actions/manage_palette.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'edit',
                    palette_id: paletteId,
                    name: name,
                    season: season,
                    colors: this.savedColors
                })
            });
    
            const data = await response.json();
            
            if (data.success) {
                alert('Palette updated successfully');
                this.loadSavedPalettes();
            } else {
                throw new Error(data.message || 'Failed to update palette');
            }
        } catch (error) {
            console.error('Error updating palette:', error);
            alert('Failed to update palette. Please try again.');
        }
    }
    
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.colorPaletteManager = new ColorPaletteManager();
});