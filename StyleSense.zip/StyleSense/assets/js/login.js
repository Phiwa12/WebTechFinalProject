class LoginPage {
    constructor() {
        this.form = document.getElementById('loginForm');
        this.loginTypeSwitch = document.getElementById('loginType');
        this.emailInput = document.querySelector('.email-input');
        this.phoneInput = document.querySelector('.phone-input');
        this.passwordToggle = document.querySelector('.toggle-password');
        this.passwordInput = document.getElementById('password');
        this.forgotPasswordLink = document.querySelector('.forgot-password');
        this.modal = document.querySelector('.modal');

        this.init();
    }

    init() {
        this.attachEventListeners();
        this.initializeFloatingElements();
        this.initializeSparkleEffect();
    }

    attachEventListeners() {
        // Form submission
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        // Login type switch
        this.loginTypeSwitch.addEventListener('change', () => {
            this.toggleLoginMethod();
        });

        // Password visibility toggle
        this.passwordToggle.addEventListener('click', () => {
            this.togglePassword();
        });

        // Forgot password link
        this.forgotPasswordLink.addEventListener('click', (e) => {
            e.preventDefault();
            this.handleForgotPassword();
        });

        // Modal close button
        const closeModal = document.querySelector('.close-modal');
        if (closeModal) {
            closeModal.addEventListener('click', () => {
                this.modal.classList.remove('active');
                setTimeout(() => {
                    this.modal.style.display = 'none';
                }, 300);
            });
        }

        // Social login buttons
        document.querySelectorAll('.social-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const provider = btn.classList.contains('google-btn') ? 'google' : 'facebook';
                this.handleSocialLogin(provider);
            });
        });

        // Reset password form
        const resetForm = document.getElementById('resetForm');
        if (resetForm) {
            resetForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleResetPassword(e);
            });
        }
    }

    toggleLoginMethod() {
        if (this.loginTypeSwitch.checked) {
            this.emailInput.style.display = 'none';
            this.phoneInput.style.display = 'block';
            this.animateInputTransition(this.phoneInput);
        } else {
            this.phoneInput.style.display = 'none';
            this.emailInput.style.display = 'block';
            this.animateInputTransition(this.emailInput);
        }
    }

    togglePassword() {
        const type = this.passwordInput.type === 'password' ? 'text' : 'password';
        this.passwordInput.type = type;
        
        // Update Font Awesome icon
        const icon = this.passwordToggle.querySelector('i');
        icon.className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
        
        // Add animation
        icon.style.transform = 'scale(1.2)';
        setTimeout(() => {
            icon.style.transform = 'scale(1)';
        }, 200);
    }
    initializeFloatingElements() {
        try {
            const container = document.querySelector('.floating-elements');
            if (!container) return;
    
            const fashionIcons = [
                'fa-tshirt',
                'fa-shopping-bag',
                'fa-shoe-prints',
                'fa-hat-cowboy',
                'fa-glasses',
                'fa-gem',
                'fa-vest',
                'fa-socks'
            ];
            
            setInterval(() => {
                const item = document.createElement('div');
                item.className = 'floating-item';
                const icon = document.createElement('i');
                icon.className = `fas ${fashionIcons[Math.floor(Math.random() * fashionIcons.length)]}`;
                item.appendChild(icon);
                
                item.style.left = Math.random() * 100 + 'vw';
                item.style.animationDuration = (Math.random() * 10 + 10) + 's';
                container.appendChild(item);
    
                setTimeout(() => {
                    if (item && item.parentNode) {
                        item.remove();
                    }
                }, 20000);
            }, 2000);
        } catch (error) {
            console.error('Error initializing floating elements:', error);
        }
    }

    initializeSparkleEffect() {
        const logo = document.querySelector('.logo-animation');
        if (!logo) return;
        
        const createSparkle = () => {
            const sparkle = document.createElement('div');
            sparkle.className = 'sparkle';
            sparkle.style.left = Math.random() * 100 + '%';
            sparkle.style.top = Math.random() * 100 + '%';
            logo.appendChild(sparkle);

            setTimeout(() => {
                if (sparkle && sparkle.parentNode) {
                    sparkle.remove();
                }
            }, 1000);
        };

        setInterval(createSparkle, 2000);
    }

    animateInputTransition(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateX(20px)';
        
        requestAnimationFrame(() => {
            element.style.opacity = '1';
            element.style.transform = 'translateX(0)';
        });
    }

    async handleSubmit(event) {
        event.preventDefault();
        const submitButton = this.form.querySelector('.login-btn');
        const btnText = submitButton.querySelector('.btn-text');
        const btnLoader = submitButton.querySelector('.btn-loader');

        try {
            // Show loading state
            btnText.style.opacity = '0';
            btnLoader.style.display = 'block';
            submitButton.disabled = true;

            // Validate inputs
            if (!this.validateForm()) {
                throw new Error('Please check your inputs');
            }

            // Get form data
            const formData = new FormData(this.form);
            
            // Make the actual login request
            const response = await fetch('../actions/login_actions.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                // Show success and redirect
                this.showSuccessMessage();
                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1500);
            } else {
                throw new Error(data.message || 'Login failed. Please try again.');
            }

        } catch (error) {
            this.showError(error.message);
        } finally {
            // Reset button state
            btnText.style.opacity = '1';
            btnLoader.style.display = 'none';
            submitButton.disabled = false;
        }
    }


    validateForm() {
        let isValid = true;
        const inputs = this.form.querySelectorAll('input[required]');

        inputs.forEach(input => {
            if (!input.value) {
                this.showInputError(input, 'This field is required');
                isValid = false;
            } else if (input.type === 'email' && !this.validateEmail(input.value)) {
                this.showInputError(input, 'Please enter a valid email');
                isValid = false;
            } else if (input.type === 'tel' && !this.validatePhone(input.value)) {
                this.showInputError(input, 'Please enter a valid phone number');
                isValid = false;
            }
        });

        return isValid;
    }

    validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    validatePhone(phone) {
        return /^\d{10}$/.test(phone);
    }

    showInputError(input, message) {
        const errorElement = document.createElement('div');
        errorElement.className = 'input-error';
        errorElement.textContent = message;
        
        input.classList.add('error');
        input.parentElement.appendChild(errorElement);

        // Shake animation
        input.style.animation = 'shake 0.5s ease';
        setTimeout(() => {
            input.style.animation = '';
            errorElement.remove();
            input.classList.remove('error');
        }, 3000);
    }

    async simulateLogin() {
        return new Promise((resolve) => {
            setTimeout(resolve, 1500);
        });
    }

    showSuccessMessage(message = 'Welcome back!') {
        const successMessage = document.createElement('div');
        successMessage.className = 'success-message';
        successMessage.innerHTML = `
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>${message}</h3>
            <p><i class="fas fa-spinner fa-spin"></i> Redirecting to services...</p>
        `;

        this.form.appendChild(successMessage);
        successMessage.style.animation = 'slideIn 0.5s ease forwards';
    }

    showError(message) {
        const errorToast = document.createElement('div');
        errorToast.className = 'error-toast';
        errorToast.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            ${message}
        `;
        
        document.body.appendChild(errorToast);
        
        setTimeout(() => {
            errorToast.remove();
        }, 3000);
    }

    handleForgotPassword() {
        this.modal.style.display = 'flex';
        setTimeout(() => {
            this.modal.classList.add('active');
        }, 10);
    }

    handleResetPassword(event) {
        const form = event.target;
        const email = form.querySelector('input[type="email"]').value;
        const submitBtn = form.querySelector('.reset-btn');

        // Show loading state
        submitBtn.textContent = 'Sending...';
        submitBtn.disabled = true;

        // Simulate API call
        setTimeout(() => {
            this.showSuccessMessage('Password reset link sent! Please check your email.');
            this.modal.classList.remove('active');
            setTimeout(() => {
                this.modal.style.display = 'none';
                submitBtn.textContent = 'Send Reset Link';
                submitBtn.disabled = false;
            }, 300);
        }, 1500);
    }

    handleSocialLogin(provider) {
        const button = this.form.querySelector(`.${provider}-btn`);
        button.classList.add('loading');
        
        // Simulate social login
        setTimeout(() => {
            button.classList.remove('loading');
            this.showSuccessMessage();
            setTimeout(() => {
                window.location.href = '../view/services.php';
            }, 1500);
        }, 2000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const loginPage = new LoginPage();

    // Add additional animations
    document.querySelectorAll('.feature').forEach((feature, index) => {
        setTimeout(() => {
            feature.style.opacity = '1';
            feature.style.transform = 'translateY(0)';
        }, index * 200);
    });

    // Add hover effects for social buttons
    document.querySelectorAll('.social-btn').forEach(btn => {
        btn.addEventListener('mouseover', () => {
            btn.style.transform = 'translateY(-3px)';
        });
        btn.addEventListener('mouseout', () => {
            btn.style.transform = 'translateY(0)';
        });
    });

    // Add ripple effect to buttons
    document.querySelectorAll('button').forEach(button => {
        button.addEventListener('click', (e) => {
            const ripple = document.createElement('span');
            ripple.className = 'ripple';
            const rect = button.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = e.clientX - rect.left - size/2 + 'px';
            ripple.style.top = e.clientY - rect.top - size/2 + 'px';
            button.appendChild(ripple);
            setTimeout(() => ripple.remove(), 1000);
        });
    });
});