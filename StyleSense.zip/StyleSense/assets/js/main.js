document.addEventListener('DOMContentLoaded', () => {
    initializeAnimations();
    initializeTestimonials();
    initializeInteractiveElements();
    initializeJourneyButton();
});

// Initialize journey button
function initializeJourneyButton() {
    const journeyButton = document.getElementById('journeyButton');
    if (journeyButton) {
        journeyButton.addEventListener('click', () => {
            // Get the current URL path
            const currentPath = window.location.pathname;
            // Check if user is logged in by checking a data attribute we'll add to the button
            const isLoggedIn = journeyButton.dataset.loggedin === 'true';
            
            if (isLoggedIn) {
                window.location.href = 'view/body_analysis.php';
            } else {
                window.location.href = 'view/signup.php';
            }
        });
    }
}

// Initialize all animations and visual effects
function initializeAnimations() {
    const hero = document.querySelector('.hero');
    if (hero) {
        setInterval(() => {
            createFloatingHeart(hero);
        }, 3000);
    }

    const featureCards = document.querySelectorAll('.feature-card');
    if (featureCards.length > 0) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        });

        featureCards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(50px)';
            observer.observe(card);
        });
    }
}

// Create floating heart elements
function createFloatingHeart(parent) {
    const heart = document.createElement('div');
    heart.classList.add('floating-hearts');
    heart.innerHTML = '💝';
    heart.style.left = Math.random() * 100 + 'vw';
    heart.style.fontSize = (Math.random() * 20 + 10) + 'px';
    parent.appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 6000);
}

// Initialize testimonial slider
function initializeTestimonials() {
    const testimonials = [
        {
            name: "Sarah Johnson",
            text: "StyleSense completely transformed my wardrobe and confidence!",
            rating: 5
        },
        {
            name: "Emily Chen",
            text: "The color palette suggestions are spot-on. I've never received so many compliments!",
            rating: 5
        },
        {
            name: "Maria Garcia",
            text: "Finally understanding my body type has made shopping so much easier.",
            rating: 4
        }
    ];

    const slider = document.querySelector('.testimonial-slider');
    if (slider) {
        let currentIndex = 0;

        function updateTestimonials() {
            slider.innerHTML = '';
            const testimonial = testimonials[currentIndex];
            
            const card = document.createElement('div');
            card.classList.add('testimonial-card');
            card.innerHTML = `
                <p class="testimonial-text">"${testimonial.text}"</p>
                <p class="testimonial-author">- ${testimonial.name}</p>
                <div class="testimonial-rating">
                    ${'⭐'.repeat(testimonial.rating)}
                </div>
            `;
            
            slider.appendChild(card);

            card.style.opacity = 0;
            setTimeout(() => {
                card.style.opacity = 1;
            }, 100);
        }

        updateTestimonials();
        setInterval(() => {
            currentIndex = (currentIndex + 1) % testimonials.length;
            updateTestimonials();
        }, 5000);
    }
}

// Initialize interactive elements
function initializeInteractiveElements() {
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
        ctaButton.addEventListener('mouseover', createRippleEffect);
    }

    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('mouseover', () => {
            link.style.transform = 'scale(1.1)';
        });
        link.addEventListener('mouseout', () => {
            link.style.transform = 'scale(1)';
        });
    });
}

// Create ripple effect for buttons
function createRippleEffect(event) {
    const button = event.currentTarget;
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${event.clientX - rect.left - size/2}px`;
    ripple.style.top = `${event.clientY - rect.top - size/2}px`;
    ripple.classList.add('ripple');
    
    button.appendChild(ripple);
    setTimeout(() => ripple.remove(), 1000);
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.classList.add('notification');
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('visible');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('visible');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}