class BodyTypeAnalyzer {
    constructor() {
        console.log('Initializing BodyTypeAnalyzer');
        
        this.form = document.getElementById('bodyAnalysisForm');
        console.log('Form element:', this.form);
        
        if (!this.form) {
            console.error('Body analysis form not found. Make sure the form has id="bodyAnalysisForm"');
            return;
        }

        this.initializeBodyTypes();
        this.init();
    }

    initializeBodyTypes() {
        this.bodyTypes = {
            hourglass: {
                name: "Hourglass",
                description: "Your shoulders and hips are about the same width with a significantly smaller waist.",
                recommendations: [
                    "Fitted clothing that shows off your natural curves",
                    "Wrap dresses and tops",
                    "High-waisted bottoms",
                    "Belt to emphasize waist"
                ],
                dos: [
                    "Emphasize your waist",
                    "Choose fitted styles",
                    "Use belts to define your middle",
                    "Wear v-neck or scoop necklines"
                ],
                donts: [
                    "Wear boxy or shapeless clothing",
                    "Choose overwhelming ruffles or volume",
                    "Hide your waist",
                    "Wear overly loose styles"
                ]
            },
            pear: {
                name: "Pear",
                description: "Your hips are wider than your shoulders with a defined waist.",
                recommendations: [
                    "A-line skirts and dresses",
                    "Boat neck and wide necklines",
                    "Fitted tops with flared bottoms",
                    "Dark colors for bottom half"
                ],
                dos: [
                    "Draw attention to your upper body",
                    "Wear bright colors on top",
                    "Choose A-line silhouettes",
                    "Opt for statement necklines"
                ],
                donts: [
                    "Wear tight-fitting bottoms",
                    "Choose bottoms with large patterns",
                    "Wear cropped tops",
                    "Choose skinny straps"
                ]
            },
            apple: {
                name: "Apple",
                description: "Your shoulders and bust are wider than your hips with less waist definition.",
                recommendations: [
                    "Empire waist dresses",
                    "V-neck tops",
                    "Flowy fabrics",
                    "A-line silhouettes"
                ],
                dos: [
                    "Create vertical lines",
                    "Choose empire waist styles",
                    "Wear V-necks",
                    "Opt for flowing fabrics"
                ],
                donts: [
                    "Wear tight-fitting waistbands",
                    "Choose bulky fabrics",
                    "Wear heavy belts",
                    "Add volume at the waist"
                ]
            },
            rectangle: {
                name: "Rectangle",
                description: "Your shoulders, waist, and hips are similar in width.",
                recommendations: [
                    "Ruffles and layers to create curves",
                    "Peplum tops",
                    "Belt to create waist definition",
                    "Asymmetrical designs"
                ],
                dos: [
                    "Create curves with clothing",
                    "Use layers and ruffles",
                    "Wear belts and waist-defining pieces",
                    "Try asymmetrical designs"
                ],
                donts: [
                    "Wear straight, shapeless clothing",
                    "Choose plain, unstructured pieces",
                    "Wear oversized clothing",
                    "Stick to one silhouette"
                ]
            }
        };
    }

    init() {
        console.log('Initializing form handlers');
        
        if (!this.form) {
            console.error('Cannot initialize form handlers: form not found');
            return;
        }

        this.form.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Form submitted');
            await this.analyzeBodyType();
        });

        const inputs = this.form.querySelectorAll('input[type="number"]');
        console.log('Found number inputs:', inputs.length);
        
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                this.validateMeasurement(input);
            });
        });
    }

    validateMeasurement(input) {
        const value = parseFloat(input.value);
        if (value < 20 || value > 60) {
            input.setCustomValidity('Please enter a realistic measurement (20-60 inches)');
        } else {
            input.setCustomValidity('');
        }
        input.reportValidity();
    }

    async analyzeBodyType() {
        const submitButton = this.form.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Analyzing...';
        
        try {
            const formData = new FormData(this.form);
            console.log('Sending data:', Object.fromEntries(formData));
            
            const response = await fetch('../actions/process_analysis.php', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Server response:', errorText);
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log('Received response:', data);
            
            if (data.success) {
                this.showResults(data.result.type.toLowerCase());
            } else {
                throw new Error(data.message || 'Analysis failed. Please try again.');
            }
        } catch (error) {
            console.error('Analysis error:', error);
            alert(error.message);
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Analyze My Body Type';
        }
    }

    determineBodyType(measurements) {
        console.log('Determining body type for measurements:', measurements);
        const shoulderHipRatio = measurements.shoulders / measurements.hips;
        const waistHipRatio = measurements.waist / measurements.hips;
        const bustWaistRatio = measurements.bust / measurements.waist;

        let scores = {
            hourglass: 0,
            pear: 0,
            apple: 0,
            rectangle: 0
        };

        if (Math.abs(shoulderHipRatio - 1) < 0.05) {
            scores.hourglass += 2;
            scores.rectangle += 1;
        } else if (shoulderHipRatio < 0.9) {
            scores.pear += 2;
        } else if (shoulderHipRatio > 1.1) {
            scores.apple += 2;
        }

        if (waistHipRatio < 0.75) {
            scores.hourglass += 2;
            scores.pear += 1;
        } else if (waistHipRatio > 0.85) {
            scores.rectangle += 2;
            scores.apple += 1;
        }

        switch (measurements.weightGain) {
            case 'upper':
                scores.apple += 2;
                break;
            case 'lower':
                scores.pear += 2;
                break;
            case 'middle':
                scores.apple += 1;
                break;
            case 'even':
                scores.rectangle += 2;
                break;
        }

        switch (measurements.shoulderType) {
            case 'broad':
                scores.apple += 1;
                break;
            case 'narrow':
                scores.pear += 1;
                break;
            case 'even':
                scores.hourglass += 1;
                scores.rectangle += 1;
                break;
        }

        switch (measurements.waistDefinition) {
            case 'very':
                scores.hourglass += 2;
                break;
            case 'somewhat':
                scores.pear += 1;
                break;
            case 'straight':
                scores.rectangle += 2;
                break;
        }

        const result = Object.entries(scores).reduce((a, b) => b[1] > a[1] ? b : a)[0];
        console.log('Determined body type:', result);
        return result;
    }

    showResults(bodyType) {
        console.log('Showing results for body type:', bodyType);
        const resultSection = document.querySelector('.analysis-result');
        const typeInfo = this.bodyTypes[bodyType];

        if (!resultSection || !typeInfo) {
            console.error('Result section or body type info not found');
            return;
        }

        document.querySelector('.measurement-form').style.display = 'none';
        resultSection.style.display = 'block';

        const typeResult = resultSection.querySelector('.body-type-result');
        const typeDescription = resultSection.querySelector('.body-type-description');
        const recommendationsList = resultSection.querySelector('.recommendations-list');
        const dosList = resultSection.querySelector('.dos-list');
        const dontsList = resultSection.querySelector('.donts-list');

        if (typeResult) typeResult.textContent = typeInfo.name;
        if (typeDescription) typeDescription.textContent = typeInfo.description;

        if (recommendationsList) {
            recommendationsList.innerHTML = typeInfo.recommendations
                .map(rec => `<div class="recommendation-item">${rec}</div>`)
                .join('');
        }

        if (dosList) {
            dosList.innerHTML = typeInfo.dos
                .map(item => `<li>${item}</li>`)
                .join('');
        }

        if (dontsList) {
            dontsList.innerHTML = typeInfo.donts
                .map(item => `<li>${item}</li>`)
                .join('');
        }

        resultSection.querySelectorAll('.recommendation-item, li').forEach((el, index) => {
            el.style.animation = `slideUp 0.5s ease forwards ${index * 0.1}s`;
        });

        this.initializeSaveButton(resultSection, typeInfo);
    }

    initializeSaveButton(resultSection, typeInfo) {
        console.log('Initializing save button');
        const saveButton = resultSection.querySelector('.save-result-btn');
        if (!saveButton) {
            console.error('Save button not found');
            return;
        }

        const newSaveButton = saveButton.cloneNode(true);
        saveButton.parentNode.replaceChild(newSaveButton, saveButton);
        
        newSaveButton.addEventListener('click', async () => {
            try {
                newSaveButton.disabled = true;
                newSaveButton.textContent = 'Saving...';
                console.log('Saving analysis...', typeInfo.name);

                const response = await fetch('../actions/save_analysis.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        bodyType: typeInfo.name
                    })
                });

                const data = await response.json();
                console.log('Save response:', data);
                
                if (data.success) {
                    newSaveButton.textContent = 'Saved!';
                    alert('Analysis saved successfully!');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    throw new Error(data.message || 'Failed to save analysis');
                }
            } catch (error) {
                console.error('Save error:', error);
                alert(error.message);
                newSaveButton.textContent = 'Save My Analysis';
                newSaveButton.disabled = false;
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing BodyTypeAnalyzer');
    try {
        const analyzer = new BodyTypeAnalyzer();
        if (!analyzer.form) {
            throw new Error('Body analysis form initialization failed');
        }
        console.log('BodyTypeAnalyzer initialized successfully');
    } catch (error) {
        console.error('Failed to initialize BodyTypeAnalyzer:', error);
    }
});