class StyleQuiz {
    constructor(quizData) {
        this.questions = quizData.questions;
        this.currentQuestion = 0;
        this.totalQuestions = quizData.totalQuestions;
        this.answers = {};
        this.styleScores = {
            classic: 0,
            edgy: 0,
            minimalist: 0,
            romantic: 0
        };
        this.savedResult = null;
        this.init();
    }

    init() {
        // Initialize DOM elements
        this.questionContainer = document.querySelector('.question-container');
        this.optionsContainer = document.querySelector('.options-container');
        this.progressBar = document.querySelector('.progress');
        this.categorySpan = document.querySelector('.category');
        this.questionCounter = document.querySelector('.question-counter');
        
        // Initialize event listeners
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Start quiz button
        const startButton = document.querySelector('.start-quiz-btn');
        if (startButton) {
            startButton.addEventListener('click', () => this.startQuiz());
        }

        // Action buttons
        const saveButton = document.querySelector('.save-results-btn');
        if (saveButton) {
            saveButton.addEventListener('click', () => this.saveResults());
        }

        const shareButton = document.querySelector('.share-results-btn');
        if (shareButton) {
            shareButton.addEventListener('click', () => this.shareResults());
        }

        // Take quiz button in history section
        const takeQuizBtn = document.querySelector('.take-quiz-btn');
        if (takeQuizBtn) {
            takeQuizBtn.addEventListener('click', () => {
                document.querySelector('[data-tab="quiz"]').click();
            });
        }
    }

    startQuiz() {
        document.getElementById('quizIntro').style.display = 'none';
        document.getElementById('quizContent').style.display = 'block';
        this.showQuestion();
    }

    showQuestion() {
        if (!this.questions[this.currentQuestion]) {
            console.error('Question not found:', this.currentQuestion);
            return;
        }

        const question = this.questions[this.currentQuestion];
        let options;
        
        try {
            options = JSON.parse(question.options).options;
        } catch (error) {
            console.error('Error parsing question options:', error);
            return;
        }

        // Update category and progress
        this.categorySpan.textContent = question.category.charAt(0).toUpperCase() + question.category.slice(1);
        this.updateProgress();

        // Show question
        this.questionContainer.innerHTML = `
            <h3>${question.question_text}</h3>
        `;

        // Show options
        this.optionsContainer.innerHTML = options.map((option, index) => `
            <div class="option-card" data-style="${option.style}" data-option-id="${option.id}">
                <div class="option-content">
                    <span class="option-text">${option.text}</span>
                </div>
            </div>
        `).join('');

        // Add click handlers to options
        this.optionsContainer.querySelectorAll('.option-card').forEach(card => {
            card.addEventListener('click', () => this.handleOptionSelect(card));
        });
    }

    handleOptionSelect(selectedOption) {
        // Remove selection from all options
        this.optionsContainer.querySelectorAll('.option-card').forEach(card => {
            card.classList.remove('selected');
        });

        // Add selection to clicked option
        selectedOption.classList.add('selected');

        // Save answer
        this.answers[this.currentQuestion] = {
            questionId: this.questions[this.currentQuestion].id,
            selectedStyle: selectedOption.dataset.style,
            optionId: selectedOption.dataset.optionId
        };

        // Update scores and proceed
        this.updateStyleScores(selectedOption.dataset.style);
        setTimeout(() => this.nextQuestion(), 500);
    }

    updateStyleScores(style) {
        if (this.styleScores.hasOwnProperty(style)) {
            this.styleScores[style]++;
        }
    }

    nextQuestion() {
        if (this.currentQuestion < this.totalQuestions - 1) {
            this.currentQuestion++;
            this.showQuestion();
        } else {
            this.showResults();
        }
    }

    updateProgress() {
        const progress = ((this.currentQuestion + 1) / this.totalQuestions) * 100;
        this.progressBar.style.width = `${progress}%`;
        this.questionCounter.textContent = `Question ${this.currentQuestion + 1} of ${this.totalQuestions}`;
    }

    async showResults() {
        try {
            const response = await fetch('../actions/process_quiz.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    answers: this.answers,
                    styleScores: this.styleScores
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const results = await response.json();

            if (results.success) {
                document.getElementById('quizContent').style.display = 'none';
                document.getElementById('quizResult').style.display = 'block';
                this.displayResults(results);
            } else {
                throw new Error(results.message || 'Error processing quiz results');
            }
        } catch (error) {
            console.error('Error processing quiz results:', error);
            this.showNotification('Failed to process quiz results. Please try again.', 'error');
        }
    }

    displayResults(results) {
        const resultContent = document.querySelector('.result-content');

        resultContent.innerHTML = `
            <div class="style-profile">
                <h3>Your Dominant Style: ${results.dominantStyle}</h3>
                <p class="style-description">${results.styleDescription}</p>
                
                <div class="style-breakdown">
                    <h4>Style Breakdown</h4>
                    ${Object.entries(results.styleScores).map(([style, score]) => `
                        <div class="style-score">
                            <div class="score-label">${style}: ${score}%</div>
                            <div class="score-bar">
                                <div class="score-fill" style="width: ${score}%"></div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <div class="recommendations">
                    <h4>Style Recommendations</h4>
                    <ul>
                        ${results.recommendations.map(rec => `
                            <li class="recommendation-item">
                                <span>→</span>
                                <span>${rec}</span>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            </div>
        `;
    }

    async saveResults() {
        if (this.savedResult) {
            this.showNotification('Results have already been saved!', 'info');
            return;
        }

        try {
            const response = await fetch('../actions/save_quiz_results.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    styleScores: this.styleScores,
                    answers: this.answers
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            if (data.success) {
                this.savedResult = data.result_id;
                this.showNotification('Results saved successfully!', 'success');
                // Refresh page after a short delay to show updated history
                setTimeout(() => location.reload(), 1500);
            } else {
                throw new Error(data.message || 'Failed to save results');
            }
        } catch (error) {
            console.error('Error saving results:', error);
            this.showNotification('Failed to save results. Please try again.', 'error');
        }
    }

    shareResults() {
        this.showNotification('Share functionality coming soon!', 'info');
    }

    showNotification(message, type = 'success') {
        const existingNotifications = document.querySelectorAll('.notification');
        existingNotifications.forEach(notification => notification.remove());

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 
                          type === 'error' ? 'exclamation-circle' : 
                          'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}


// Initialize quiz when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (typeof quizData !== 'undefined') {
        const quiz = new StyleQuiz(quizData);
    } else {
        console.error('Quiz data not found');
    }
});