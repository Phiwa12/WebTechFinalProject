// about.js
class AboutPage {
    constructor() {
        this.currentTestimonial = 0;
        this.testimonials = [
            {
                text: "StyleSense completely transformed my approach to fashion. I've never felt more confident!",
                author: "Emily Chen",
                role: "Fashion Blogger",
                image: "images/testimonials/emily.jpg"
            },
            // Add more testimonials...
        ];

        this.init();
    }

    init() {
        this.initializeAnimations();
        this.initializeTestimonials();
        this.initializeVideo();
        this.attachEventListeners();
    }

    initializeAnimations() {
        // Animate stats counting up
        const stats = document.querySelectorAll('.stat-number');
        const options = {
            threshold: 0.5
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = entry.target;
                    const finalValue = parseInt(target.textContent);
                    this.animateValue(target, 0, finalValue, 2000);
                    observer.unobserve(target);
                }
            });
        }, options);

        stats.forEach(stat => observer.observe(stat));
    }

    animateValue(element, start, end, duration) {
        const range = end - start;
        const increment = range / (duration / 16);
        let current = start;

        const animate = () => {
            current += increment;
            element.textContent = Math.floor(current).toLocaleString();

            if (current < end) {
                requestAnimationFrame(animate);
            } else {
                element.textContent = end.toLocaleString();
            }
        };

        animate();
    }

    initializeTestimonials() {
        const carousel = document.querySelector('.testimonials-carousel');
        carousel.innerHTML = `
            <div class="testimonial-track">
                ${this.testimonials.map((testimonial, index) => `
                    <div class="testimonial-slide ${index === 0 ? 'active' : ''}">
                        <div class="testimonial-content">
                            <p>"${testimonial.text}"</p>
                            <div class="testimonial-author">
                                <img src="${testimonial.image}" alt="${testimonial.author}">
                                <div class="author-info">
                                    <h4>${testimonial.author}</h4>
                                    <span>${testimonial.role}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="testimonial-controls">
                <button class="prev-btn"><i class="fas fa-chevron-left"></i></button>
                <div class="testimonial-dots">
                    ${this.testimonials.map((_, index) => `
                        <button class="dot ${index === 0 ? 'active' : ''}" 
                                data-index="${index}"></button>
                    `).join('')}
                </div>
                <button class="next-btn"><i class="fas fa-chevron-right"></i></button>
            </div>
        `;

        this.startTestimonialAutoplay();
    }

    startTestimonialAutoplay() {
        setInterval(() => {
            this.nextTestimonial();
        }, 5000);
    }

    nextTestimonial() {
        this.currentTestimonial = (this.currentTestimonial + 1) % this.testimonials.length;
        this.updateTestimonials();
    }

    previousTestimonial() {
        this.currentTestimonial = (this.currentTestimonial - 1 + this.testimonials.length) % this.testimonials.length;
        this.updateTestimonials();
    }

    updateTestimonials() {
        const slides = document.querySelectorAll('.testimonial-slide');
        const dots = document.querySelectorAll('.dot');

        slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === this.currentTestimonial);
        });

        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === this.currentTestimonial);
        });
    }

    initializeVideo() {
        const playBtn = document.querySelector('.play-btn');
        const videoModal = document.getElementById('videoModal');
        const closeBtn = videoModal.querySelector('.close-modal');

        playBtn.addEventListener('click', () => {
            videoModal.style.display = 'flex';
            videoModal.querySelector('.video-container').innerHTML = `
                <iframe src="https://www.youtube.com/embed/VIDEO_ID?autoplay=1" 
                        frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen>
                </iframe>
            `;
        });

        closeBtn.addEventListener('click', () => {
            videoModal.style.display = 'none';
            videoModal.querySelector('.video-container').innerHTML = '';
        });
    }

    attachEventListeners() {
        // Testimonial controls
        document.querySelector('.prev-btn').addEventListener('click', () => this.previousTestimonial());
        document.querySelector('.next-btn').addEventListener('click', () => this.nextTestimonial());
        document.querySelectorAll('.dot').forEach(dot => {
            dot.addEventListener('click', () => {
                this.currentTestimonial = parseInt(dot.dataset.index);
                this.updateTestimonials();
            });
        });

        // Smooth scroll for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                target.scrollIntoView({ behavior: 'smooth' });
            });
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const aboutPage = new AboutPage();

    // Additional functionality for team member interactions
    class TeamMemberInteraction {
        constructor() {
            this.initializeTeamInteractions();
        }

        initializeTeamInteractions() {
            const teamMembers = document.querySelectorAll('.team-member');
            
            teamMembers.forEach(member => {
                // Add hover effect for social links
                member.addEventListener('mouseenter', () => {
                    const socialLinks = member.querySelector('.social-links');
                    socialLinks.style.transform = 'translateY(0)';
                    socialLinks.style.opacity = '1';
                });

                member.addEventListener('mouseleave', () => {
                    const socialLinks = member.querySelector('.social-links');
                    socialLinks.style.transform = 'translateY(10px)';
                    socialLinks.style.opacity = '0';
                });

                // Add click handler for team member details
                member.addEventListener('click', () => {
                    this.showTeamMemberDetails(member.dataset.memberId);
                });
            });
        }

        showTeamMemberDetails(memberId) {
            const memberDetails = this.getTeamMemberDetails(memberId);
            const modal = document.createElement('div');
            modal.className = 'modal team-modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <button class="close-modal">
                        <i class="fas fa-times"></i>
                    </button>
                    <div class="member-details">
                        <img src="${memberDetails.image}" alt="${memberDetails.name}">
                        <h3>${memberDetails.name}</h3>
                        <span class="member-role">${memberDetails.role}</span>
                        <p class="member-bio">${memberDetails.bio}</p>
                        <div class="member-expertise">
                            <h4>Expertise</h4>
                            <ul>
                                ${memberDetails.expertise.map(item => `
                                    <li>${item}</li>
                                `).join('')}
                            </ul>
                        </div>
                        <div class="member-achievements">
                            <h4>Achievements</h4>
                            <ul>
                                ${memberDetails.achievements.map(item => `
                                    <li>${item}</li>
                                `).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
            `;

            document.body.appendChild(modal);
            setTimeout(() => modal.classList.add('active'), 10);

            // Close modal functionality
            const closeBtn = modal.querySelector('.close-modal');
            closeBtn.addEventListener('click', () => {
                modal.classList.remove('active');
                setTimeout(() => modal.remove(), 300);
            });
        }

        getTeamMemberDetails(memberId) {
            // Simulated team member data
            const teamData = {
                '1': {
                    name: 'Sarah Johnson',
                    role: 'Founder & CEO',
                    image: 'images/team/sarah.jpg',
                    bio: 'Fashion industry veteran with 15 years of experience...',
                    expertise: [
                        'Fashion Trend Analysis',
                        'Business Strategy',
                        'Brand Development'
                    ],
                    achievements: [
                        'Forbes 30 Under 30',
                        'Fashion Innovation Award 2023',
                        'Featured in Vogue Magazine'
                    ]
                }
                // Add more team members...
            };

            return teamData[memberId];
        }
    }

    // Initialize partners section with animations
    class PartnersSection {
        constructor() {
            this.initializePartners();
        }

        initializePartners() {
            const partners = document.querySelectorAll('.partner-logo');
            
            const observerOptions = {
                threshold: 0.5,
                rootMargin: '0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        this.animatePartnerLogo(entry.target);
                    }
                });
            }, observerOptions);

            partners.forEach(partner => observer.observe(partner));
        }

        animatePartnerLogo(logo) {
            logo.style.opacity = '0';
            logo.style.transform = 'scale(0.8)';

            setTimeout(() => {
                logo.style.transition = 'all 0.5s ease';
                logo.style.opacity = '1';
                logo.style.transform = 'scale(1)';
            }, 100);
        }
    }

    // Initialize awards section
    class AwardsSection {
        constructor() {
            this.initializeAwards();
        }

        initializeAwards() {
            const awards = document.querySelectorAll('.award-item');
            
            awards.forEach(award => {
                award.addEventListener('mouseenter', () => {
                    this.showAwardDetails(award);
                });
            });
        }

        showAwardDetails(award) {
            const details = award.dataset.details;
            const tooltip = document.createElement('div');
            tooltip.className = 'award-tooltip';
            tooltip.textContent = details;
            
            award.appendChild(tooltip);
            
            award.addEventListener('mouseleave', () => {
                tooltip.remove();
            });
        }
    }

    // Initialize scroll animations
    class ScrollAnimations {
        constructor() {
            this.initializeScrollEffects();
        }

        initializeScrollEffects() {
            const sections = document.querySelectorAll('section');
            
            const options = {
                threshold: 0.2,
                rootMargin: '0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        this.animateSection(entry.target);
                    }
                });
            }, options);

            sections.forEach(section => observer.observe(section));
        }

        animateSection(section) {
            const elements = section.querySelectorAll('.animate-on-scroll');
            
            elements.forEach((element, index) => {
                setTimeout(() => {
                    element.classList.add('animated');
                }, index * 200);
            });
        }
    }

    // Initialize all components
    new TeamMemberInteraction();
    new PartnersSection();
    new AwardsSection();
    new ScrollAnimations();

    // Add page load animations
    document.body.classList.add('loaded');
});

// Utility function for smooth scrolling
function smoothScroll(target, duration) {
    const targetPosition = target.getBoundingClientRect().top;
    const startPosition = window.pageYOffset;
    const distance = targetPosition - startPosition;
    let startTime = null;

    function animation(currentTime) {
        if (startTime === null) startTime = currentTime;
        const timeElapsed = currentTime - startTime;
        const run = ease(timeElapsed, startPosition, distance, duration);
        window.scrollTo(0, run);
        if (timeElapsed < duration) requestAnimationFrame(animation);
    }

    function ease(t, b, c, d) {
        t /= d / 2;
        if (t < 1) return c / 2 * t * t + b;
        t--;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }

    requestAnimationFrame(animation);
}