// Activity Chart
        const activityData = <?php echo json_encode($activity_data); ?>;
        new Chart(document.getElementById('activityChart'), {
            type: 'line',
            data: {
                labels: [...new Set(activityData.map(item => item.date))],
                datasets: [{
                    label: 'Daily Activity',
                    data: activityData.map(item => item.activity_count),
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Daily User Activity'
                    }
                }
            }
        });

        // Body Types Chart
    const bodyTypesData = <?php echo json_encode($body_types_data); ?>;
    new Chart(document.getElementById('bodyTypesChart'), {
        type: 'pie',
        data: {
            labels: bodyTypesData.map(item => item.body_type),
            datasets: [{
                data: bodyTypesData.map(item => item.count),
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right',
                },
                title: {
                    display: true,
                    text: 'Body Types Distribution'
                }
            }
        }
    });

    // Dominant Styles Chart
    const stylesData = <?php echo json_encode($styles_data); ?>;
new Chart(document.getElementById('stylesChart'), {
    type: 'doughnut',
    data: {
        labels: stylesData.map(item => 
            item.dominant_style.charAt(0).toUpperCase() + 
            item.dominant_style.slice(1).toLowerCase()
        ),
        datasets: [{
            data: stylesData.map(item => item.count),
            backgroundColor: [
                '#FF6B6B',  // Red
                '#4ECDC4',  // Teal
                '#45B7D1',  // Blue
                '#96CEB4',  // Green
                '#FFEEAD',  // Yellow
                '#D4A5A5',  // Pink
                '#9B786F'   // Brown
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'right',
                labels: {
                    font: {
                        size: 12
                    }
                }
            },
            title: {
                display: true,
                text: 'Style Preferences Distribution',
                font: {
                    size: 16,
                    weight: 'bold'
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const label = context.label || '';
                        const value = context.raw || 0;
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = Math.round((value / total) * 100);
                        return `${label}: ${value} (${percentage}%)`;
                    }
                }
            }
        }
    }
});

    // Product Categories Chart
    const categoriesData = <?php echo json_encode($categories_data); ?>;
    new Chart(document.getElementById('categoriesChart'), {
        type: 'bar',
        data: {
            labels: categoriesData.map(item => item.category),
            datasets: [{
                label: 'Number of Products',
                data: categoriesData.map(item => item.count),
                backgroundColor: '#FF1493',
                borderColor: '#388E3C',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Products by Category'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });