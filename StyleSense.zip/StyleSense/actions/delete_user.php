<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

// Check if user is super admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'super_admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access'
    ]);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['user_id'])) {
        throw new Exception('User ID is required');
    }

    $userId = (int)$data['user_id'];

    // Prevent self-deletion
    if ($userId === $_SESSION['user_id']) {
        throw new Exception('Cannot delete your own account');
    }

    mysqli_begin_transaction($db);

    // Delete user's data from related tables
    $tables = [
        'style_user_preferences',
        'style_wardrobe_items',
        'style_outfits',
        'user_cart'
    ];

    foreach ($tables as $table) {
        $stmt = $db->prepare("DELETE FROM $table WHERE user_id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
    }

    // Delete the user
    $stmt = $db->prepare("DELETE FROM style_users WHERE id = ?");
    $stmt->bind_param('i', $userId);
    
    if (!$stmt->execute()) {
        throw new Exception("Error deleting user");
    }

    mysqli_commit($db);

    echo json_encode([
        'success' => true,
        'message' => 'User deleted successfully'
    ]);

} catch (Exception $e) {
    mysqli_rollback($db);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>