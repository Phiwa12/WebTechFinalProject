<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // Get login credentials
    $identifier = isset($_POST['email']) ? $_POST['email'] : $_POST['phone'];
    $password = $_POST['password'];

    // Validate required fields
    if (empty($identifier) || empty($password)) {
        throw new Exception('Please fill in all required fields');
    }

    // Determine if email or phone is used
    $isEmail = filter_var($identifier, FILTER_VALIDATE_EMAIL);
    
    // Prepare query based on identifier type
    $query = "SELECT id, full_name, password_hash FROM style_users WHERE ";
    $query .= $isEmail ? "email = ?" : "phone = ?";
    
    $stmt = $db->prepare($query);
    if (!$stmt) {
        throw new Exception("Database error: " . $db->error);
    }

    $stmt->bind_param("s", $identifier);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception('Invalid credentials');
    }

    $user = $result->fetch_assoc();

    // Verify password
    if (!password_verify($password, $user['password_hash'])) {
        throw new Exception('Invalid credentials');
    }

    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['full_name'] = $user['full_name'];

    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Login successful',
        'redirect' => '../view/services.php'
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}