<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('User not authenticated');
    }

    // Calculate dominant style
    $styleScores = $data['styleScores'];
    arsort($styleScores);
    $dominantStyle = array_key_first($styleScores);

    // Convert scores to percentages
    $total = array_sum($styleScores);
    $styleScores = array_map(function($score) use ($total) {
        return round(($score / $total) * 100);
    }, $styleScores);

    // Complete style profiles with descriptions and recommendations
    $styleProfiles = [
        'classic' => [
            'description' => 'You appreciate timeless elegance and sophisticated style. Your wardrobe consists of well-made basics and refined pieces that never go out of style.',
            'recommendations' => [
                'Invest in high-quality basics like blazers, white shirts, and tailored trousers',
                'Stick to a neutral color palette with navy, black, white, and beige',
                'Choose structured silhouettes and tailored pieces',
                'Accessorize with pearls, delicate jewelry, and classic watches',
                'Focus on quality over quantity in your wardrobe'
            ]
        ],
        'edgy' => [
            'description' => 'You have a bold, adventurous style that pushes boundaries. You\'re not afraid to make a statement and express yourself through fashion.',
            'recommendations' => [
                'Experiment with unique textures like leather and metallic materials',
                'Mix unexpected combinations of pieces',
                'Incorporate statement accessories and bold jewelry',
                'Play with asymmetrical cuts and unusual silhouettes',
                'Don\'t shy away from bold colors and patterns'
            ]
        ],
        'minimalist' => [
            'description' => 'You prefer clean lines, simple shapes, and a streamlined approach to dressing. Quality and functionality are key elements of your style.',
            'recommendations' => [
                'Build a capsule wardrobe with versatile pieces',
                'Focus on solid colors and simple patterns',
                'Choose clean lines and modern silhouettes',
                'Invest in quality basics that work well together',
                'Keep accessories subtle and functional'
            ]
        ],
        'romantic' => [
            'description' => 'Your style embraces femininity and softness. You\'re drawn to beautiful details and enjoy expressing yourself through delicate, pretty pieces.',
            'recommendations' => [
                'Look for pieces with feminine details like ruffles and lace',
                'Embrace soft, flowing fabrics and silhouettes',
                'Choose a color palette with pastels and soft hues',
                'Accessorize with delicate jewelry and romantic details',
                'Mix textures and patterns for visual interest'
            ]
        ]
    ];

    // Additional style tips based on dominant style
    $styleTips = [
        'classic' => [
            'wardrobe_essentials' => [
                'Tailored blazer',
                'White button-down shirt',
                'Little black dress',
                'Well-fitted trousers',
                'Quality leather pumps'
            ],
            'color_palette' => ['Navy', 'Black', 'White', 'Beige', 'Gray'],
            'avoid' => [
                'Overly trendy pieces',
                'Fast fashion items',
                'Excessive patterns',
                'Ultra-casual items'
            ]
        ],
        'edgy' => [
            'wardrobe_essentials' => [
                'Leather jacket',
                'Statement boots',
                'Unique denim pieces',
                'Graphic t-shirts',
                'Statement accessories'
            ],
            'color_palette' => ['Black', 'White', 'Red', 'Metallic', 'Deep Purple'],
            'avoid' => [
                'Overly preppy pieces',
                'Traditional office wear',
                'Plain basics without interest',
                'Conventional styling'
            ]
        ],
        'minimalist' => [
            'wardrobe_essentials' => [
                'Simple t-shirts',
                'Straight-leg trousers',
                'Sleek sneakers',
                'Modern jewelry',
                'Quality basics'
            ],
            'color_palette' => ['White', 'Black', 'Gray', 'Beige', 'Navy'],
            'avoid' => [
                'Busy patterns',
                'Excessive details',
                'Complicated silhouettes',
                'Too many accessories'
            ]
        ],
        'romantic' => [
            'wardrobe_essentials' => [
                'Floral dresses',
                'Silk blouses',
                'A-line skirts',
                'Delicate cardigans',
                'Pretty flats'
            ],
            'color_palette' => ['Pink', 'Light Blue', 'Lavender', 'Cream', 'Soft Yellow'],
            'avoid' => [
                'Harsh lines',
                'Overly structured pieces',
                'Heavy materials',
                'Aggressive styling'
            ]
        ]
    ];

    // Prepare result data
    $resultData = [
        'dominant_style' => $dominantStyle,
        'style_scores' => $styleScores,
        'profile' => $styleProfiles[$dominantStyle],
        'tips' => $styleTips[$dominantStyle]
    ];

    // Save results to database
    $stmt = $db->prepare("
        INSERT INTO style_quiz_results 
        (user_id, quiz_answers, style_profile, recommendations, taken_at)
        VALUES (?, ?, ?, ?, NOW())
    ");

    $quizAnswers = json_encode($data['answers']);
    $styleProfile = json_encode([
        'dominant_style' => $dominantStyle,
        'style_scores' => $styleScores,
        'profile_description' => $styleProfiles[$dominantStyle]['description']
    ]);
    $recommendations = json_encode([
        'general' => $styleProfiles[$dominantStyle]['recommendations'],
        'wardrobe_essentials' => $styleTips[$dominantStyle]['wardrobe_essentials'],
        'color_palette' => $styleTips[$dominantStyle]['color_palette'],
        'avoid' => $styleTips[$dominantStyle]['avoid']
    ]);

    $stmt->bind_param(
        "ssss",
        $_SESSION['user_id'],
        $quizAnswers,
        $styleProfile,
        $recommendations
    );

    if (!$stmt->execute()) {
        throw new Exception('Failed to save quiz results');
    }

    // Log the activity
    $activityStmt = $db->prepare("
        INSERT INTO style_activity_log 
        (user_id, activity_type, details) 
        VALUES (?, 'quiz_completed', ?)
    ");

    $activityDetails = json_encode([
        'quiz_result_id' => $stmt->insert_id,
        'dominant_style' => $dominantStyle,
        'completed_at' => date('Y-m-d H:i:s')
    ]);

    $activityStmt->bind_param("is", $_SESSION['user_id'], $activityDetails);
    $activityStmt->execute();

    // Send results back to client
    echo json_encode([
        'success' => true,
        'dominantStyle' => ucfirst($dominantStyle),
        'styleDescription' => $styleProfiles[$dominantStyle]['description'],
        'recommendations' => $styleProfiles[$dominantStyle]['recommendations'],
        'styleScores' => $styleScores,
        'additionalTips' => $styleTips[$dominantStyle],
        'result_id' => $stmt->insert_id
    ]);

} catch (Exception $e) {
    error_log("Quiz processing error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>