<?php
// actions/update_product.php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Only super_admin can modify products
requireSuperAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

try {
    $data = $_POST;
    $productId = isset($data['id']) ? (int)$data['id'] : null;
    $isNewProduct = empty($productId);

    // Validate required fields
    $requiredFields = ['name', 'price', 'category', 'type', 'description'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }

    // Validate price
    if (!is_numeric($data['price']) || $data['price'] < 0) {
        throw new Exception("Invalid price value");
    }

    // Validate category and type
    $validCategories = ['tops', 'bottoms', 'dresses', 'shoes', 'accessories', 'outerwear'];
    $validTypes = ['casual', 'formal', 'business', 'party'];

    if (!in_array($data['category'], $validCategories)) {
        throw new Exception("Invalid category");
    }

    if (!in_array($data['type'], $validTypes)) {
        throw new Exception("Invalid type");
    }

    $db->begin_transaction();

    // Prepare the data for binding
    $name = $data['name'];
    $price = $data['price'];
    $category = $data['category'];
    $type = $data['type'];
    $description = $data['description'];
    $color = $data['color'] ?? '#000000';
    $imageUrl = $data['image_url'] ?? '';

    if ($isNewProduct) {
        // Insert new product
        $query = "INSERT INTO shop_products (name, price, category, type, description, color, image_url) 
                 VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        $stmt->bind_param("sdsssss",
            $name,
            $price,
            $category,
            $type,
            $description,
            $color,
            $imageUrl
        );
    } else {
        // Update existing product
        $query = "UPDATE shop_products 
                 SET name = ?, price = ?, category = ?, type = ?, 
                     description = ?, color = ?, image_url = ?
                 WHERE id = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("sdsssssi",
            $name,
            $price,
            $category,
            $type,
            $description,
            $color,
            $imageUrl,
            $productId
        );
    }

    if (!$stmt->execute()) {
        throw new Exception("Error saving product: " . $stmt->error);
    }

    // Get the product ID for logging
    $affectedProductId = $isNewProduct ? $db->insert_id : $productId;

    // Log the activity
    $activityType = $isNewProduct ? 'product_created' : 'product_updated';
    $details = json_encode([
        'product_id' => $affectedProductId,
        'product_name' => $name,
        'action_by' => $_SESSION['user_id']
    ]);

    $userId = $_SESSION['user_id'];
    $logStmt = $db->prepare("INSERT INTO style_activity_log (user_id, activity_type, details) VALUES (?, ?, ?)");
    $logStmt->bind_param("iss", $userId, $activityType, $details);
    $logStmt->execute();

    $db->commit();
    echo json_encode([
        'success' => true, 
        'message' => $isNewProduct ? 'Product added successfully' : 'Product updated successfully'
    ]);

} catch (Exception $e) {
    $db->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}