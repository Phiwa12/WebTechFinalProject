<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $itemId = $data['item_id'] ?? null;
    $userId = $_SESSION['user_id'];

    if (!$itemId) {
        throw new Exception('Item ID is required');
    }

    // Verify item belongs to user and delete it
    $stmt = $db->prepare("DELETE FROM style_wardrobe_items WHERE id = ? AND user_id = ?");
    $stmt->bind_param('ii', $itemId, $userId);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        throw new Exception('Item not found or already deleted');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Item deleted successfully'
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>