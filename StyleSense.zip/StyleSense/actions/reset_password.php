<?php
// reset_password.php - Handles the initial reset request
session_start();
require_once('../db/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($db, $_POST['reset_email']);
    
    // Check if email exists
    $query = "SELECT id, email, full_name FROM style_users WHERE email = ? AND status = 'active'";
    $stmt = $db->prepare($query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Generate reset code
        $reset_code = sprintf("%06d", mt_rand(100000, 999999));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Store reset code in database
        $store_code = "INSERT INTO password_resets (user_id, reset_code, expiry) VALUES (?, ?, ?)";
        $stmt = $db->prepare($store_code);
        $stmt->bind_param('iss', $user['id'], $reset_code, $expiry);
        $stmt->execute();
        
        // Send email with reset code
        $to = $user['email'];
        $subject = "StyleSense Password Reset Code";
        $message = "Hello " . htmlspecialchars($user['full_name']) . ",\n\n";
        $message .= "Your password reset code is: " . $reset_code . "\n";
        $message .= "This code will expire in 1 hour.\n\n";
        $message .= "If you did not request this reset, please ignore this email.\n";
        $headers = "From: noreply@stylesense.com";
        
        mail($to, $subject, $message, $headers);
        
        // Redirect to code verification page
        $_SESSION['reset_email'] = $email;
        header('Location: ../view/verify_reset_code.php');
        exit();
    }
    // Don't reveal if email exists or not
    header('Location: ../view/verify_reset_code.php');
    exit();
}
?>