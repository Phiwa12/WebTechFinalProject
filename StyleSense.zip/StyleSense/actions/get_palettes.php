<?php
// actions/get_palettes.php
session_start();
require_once '../db/config.php';
require_once '../functions/color_functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $stmt = $db->prepare("
        SELECT sp.*, 
               DATE_FORMAT(sp.created_at, '%M %d, %Y') as created_date
        FROM style_color_palettes sp
        WHERE sp.user_id = ?
        ORDER BY sp.created_at DESC
    ");

    if (!$stmt) {
        throw new Exception("Database error: " . $db->error);
    }

    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    $palettes = [];
    while ($row = $result->fetch_assoc()) {
        $palettes[] = [
            'id' => $row['id'],
            'name' => $row['palette_name'],
            'colors' => json_decode($row['colors'], true),
            'season' => $row['season'],
            'combinations' => json_decode($row['combinations'], true),
            'created_at' => $row['created_date']
        ];
    }

    echo json_encode([
        'success' => true,
        'palettes' => $palettes
    ]);

} catch (Exception $e) {
    error_log("Error fetching palettes: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to fetch palettes'
    ]);
}
?>