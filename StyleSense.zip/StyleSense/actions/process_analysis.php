<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0); 
ini_set('log_errors', 1); // Enable error logging

require_once '../db/config.php';
require_once '../functions/body_functions.php';

header('Content-Type: application/json');

function debugLog($message, $data = null) {
    error_log("DEBUG: " . $message);
    if ($data !== null) {
        error_log("DATA: " . print_r($data, true));
    }
}


try {
    // Check database connection first
    if (!isset($db) || !($db instanceof mysqli)) {
        throw new Exception('Database connection not established');
    }

    if ($db->connect_error) {
        throw new Exception("Database connection failed: " . $db->connect_error);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    if (!isset($_SESSION['user_id'])) {
        throw new Exception('User not authenticated');
    }

    // Log received data
    debugLog("Received POST data", $_POST);

    // Validate measurements
    $measurements = [
        'shoulders' => filter_input(INPUT_POST, 'shoulders', FILTER_VALIDATE_FLOAT),
        'bust' => filter_input(INPUT_POST, 'bust', FILTER_VALIDATE_FLOAT),
        'waist' => filter_input(INPUT_POST, 'waist', FILTER_VALIDATE_FLOAT),
        'hips' => filter_input(INPUT_POST, 'hips', FILTER_VALIDATE_FLOAT)
    ];

    foreach ($measurements as $key => $value) {
        if ($value === false || $value === null) {
            throw new Exception("Invalid measurement for $key: " . ($_POST[$key] ?? 'not set'));
        }
    }

    $additionalDetails = [
        'weightGain' => $_POST['weightGain'] ?? '',
        'shoulderType' => $_POST['shoulderType'] ?? '',
        'waistDefinition' => $_POST['waistDefinition'] ?? ''
    ];

    foreach ($additionalDetails as $key => $value) {
        if (empty($value)) {
            throw new Exception("Missing value for $key");
        }
    }

    // Start transaction
    $db->begin_transaction();

    try {
        // Determine body type
        $shoulderHipRatio = $measurements['shoulders'] / $measurements['hips'];
        $waistHipRatio = $measurements['waist'] / $measurements['hips'];

        // Calculate body type
        $bodyType = '';
        if (abs($shoulderHipRatio - 1) < 0.05 && $waistHipRatio < 0.75) {
            $bodyType = 'Hourglass';
        } elseif ($shoulderHipRatio < 0.9) {
            $bodyType = 'Pear';
        } elseif ($shoulderHipRatio > 1.1) {
            $bodyType = 'Apple';
        } else {
            $bodyType = 'Rectangle';
        }

        // Get recommendations
        $recommendations = [
            'description' => "Your body measurements suggest you have a $bodyType body type.",
            'recommendations' => [],
            'dos' => [],
            'donts' => []
        ];

        // Insert into database
        $stmt = $db->prepare("
            INSERT INTO body_measurements 
            (user_id, shoulders, bust, waist, hips, 
             weight_gain_pattern, shoulder_type, waist_definition, 
             body_type, recommendations)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            throw new Exception("Failed to prepare statement: " . $db->error);
        }

        $recommendationsJson = json_encode($recommendations);
        
        $stmt->bind_param("idddssssss",
            $_SESSION['user_id'],
            $measurements['shoulders'],
            $measurements['bust'],
            $measurements['waist'],
            $measurements['hips'],
            $additionalDetails['weightGain'],
            $additionalDetails['shoulderType'],
            $additionalDetails['waistDefinition'],
            $bodyType,
            $recommendationsJson
        );

        if (!$stmt->execute()) {
            throw new Exception("Failed to execute statement: " . $stmt->error);
        }

        $db->commit();

        // Send response
        echo json_encode([
            'success' => true,
            'result' => [
                'type' => $bodyType,
                'description' => $recommendations['description'],
                'recommendations' => $recommendations['recommendations'],
                'dos' => $recommendations['dos'],
                'donts' => $recommendations['donts']
            ]
        ]);

    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    error_log("Process Analysis Error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function determineBodyType($measurements, $additionalDetails) {
    // Calculate ratios
    $shoulderHipRatio = $measurements['shoulders'] / $measurements['hips'];
    $waistHipRatio = $measurements['waist'] / $measurements['hips'];

    // Initialize scores
    $scores = [
        'Hourglass' => 0,
        'Pear' => 0,
        'Apple' => 0,
        'Rectangle' => 0
    ];

    // Score based on measurements
    if (abs($shoulderHipRatio - 1) < 0.05) {
        $scores['Hourglass'] += 2;
        $scores['Rectangle'] += 1;
    } elseif ($shoulderHipRatio < 0.9) {
        $scores['Pear'] += 2;
    } elseif ($shoulderHipRatio > 1.1) {
        $scores['Apple'] += 2;
    }

    if ($waistHipRatio < 0.75) {
        $scores['Hourglass'] += 2;
        $scores['Pear'] += 1;
    } elseif ($waistHipRatio > 0.85) {
        $scores['Rectangle'] += 2;
        $scores['Apple'] += 1;
    }

    // Score based on additional details
    switch ($additionalDetails['weightGain']) {
        case 'upper': $scores['Apple'] += 2; break;
        case 'lower': $scores['Pear'] += 2; break;
        case 'middle': $scores['Apple'] += 1; break;
        case 'even': $scores['Rectangle'] += 2; break;
    }

    switch ($additionalDetails['shoulderType']) {
        case 'broad': $scores['Apple'] += 1; break;
        case 'narrow': $scores['Pear'] += 1; break;
        case 'even':
            $scores['Hourglass'] += 1;
            $scores['Rectangle'] += 1;
            break;
    }

    switch ($additionalDetails['waistDefinition']) {
        case 'very': $scores['Hourglass'] += 2; break;
        case 'somewhat': $scores['Pear'] += 1; break;
        case 'straight': $scores['Rectangle'] += 2; break;
    }

    // Determine highest scoring type
    arsort($scores);
    return key($scores);
}

function getRecommendations($bodyType) {
    $recommendations = [
        'Hourglass' => [
            'description' => 'Your shoulders and hips are about the same width with a significantly smaller waist.',
            'recommendations' => [
                'Fitted clothing that shows off your natural curves',
                'Wrap dresses and tops',
                'High-waisted bottoms',
                'Belt to emphasize waist'
            ],
            'dos' => [
                'Emphasize your waist',
                'Choose fitted styles',
                'Use belts to define your middle',
                'Wear v-neck or scoop necklines'
            ],
            'donts' => [
                'Wear boxy or shapeless clothing',
                'Choose overwhelming ruffles or volume',
                'Hide your waist',
                'Wear overly loose styles'
            ]
        ],
        'Pear' => [
            'description' => 'Your hips are wider than your shoulders with a defined waist.',
            'recommendations' => [
                'A-line skirts and dresses',
                'Boat neck and wide necklines',
                'Fitted tops with flared bottoms',
                'Dark colors for bottom half'
            ],
            'dos' => [
                'Draw attention to your upper body',
                'Wear bright colors on top',
                'Choose A-line silhouettes',
                'Opt for statement necklines'
            ],
            'donts' => [
                'Wear tight-fitting bottoms',
                'Choose bottoms with large patterns',
                'Wear cropped tops',
                'Choose skinny straps'
            ]
        ],
        'Apple' => [
            'description' => 'Your shoulders and bust are wider than your hips with less waist definition.',
            'recommendations' => [
                'Empire waist dresses',
                'V-neck tops',
                'Flowy fabrics',
                'A-line silhouettes'
            ],
            'dos' => [
                'Create vertical lines',
                'Choose empire waist styles',
                'Wear V-necks',
                'Opt for flowing fabrics'
            ],
            'donts' => [
                'Wear tight-fitting waistbands',
                'Choose bulky fabrics',
                'Wear heavy belts',
                'Add volume at the waist'
            ]
        ],
        'Rectangle' => [
            'description' => 'Your shoulders, waist, and hips are similar in width.',
            'recommendations' => [
                'Ruffles and layers to create curves',
                'Peplum tops',
                'Belt to create waist definition',
                'Asymmetrical designs'
            ],
            'dos' => [
                'Create curves with clothing',
                'Use layers and ruffles',
                'Wear belts and waist-defining pieces',
                'Try asymmetrical designs'
            ],
            'donts' => [
                'Wear straight, shapeless clothing',
                'Choose plain, unstructured pieces',
                'Wear oversized clothing',
                'Stick to one silhouette'
            ]
        ]
    ];

    

    return $recommendations[$bodyType] ?? [
        'description' => 'Custom recommendations will be provided shortly.',
        'recommendations' => [],
        'dos' => [],
        'donts' => []
    ];
}
?>

