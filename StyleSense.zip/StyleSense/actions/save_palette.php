<?php
// actions/save_palette.php
session_start();
require_once '../db/config.php';
require_once '../functions/color_functions.php';

header('Content-Type: application/json');

// Enable error logging
ini_set('display_errors', 1);
error_reporting(E_ALL);
error_log("Save palette request received");

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    // Get and validate the input data
    $rawData = file_get_contents('php://input');
    error_log("Received data: " . $rawData);
    
    $data = json_decode($rawData, true);
    if (!$data) {
        throw new Exception('Invalid JSON data received');
    }

    if (!isset($data['colors']) || empty($data['colors'])) {
        throw new Exception('No colors provided');
    }

    // Generate combinations for the colors
    $combinations = [];
    foreach ($data['colors'] as $color) {
        $combinations[$color] = generateColorCombinations($color);
    }

    // Prepare the data for insertion
    $stmt = $db->prepare("
        INSERT INTO style_color_palettes 
        (user_id, palette_name, colors, season, combinations) 
        VALUES (?, ?, ?, ?, ?)
    ");

    if (!$stmt) {
        throw new Exception("Database preparation error: " . $db->error);
    }

    $colors = json_encode($data['colors']);
    $paletteName = $data['name'] ?? 'My Palette ' . date('Y-m-d H:i:s');
    $season = $data['season'] ?? null;
    $combinationsJson = json_encode($combinations);

    $stmt->bind_param("issss", 
        $_SESSION['user_id'],
        $paletteName,
        $colors,
        $season,
        $combinationsJson
    );

    if (!$stmt->execute()) {
        throw new Exception("Error executing query: " . $stmt->error);
    }

    // Log the activity
    $activityStmt = $db->prepare("
        INSERT INTO style_activity_log 
        (user_id, activity_type, details) 
        VALUES (?, 'palette_saved', ?)
    ");

    $activityDetails = json_encode([
        'palette_id' => $db->insert_id,
        'name' => $paletteName,
        'colors_count' => count($data['colors']),
        'saved_at' => date('Y-m-d H:i:s')
    ]);

    $activityStmt->bind_param("is", $_SESSION['user_id'], $activityDetails);
    $activityStmt->execute();

    echo json_encode([
        'success' => true,
        'message' => 'Palette saved successfully',
        'paletteId' => $db->insert_id
    ]);

} catch (Exception $e) {
    error_log("Save palette error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>