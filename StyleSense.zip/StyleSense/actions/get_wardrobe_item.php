<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $itemId = $data['item_id'] ?? null;
    $userId = $_SESSION['user_id'];

    if (!$itemId) {
        throw new Exception('Item ID is required');
    }

    $stmt = $db->prepare("
        SELECT * FROM style_wardrobe_items 
        WHERE id = ? AND user_id = ? AND status = 'active'
    ");
    $stmt->bind_param('ii', $itemId, $userId);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();

    if (!$item) {
        throw new Exception('Item not found');
    }

    echo json_encode([
        'success' => true,
        'item' => $item
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>