<?php
// actions/delete_product.php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

// Only super_admin can delete products
requireSuperAdmin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['product_id'])) {
        throw new Exception('Product ID is required');
    }

    $productId = (int)$data['product_id'];

    $db->begin_transaction();

    // Get product details before deletion for logging
    $stmt = $db->prepare("SELECT name FROM shop_products WHERE id = ?");
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if (!$product) {
        throw new Exception("Product not found");
    }

    // First delete from cart (due to foreign key constraints)
    $stmt = $db->prepare("DELETE FROM user_cart WHERE product_id = ?");
    $stmt->bind_param('i', $productId);
    $stmt->execute();

    

    // Then delete the product
    $stmt = $db->prepare("DELETE FROM shop_products WHERE id = ?");
    $stmt->bind_param('i', $productId);
    
    if (!$stmt->execute()) {
        throw new Exception("Error deleting product");
    }

    // Log the deletion
    $details = json_encode([
        'product_id' => $productId,
        'product_name' => $product['name'],
        'action_by' => $_SESSION['user_id']
    ]);

    $logStmt = $db->prepare("INSERT INTO style_activity_log (user_id, activity_type, details) VALUES (?, 'product_deleted', ?)");
    $logStmt->bind_param("is", $_SESSION['user_id'], $details);
    $logStmt->execute();

    $db->commit();
    echo json_encode(['success' => true, 'message' => 'Product deleted successfully']);

} catch (Exception $e) {
    $db->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}