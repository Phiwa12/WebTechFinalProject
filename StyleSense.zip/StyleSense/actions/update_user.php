<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

// Check if user is super admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'super_admin') {
    echo json_encode([
        'success' => false,
        'message' => 'Unauthorized access'
    ]);
    exit;
}

try {
    // Get and sanitize form data
    $userId = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $userData = [
        'full_name' => trim(mysqli_real_escape_string($db, $_POST['full_name'])),
        'email' => trim(mysqli_real_escape_string($db, $_POST['email'])),
        'role' => trim(mysqli_real_escape_string($db, $_POST['role'])),
        'status' => trim(mysqli_real_escape_string($db, $_POST['status'])),
        'password' => !empty($_POST['password']) ? trim($_POST['password']) : null
    ];

    // Start transaction
    mysqli_begin_transaction($db);

    // Check if email exists (excluding current user)
    $emailCheckStmt = $db->prepare("SELECT id FROM style_users WHERE email = ? AND id != ?");
    $emailCheckStmt->bind_param("si", $userData['email'], $userId);
    $emailCheckStmt->execute();
    if ($emailCheckStmt->get_result()->num_rows > 0) {
        throw new Exception("Email already exists");
    }

    if ($userId > 0) {
        // Update existing user
        $query = "UPDATE style_users SET 
                    full_name = ?,
                    email = ?,
                    role = ?,
                    status = ?";
        $params = [$userData['full_name'], $userData['email'], $userData['role'], $userData['status']];
        $types = "ssss";

        // Add password to update if provided
        if (!empty($userData['password'])) {
            $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
            $query .= ", password_hash = ?";
            $params[] = $hashedPassword;
            $types .= "s";
        }

        $query .= " WHERE id = ?";
        $params[] = $userId;
        $types .= "i";

        $stmt = $db->prepare($query);
        $stmt->bind_param($types, ...$params);
    } else {
        // Insert new user
        if (empty($userData['password'])) {
            throw new Exception("Password is required for new users");
        }
        $hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);
        $stmt = $db->prepare("
            INSERT INTO style_users (
                full_name, 
                email, 
                password_hash, 
                role, 
                status, 
                created_at
            ) VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("sssss", 
            $userData['full_name'], 
            $userData['email'], 
            $hashedPassword, 
            $userData['role'], 
            $userData['status']
        );
    }

    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }

    mysqli_commit($db);

    echo json_encode([
        'success' => true,
        'message' => $userId ? 'User updated successfully' : 'User created successfully'
    ]);

} catch (Exception $e) {
    mysqli_rollback($db);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>