<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    // Get and validate input data
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['styleScores']) || !isset($data['answers'])) {
        throw new Exception('Invalid quiz data provided');
    }

    // Validate style scores
    $validStyles = ['classic', 'edgy', 'minimalist', 'romantic'];
    $styleScores = $data['styleScores'];
    
    foreach ($styleScores as $style => $score) {
        if (!in_array($style, $validStyles)) {
            throw new Exception('Invalid style category detected');
        }
        if (!is_numeric($score)) {
            throw new Exception('Invalid score value detected');
        }
    }

    // Calculate total score and convert to percentages
    $totalScore = array_sum($styleScores);
    if ($totalScore == 0) {
        throw new Exception('Invalid scores: total is 0');
    }

    $normalizedScores = array_map(function($score) use ($totalScore) {
        return round(($score / $totalScore) * 100, 1);
    }, $styleScores);

    // Determine dominant style
    arsort($normalizedScores);
    $dominantStyle = array_key_first($normalizedScores);

    // Prepare style profile data
    $styleProfiles = [
        'classic' => [
            'description' => 'You prefer timeless, sophisticated pieces that never go out of style.',
            'recommendations' => [
                'Invest in high-quality basic pieces',
                'Focus on neutral colors',
                'Choose structured silhouettes',
                'Prioritize classic patterns',
                'Select traditional accessories'
            ]
        ],
        'edgy' => [
            'description' => 'You love making bold fashion statements and pushing style boundaries.',
            'recommendations' => [
                'Experiment with unique textures',
                'Mix unexpected pieces',
                'Try asymmetrical designs',
                'Incorporate statement accessories',
                'Play with contrasting elements'
            ]
        ],
        'minimalist' => [
            'description' => 'You appreciate clean lines and simple, functional fashion.',
            'recommendations' => [
                'Focus on quality basics',
                'Keep accessories subtle',
                'Choose monochromatic looks',
                'Prioritize clean lines',
                'Select versatile pieces'
            ]
        ],
        'romantic' => [
            'description' => 'You gravitate towards soft, feminine pieces with delicate details.',
            'recommendations' => [
                'Choose flowing fabrics',
                'Incorporate feminine details',
                'Select soft color palettes',
                'Add romantic accessories',
                'Layer delicate pieces'
            ]
        ]
    ];

    // Start transaction
    mysqli_begin_transaction($db);

    // Save quiz results
    $stmt = $db->prepare("
        INSERT INTO style_quiz_results 
        (user_id, quiz_answers, style_profile, recommendations, taken_at)
        VALUES (?, ?, ?, ?, NOW())
    ");

    // Prepare data for storage
    $quizAnswers = json_encode($data['answers']);
    $styleProfile = json_encode([
        'dominant_style' => $dominantStyle,
        'style_scores' => $normalizedScores,
        'profile_description' => $styleProfiles[$dominantStyle]['description']
    ]);
    $recommendations = json_encode([
        'general' => $styleProfiles[$dominantStyle]['recommendations'],
        'taken_at' => date('Y-m-d H:i:s')
    ]);

    $stmt->bind_param("ssss", 
        $_SESSION['user_id'],
        $quizAnswers,
        $styleProfile,
        $recommendations
    );

    if (!$stmt->execute()) {
        throw new Exception('Failed to save quiz results: ' . $stmt->error);
    }

    $resultId = $stmt->insert_id;

    // Log the activity
    $activityStmt = $db->prepare("
        INSERT INTO style_activity_log 
        (user_id, activity_type, details)
        VALUES (?, 'quiz_results_saved', ?)
    ");

    $activityDetails = json_encode([
        'quiz_result_id' => $resultId,
        'dominant_style' => $dominantStyle,
        'saved_at' => date('Y-m-d H:i:s')
    ]);

    $activityStmt->bind_param("is", $_SESSION['user_id'], $activityDetails);
    
    if (!$activityStmt->execute()) {
        throw new Exception('Failed to log activity: ' . $activityStmt->error);
    }

    // Commit transaction
    mysqli_commit($db);

    // Send success response
    echo json_encode([
        'success' => true,
        'message' => 'Quiz results saved successfully',
        'result_id' => $resultId,
        'dominant_style' => $dominantStyle,
        'style_scores' => $normalizedScores,
        'recommendations' => $styleProfiles[$dominantStyle]['recommendations']
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    mysqli_rollback($db);
    
    error_log("Error saving quiz results: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Close database connection
if (isset($stmt)) $stmt->close();
if (isset($activityStmt)) $activityStmt->close();
mysqli_close($db);
?>