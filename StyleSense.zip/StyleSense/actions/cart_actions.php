<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    $productId = $data['product_id'] ?? null;
    $userId = $_SESSION['user_id'];

    switch ($action) {
        case 'get':
            // Get current cart items
            $stmt = $db->prepare("
                SELECT c.*, p.name, p.price, p.image_url, p.color 
                FROM user_cart c 
                JOIN shop_products p ON c.product_id = p.id 
                WHERE c.user_id = ?
            ");
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $cart = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            echo json_encode([
                'success' => true,
                'cart' => $cart
            ]);
            break;

        case 'add':
            // Check if product exists
            $stmt = $db->prepare("SELECT * FROM shop_products WHERE id = ?");
            $stmt->bind_param('i', $productId);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();

            if (!$product) {
                throw new Exception('Product not found');
            }

            // Check if product already in cart
            $stmt = $db->prepare("SELECT * FROM user_cart WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param('ii', $userId, $productId);
            $stmt->execute();
            $cartItem = $stmt->get_result()->fetch_assoc();

            if ($cartItem) {
                // Update quantity
                $stmt = $db->prepare("UPDATE user_cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?");
                $stmt->bind_param('ii', $userId, $productId);
            } else {
                // Add new item
                $stmt = $db->prepare("INSERT INTO user_cart (user_id, product_id, quantity) VALUES (?, ?, 1)");
                $stmt->bind_param('ii', $userId, $productId);
            }
            $stmt->execute();

            // Get updated cart
            $stmt = $db->prepare("
                SELECT c.*, p.name, p.price, p.image_url, p.color 
                FROM user_cart c 
                JOIN shop_products p ON c.product_id = p.id 
                WHERE c.user_id = ?
            ");
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $cart = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            echo json_encode([
                'success' => true,
                'cart' => $cart
            ]);
            break;

        case 'update':
            $change = $data['change'] ?? 0;
            
            $stmt = $db->prepare("
                UPDATE user_cart 
                SET quantity = GREATEST(1, quantity + ?) 
                WHERE user_id = ? AND product_id = ?
            ");
            $stmt->bind_param('iii', $change, $userId, $productId);
            $stmt->execute();

            // Get updated cart
            $stmt = $db->prepare("
                SELECT c.*, p.name, p.price, p.image_url, p.color 
                FROM user_cart c 
                JOIN shop_products p ON c.product_id = p.id 
                WHERE c.user_id = ?
            ");
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $cart = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            echo json_encode([
                'success' => true,
                'cart' => $cart
            ]);
            break;

        case 'remove':
            $stmt = $db->prepare("DELETE FROM user_cart WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param('ii', $userId, $productId);
            $stmt->execute();

            // Get updated cart
            $stmt = $db->prepare("
                SELECT c.*, p.name, p.price, p.image_url, p.color 
                FROM user_cart c 
                JOIN shop_products p ON c.product_id = p.id 
                WHERE c.user_id = ?
            ");
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $cart = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            echo json_encode([
                'success' => true,
                'cart' => $cart
            ]);
            break;

        default:
            throw new Exception('Invalid action');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>