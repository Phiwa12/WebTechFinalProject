<?php
session_start();
require_once '../db/config.php';
require_once '../functions/auth_functions.php';

header('Content-Type: application/json');

function sendJsonResponse($success, $data = [], $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode(array_merge(['success' => $success], $data));
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }

    // Verify database connection
    if (!$db || $db->connect_error) {
        throw new Exception("Database connection failed: " . ($db ? $db->connect_error : "Connection not established"));
    }

    $current_step = $_POST['step'] ?? 1;
    $errors = [];

    switch ($current_step) {
        case 1:
            if (!isset($_POST['email']) || !isset($_POST['password'])) {
                throw new Exception("Missing required fields");
            }

            $errors = validateStep1(
                $_POST['fullName'] ?? '',
                $_POST['email'],
                $_POST['password'],
                $_POST['confirm_password'] ?? ''
            );
            
            if (empty($errors)) {
                saveRegistrationStep(2, [
                    'fullName' => $_POST['fullName'],
                    'email' => $_POST['email'],
                    'password' => $_POST['password']
                ]);
                sendJsonResponse(true, ['nextStep' => 2]);
            }
            break;

        case 2:
            $errors = validateStep2($_POST['style'] ?? []);
            
            if (empty($errors)) {
                saveRegistrationStep(3, [
                    'style' => $_POST['style']
                ]);
                sendJsonResponse(true, ['nextStep' => 3]);
            }
            break;

        case 3:
            if (!isset($_POST['terms']) || $_POST['terms'] !== 'on') {
                throw new Exception('You must agree to the Terms & Conditions');
            }

            $registrationData = getRegistrationData();
            if (!$registrationData) {
                throw new Exception('Registration data not found in session');
            }

            // Validate all required fields are present
            $required_fields = ['fullName', 'email', 'password', 'style'];
            foreach ($required_fields as $field) {
                if (empty($registrationData[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }

            $db->begin_transaction();

            try {
                // Check for existing email - using prepared statement
                $check_email = $db->prepare("SELECT id FROM style_users WHERE email = ?");
                if (!$check_email) {
                    throw new Exception("Database error: " . $db->error);
                }
                
                $check_email->bind_param("s", $registrationData['email']);
                $check_email->execute();
                $result = $check_email->get_result();
                
                if ($result->num_rows > 0) {
                    throw new Exception('This email is already registered');
                }
                $check_email->close();

                // Insert user data - using prepared statement
                $insert_user = $db->prepare("INSERT INTO style_users (full_name, email, password_hash) VALUES (?, ?, ?)");
                if (!$insert_user) {
                    throw new Exception("Database error: " . $db->error);
                }
                
                $password_hash = password_hash($registrationData['password'], PASSWORD_DEFAULT);
                $insert_user->bind_param("sss", 
                    $registrationData['fullName'],
                    $registrationData['email'],
                    $password_hash
                );
                
                if (!$insert_user->execute()) {
                    throw new Exception("Error inserting user: " . $insert_user->error);
                }
                
                $user_id = $db->insert_id;
                $insert_user->close();

                // Insert preferences - using prepared statement
                $insert_prefs = $db->prepare("INSERT INTO style_user_preferences (user_id, style_preferences, notifications_enabled, personalization_enabled) VALUES (?, ?, ?, ?)");
                if (!$insert_prefs) {
                    throw new Exception("Database error: " . $db->error);
                }
                
                $style_json = json_encode($registrationData['style']);
                $notifications = isset($_POST['notifications']) && $_POST['notifications'] === 'on' ? 1 : 0;
                $personalization = isset($_POST['personalization']) && $_POST['personalization'] === 'on' ? 1 : 0;
                
                $insert_prefs->bind_param("isii",
                    $user_id,
                    $style_json,
                    $notifications,
                    $personalization
                );
                
                if (!$insert_prefs->execute()) {
                    throw new Exception("Error inserting preferences: " . $insert_prefs->error);
                }
                
                $insert_prefs->close();
                
                $db->commit();
                
                // Clear session data
                unset($_SESSION['registration_data']);
                unset($_SESSION['registration_step']);
                
                $_SESSION['success_message'] = "Registration successful! Please log in to continue.";
                
                sendJsonResponse(true, ['redirect' => '../view/login.php']);
                
            } catch (Exception $e) {
                $db->rollback();
                throw $e;
            }
            break;

        default:
            throw new Exception("Invalid step provided");
    }

    if (!empty($errors)) {
        sendJsonResponse(false, ['errors' => $errors], 400);
    }

} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    sendJsonResponse(false, ['errors' => [$e->getMessage()]], 500);
}


if ($registration_successful) {
    // After creating the user and getting their ID
    $newUserId = $db->insert_id;
    
    // Add default wardrobe items
    if (!addDefaultWardrobe($db, $newUserId)) {
        // Log the error but don't stop the registration process
        error_log("Failed to add default wardrobe for user {$newUserId}");
    }
}