<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $userId = $_SESSION['user_id'];
    
    // Get cart items
    $stmt = $db->prepare("
        SELECT c.*, p.name, p.category, p.type, p.color, p.image_url, p.description
        FROM user_cart c 
        JOIN shop_products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $cartItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    if (empty($cartItems)) {
        throw new Exception('Cart is empty');
    }

    // Begin transaction
    $db->begin_transaction();

    try {
        // Add each item to wardrobe
        foreach ($cartItems as $item) {
            $stmt = $db->prepare("
                INSERT INTO style_wardrobe_items 
                (user_id, name, category, type, color, image_url, brand, price, status, description)
                VALUES (?, ?, ?, ?, ?, ?, 'Store Purchase', ?, 'active', ?)
            ");
            
            $stmt->bind_param(
                'isssssds',
                $userId,
                $item['name'],
                $item['category'],
                $item['type'],
                $item['color'],
                $item['image_url'],
                $item['price'],
                $item['description']
            );
            
            $stmt->execute();
        }

        // Clear user's cart
        $stmt = $db->prepare("DELETE FROM user_cart WHERE user_id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();

        // Commit transaction
        $db->commit();

        // Clear cart session
        $_SESSION['cart'] = [];

        echo json_encode([
            'success' => true,
            'message' => 'Items successfully added to your wardrobe!',
            'itemCount' => count($cartItems)
        ]);

    } catch (Exception $e) {
        // Rollback on error
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}