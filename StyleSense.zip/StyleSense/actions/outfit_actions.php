<?php
session_start();
require_once '../db/config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Not authenticated'
    ]);
    exit;
}

try {
    if (!isset($_GET['action'])) {
        throw new Exception('Action parameter is required');
    }

    $action = $_GET['action'];
    
    switch ($action) {
        case 'get_item':
            handleGetItem($db);
            break;
            
        case 'get_outfit':
            handleGetOutfit($db);
            break;
            
        case 'save_outfit':
            handleSaveOutfit($db);
            break;
            
        case 'delete_outfit':
            handleDeleteOutfit($db);
            break;
            
        default:
            throw new Exception('Invalid action');
    }
} catch (Exception $e) {
    error_log("Outfit actions error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function handleGetItem($db) {
    try {
        $itemId = isset($_GET['id']) ? (int)$_GET['id'] : null;
        
        if (!$itemId) {
            throw new Exception('Item ID is required');
        }

        $stmt = $db->prepare("
            SELECT * FROM style_wardrobe_items 
            WHERE id = ? AND user_id = ? AND status = 'active'
        ");
        
        if (!$stmt) {
            throw new Exception('Database prepare error: ' . $db->error);
        }
        
        $stmt->bind_param('ii', $itemId, $_SESSION['user_id']);
        
        if (!$stmt->execute()) {
            throw new Exception('Database execute error: ' . $stmt->error);
        }
        
        $result = $stmt->get_result();
        $item = $result->fetch_assoc();
        
        if (!$item) {
            throw new Exception('Item not found');
        }

        echo json_encode([
            'success' => true,
            'item' => $item
        ]);
    } catch (Exception $e) {
        error_log("Get item error: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function handleGetOutfit($db) {
    try {
        $outfitId = isset($_GET['id']) ? (int)$_GET['id'] : null;
        
        if (!$outfitId) {
            throw new Exception('Outfit ID is required');
        }

        // Get outfit details
        $stmt = $db->prepare("
            SELECT o.*, GROUP_CONCAT(oi.item_id) as item_ids
            FROM style_outfits o
            LEFT JOIN style_outfit_items oi ON o.id = oi.outfit_id
            WHERE o.id = ? AND o.user_id = ?
            GROUP BY o.id
        ");
        
        if (!$stmt) {
            throw new Exception('Database prepare error: ' . $db->error);
        }
        
        $stmt->bind_param('ii', $outfitId, $_SESSION['user_id']);
        
        if (!$stmt->execute()) {
            throw new Exception('Database execute error: ' . $stmt->error);
        }
        
        $result = $stmt->get_result();
        $outfit = $result->fetch_assoc();
        
        if (!$outfit) {
            throw new Exception('Outfit not found');
        }

        // Get outfit items
        $itemIds = explode(',', $outfit['item_ids']);
        $items = [];
        
        if (!empty($itemIds)) {
            $placeholders = str_repeat('?,', count($itemIds) - 1) . '?';
            $sql = "SELECT * FROM style_wardrobe_items WHERE id IN ($placeholders)";
            $stmt = $db->prepare($sql);
            
            if (!$stmt) {
                throw new Exception('Database prepare error: ' . $db->error);
            }
            
            $stmt->bind_param(str_repeat('i', count($itemIds)), ...$itemIds);
            
            if (!$stmt->execute()) {
                throw new Exception('Database execute error: ' . $stmt->error);
            }
            
            $result = $stmt->get_result();
            while ($item = $result->fetch_assoc()) {
                $items[] = $item;
            }
        }

        $outfit['items'] = $items;
        unset($outfit['item_ids']);

        echo json_encode([
            'success' => true,
            'outfit' => $outfit
        ]);
    } catch (Exception $e) {
        error_log("Get outfit error: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function handleDeleteOutfit($db) {
    try {
        $outfitId = isset($_GET['id']) ? (int)$_GET['id'] : null;
        
        if (!$outfitId) {
            throw new Exception('Outfit ID is required');
        }

        $db->begin_transaction();

        try {
            // Delete outfit items first
            $stmt = $db->prepare("DELETE FROM style_outfit_items WHERE outfit_id = ?");
            if (!$stmt) {
                throw new Exception('Database prepare error: ' . $db->error);
            }
            
            $stmt->bind_param('i', $outfitId);
            if (!$stmt->execute()) {
                throw new Exception('Failed to delete outfit items: ' . $stmt->error);
            }

            // Then delete the outfit
            $stmt = $db->prepare("DELETE FROM style_outfits WHERE id = ? AND user_id = ?");
            if (!$stmt) {
                throw new Exception('Database prepare error: ' . $db->error);
            }
            
            $stmt->bind_param('ii', $outfitId, $_SESSION['user_id']);
            if (!$stmt->execute()) {
                throw new Exception('Failed to delete outfit: ' . $stmt->error);
            }

            if ($stmt->affected_rows === 0) {
                throw new Exception('Outfit not found or unauthorized');
            }

            $db->commit();

            echo json_encode([
                'success' => true,
                'message' => 'Outfit deleted successfully'
            ]);

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
    } catch (Exception $e) {
        error_log("Delete outfit error: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function handleSaveOutfit($db) {
    try {
        $rawInput = file_get_contents('php://input');
        error_log("Raw input received: " . $rawInput);

        $data = json_decode($rawInput, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON data: ' . json_last_error_msg());
        }

        if (!validateOutfitData($data)) {
            throw new Exception('Invalid outfit data format');
        }

        $db->begin_transaction();

        try {
            // Simplified query with only essential columns
            $stmt = $db->prepare("
                INSERT INTO style_outfits (
                    user_id,
                    name,
                    description,
                    category,
                    created_at
                ) VALUES (
                    ?, ?, ?, ?, NOW()
                )
            ");
            
            if (!$stmt) {
                throw new Exception('Failed to prepare outfit statement: ' . $db->error);
            }

            $stmt->bind_param('isss', 
                $_SESSION['user_id'],
                $data['name'],
                $data['notes'],
                $data['type']  // Using type as category
            );
            
            if (!$stmt->execute()) {
                error_log("SQL Error: " . $stmt->error);
                throw new Exception('Failed to save outfit: ' . $stmt->error);
            }
            
            $outfitId = $db->insert_id;

            // Insert outfit items
            $stmt = $db->prepare("
                INSERT INTO style_outfit_items (
                    outfit_id, 
                    item_id
                ) VALUES (?, ?)
            ");

            if (!$stmt) {
                throw new Exception('Failed to prepare items statement: ' . $db->error);
            }

            foreach ($data['items'] as $category => $items) {
                if (!is_array($items)) {
                    throw new Exception('Invalid items format for category: ' . $category);
                }
                foreach ($items as $itemId) {
                    if (!is_numeric($itemId)) {
                        throw new Exception('Invalid item ID format');
                    }
                    $stmt->bind_param('ii', $outfitId, $itemId);
                    if (!$stmt->execute()) {
                        error_log("SQL Error on item insert: " . $stmt->error);
                        throw new Exception('Failed to save outfit item: ' . $stmt->error);
                    }
                }
            }

            $db->commit();

            echo json_encode([
                'success' => true,
                'outfit_id' => $outfitId,
                'message' => 'Outfit saved successfully'
            ]);

        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }

    } catch (Exception $e) {
        error_log("Save outfit error: " . $e->getMessage());
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
}

function validateOutfitData($data) {
    if (!is_array($data)) {
        error_log("Data is not an array");
        return false;
    }
    
    // Validate required fields
    if (!isset($data['name']) || !isset($data['type']) || !isset($data['items'])) {
        error_log("Missing required fields");
        return false;
    }
    
    // Validate name length
    if (strlen($data['name']) > 100 || strlen($data['name']) < 1) {
        error_log("Invalid name length");
        return false;
    }
    
    // Validate type
    $validTypes = ['casual', 'formal', 'business', 'party'];
    if (!in_array($data['type'], $validTypes)) {
        error_log("Invalid outfit type: " . $data['type']);
        return false;
    }
    
    // Validate items structure
    if (!is_array($data['items'])) {
        error_log("Items is not an array");
        return false;
    }

    error_log("Outfit data validation passed");
    return true;
}
?>