<?php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

// Enable detailed error reporting for debugging
ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);

function logError($message, $data = null) {
    error_log("Save analysis error: " . $message);
    if ($data) {
        error_log("Additional data: " . print_r($data, true));
    }
}

// Check authentication
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

// Check database connection
if (!isset($db)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection not established']);
    exit;
}

// Validate database connection object
if (!$db instanceof mysqli) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Invalid database connection object']);
    exit;
}

try {
    $raw_input = file_get_contents('php://input');
    logError("Raw input received: " . $raw_input);
    
    $data = json_decode($raw_input, true);
    
    if (!$data || !isset($data['bodyType'])) {
        throw new Exception('Invalid data received: ' . json_last_error_msg());
    }

    // Start transaction
    if (!$db->begin_transaction()) {
        throw new Exception("Failed to start transaction: " . $db->error);
    }

    // Get the most recent measurements
    $stmt = $db->prepare("
        SELECT * FROM body_measurements 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 1
    ");

    if (!$stmt) {
        throw new Exception("Failed to prepare select statement: " . $db->error);
    }

    if (!$stmt->bind_param("i", $_SESSION['user_id'])) {
        throw new Exception("Failed to bind select parameters: " . $stmt->error);
    }

    if (!$stmt->execute()) {
        throw new Exception("Failed to execute select statement: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    if (!$result) {
        throw new Exception("Failed to get select result: " . $stmt->error);
    }

    $measurement = $result->fetch_assoc();
    if (!$measurement) {
        throw new Exception('No measurement data found for user ID: ' . $_SESSION['user_id']);
    }

    // Check if profile exists
    $check_stmt = $db->prepare("SELECT user_id FROM style_user_profiles WHERE user_id = ?");
    if (!$check_stmt) {
        throw new Exception("Failed to prepare check statement: " . $db->error);
    }
    
    if (!$check_stmt->bind_param("i", $_SESSION['user_id'])) {
        throw new Exception("Failed to bind check parameters: " . $check_stmt->error);
    }

    if (!$check_stmt->execute()) {
        throw new Exception("Failed to execute check statement: " . $check_stmt->error);
    }

    $check_result = $check_stmt->get_result();
    if (!$check_result) {
        throw new Exception("Failed to get check result: " . $check_stmt->error);
    }

    $exists = $check_result->num_rows > 0;
    $check_stmt->close();

    $measurementsJson = json_encode([
        'shoulders' => $measurement['shoulders'],
        'bust' => $measurement['bust'],
        'waist' => $measurement['waist'],
        'hips' => $measurement['hips']
    ]);

    if ($measurementsJson === false) {
        throw new Exception("Failed to encode measurements JSON: " . json_last_error_msg());
    }

    if ($exists) {
        // Update existing profile
        $update_stmt = $db->prepare("
            UPDATE style_user_profiles 
            SET body_type = ?, 
                measurements = ?
            WHERE user_id = ?
        ");
        
        if (!$update_stmt) {
            throw new Exception("Failed to prepare update statement: " . $db->error);
        }

        if (!$update_stmt->bind_param("ssi", 
            $data['bodyType'],
            $measurementsJson,
            $_SESSION['user_id']
        )) {
            throw new Exception("Failed to bind update parameters: " . $update_stmt->error);
        }

        if (!$update_stmt->execute()) {
            throw new Exception("Failed to execute update: " . $update_stmt->error);
        }
    } else {
        // Insert new profile
        $insert_stmt = $db->prepare("
            INSERT INTO style_user_profiles 
            (user_id, body_type, measurements) 
            VALUES (?, ?, ?)
        ");
        
        if (!$insert_stmt) {
            throw new Exception("Failed to prepare insert statement: " . $db->error);
        }

        if (!$insert_stmt->bind_param("iss", 
            $_SESSION['user_id'],
            $data['bodyType'],
            $measurementsJson
        )) {
            throw new Exception("Failed to bind insert parameters: " . $insert_stmt->error);
        }

        if (!$insert_stmt->execute()) {
            throw new Exception("Failed to execute insert: " . $insert_stmt->error);
        }
    }

    // Log the activity
    $log_stmt = $db->prepare("
        INSERT INTO style_activity_log 
        (user_id, activity_type, details) 
        VALUES (?, 'body_analysis_saved', ?)
    ");

    if (!$log_stmt) {
        throw new Exception("Failed to prepare log statement: " . $db->error);
    }

    $activityDetails = json_encode([
        'body_type' => $data['bodyType'],
        'saved_at' => date('Y-m-d H:i:s')
    ]);

    if ($activityDetails === false) {
        throw new Exception("Failed to encode activity details: " . json_last_error_msg());
    }

    if (!$log_stmt->bind_param("is", $_SESSION['user_id'], $activityDetails)) {
        throw new Exception("Failed to bind log parameters: " . $log_stmt->error);
    }
    
    if (!$log_stmt->execute()) {
        throw new Exception("Failed to execute log insert: " . $log_stmt->error);
    }

    if (!$db->commit()) {
        throw new Exception("Failed to commit transaction: " . $db->error);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Analysis saved successfully'
    ]);

} catch (Exception $e) {
    if (isset($db) && $db instanceof mysqli) {
        $db->rollback();
    }
    logError($e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Failed to save analysis: ' . $e->getMessage()
    ]);
}
?>