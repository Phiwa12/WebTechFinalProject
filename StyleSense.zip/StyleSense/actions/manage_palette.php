<?php
// actions/manage_palette.php
session_start();
require_once '../db/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['palette_id']) || !isset($data['action'])) {
        throw new Exception('Invalid request parameters');
    }

    switch ($data['action']) {
        case 'delete':
            $stmt = $db->prepare("
                DELETE FROM style_color_palettes 
                WHERE id = ? AND user_id = ?
            ");
            $stmt->bind_param("ii", $data['palette_id'], $_SESSION['user_id']);
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Palette deleted successfully'
                ]);
            } else {
                throw new Exception('Failed to delete palette');
            }
            break;

        case 'edit':
            if (!isset($data['name']) || !isset($data['colors'])) {
                throw new Exception('Missing required fields for edit');
            }

            $stmt = $db->prepare("
                UPDATE style_color_palettes 
                SET palette_name = ?,
                    colors = ?,
                    season = ?
                WHERE id = ? AND user_id = ?
            ");

            $colors = json_encode($data['colors']);
            $stmt->bind_param("sssii", 
                $data['name'],
                $colors,
                $data['season'],
                $data['palette_id'],
                $_SESSION['user_id']
            );
            
            if ($stmt->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Palette updated successfully'
                ]);
            } else {
                throw new Exception('Failed to update palette');
            }
            break;

        default:
            throw new Exception('Invalid action specified');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>