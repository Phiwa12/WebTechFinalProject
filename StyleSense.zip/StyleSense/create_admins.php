<?php
require_once 'db/config.php';

// First, modify the table structure
$alterTableSQL = "ALTER TABLE style_users 
                 MODIFY COLUMN role enum('user', 'moderator', 'admin', 'super_admin') DEFAULT 'user'";
try {
    $db->query($alterTableSQL);
    echo "Table structure updated successfully.\n";
} catch (Exception $e) {
    echo "Error updating table structure: " . $e->getMessage() . "\n";
    exit;
}

function createAdminUsers($db) {
    try {
        // Start transaction
        mysqli_begin_transaction($db);

        // Create super admin
        $superAdminPassword = 'Lungelo_2026';
        $superAdminHash = password_hash($superAdminPassword, PASSWORD_DEFAULT);

        $stmt = $db->prepare("
            INSERT INTO style_users (
                full_name, 
                email, 
                password_hash, 
                role, 
                status, 
                created_at
            ) VALUES (?, ?, ?, 'super_admin', 'active', NOW())
        ");

        $superAdminName = "Precious Mhlanti";
        $superAdminEmail = "phiwayinkhosi.lukhele@ashesi.edu.gh";
        $stmt->bind_param("sss", $superAdminName, $superAdminEmail, $superAdminHash);
        
        // Delete existing user if exists (since email must be unique)
        $db->query("DELETE FROM style_users WHERE email = '$superAdminEmail'");
        $stmt->execute();
        $superAdminId = $stmt->insert_id;

        // Create regular admin
        $adminPassword = 'AdminUser@2024';
        $adminHash = password_hash($adminPassword, PASSWORD_DEFAULT);

        $stmt = $db->prepare("
            INSERT INTO style_users (
                full_name, 
                email, 
                password_hash, 
                role, 
                status, 
                created_at
            ) VALUES (?, ?, ?, 'admin', 'active', NOW())
        ");

        $adminName = "Lungelo Mhlanga";
        $adminEmail = "admin@stylesense.com";
        $stmt->bind_param("sss", $adminName, $adminEmail, $adminHash);
        
        // Delete existing admin if exists
        $db->query("DELETE FROM style_users WHERE email = '$adminEmail'");
        $stmt->execute();
        $adminId = $stmt->insert_id;

        // Create preferences for super admin
        $stmt = $db->prepare("
            INSERT INTO style_user_preferences (
                user_id, 
                style_preferences, 
                notifications_enabled, 
                personalization_enabled
            ) VALUES (?, ?, 1, 1)
        ");

        $preferences = json_encode(['style' => ['admin']]);
        $stmt->bind_param("is", $superAdminId, $preferences);
        $stmt->execute();

        // Create preferences for admin
        $stmt->bind_param("is", $adminId, $preferences);
        $stmt->execute();

        // Log the creation
        $stmt = $db->prepare("
            INSERT INTO style_activity_log (
                user_id, 
                activity_type, 
                details
            ) VALUES (?, 'admin_created', ?)
        ");

        $details = json_encode([
            'message' => 'Admin users created',
            'created_by' => 'System',
            'timestamp' => date('Y-m-d H:i:s')
        ]);

        $stmt->bind_param("is", $superAdminId, $details);
        $stmt->execute();

        // Commit transaction
        mysqli_commit($db);

        echo "Admin users created successfully!\n";
        echo "Super Admin Email: " . $superAdminEmail . "\n";
        echo "Super Admin Password: " . $superAdminPassword . "\n\n";
        echo "Admin Email: " . $adminEmail . "\n";
        echo "Admin Password: " . $adminPassword . "\n";

    } catch (Exception $e) {
        mysqli_rollback($db);
        echo "Error creating admin users: " . $e->getMessage() . "\n";
    }
}

createAdminUsers($db);
?>