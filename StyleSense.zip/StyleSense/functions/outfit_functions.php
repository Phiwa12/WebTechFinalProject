<?php
// outfit_functions.php

function getWardrobeItems($db, $userId, $category = null) {
    try {
        $sql = "SELECT * FROM style_wardrobe_items WHERE user_id = ? AND status = 'active'";
        $params = [$userId];
        $types = "i";

        if ($category) {
            $sql .= " AND category = ?";
            $params[] = $category;
            $types .= "s";
        }

        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Failed to prepare statement: " . $db->error);
        }

        $stmt->bind_param($types, ...$params);
        if (!$stmt->execute()) {
            throw new Exception("Failed to execute statement: " . $stmt->error);
        }

        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        error_log("Error getting wardrobe items: " . $e->getMessage());
        return [];
    }
}

function validateOutfitItems($items) {
    if (!is_array($items)) {
        return false;
    }

    $foundCategories = [];
    $hasDress = false;
    
    foreach ($items as $zone => $zoneItems) {
        if (!is_array($zoneItems)) {
            return false;
        }
        
        foreach ($zoneItems as $item) {
            if (!isset($item['category'])) {
                return false;
            }
            $category = $item['category'];
            $foundCategories[] = $category;
            if ($category === 'dresses') {
                $hasDress = true;
                break;
            }
        }
    }
    
    if ($hasDress) {
        return in_array('shoes', $foundCategories);
    }
    
    return in_array('tops', $foundCategories) && 
           in_array('bottoms', $foundCategories) && 
           in_array('shoes', $foundCategories);
}

function saveOutfit($db, $userId, $data) {
    try {
        if (!validateOutfitData($data)) {
            throw new Exception("Invalid outfit data");
        }

        $db->begin_transaction();

        // Insert outfit with prepared statement
        $stmt = $db->prepare("
            INSERT INTO style_outfits (
                user_id, name, category, description, created_at
            ) VALUES (?, ?, ?, ?, NOW())
        ");
        
        if (!$stmt) {
            throw new Exception("Failed to prepare outfit statement");
        }
        
        $stmt->bind_param("isss", 
            $userId,
            $data['name'],
            $data['category'],
            $data['notes'] ?? ''
        );
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to save outfit");
        }
        
        $outfitId = $db->insert_id;

        // Insert outfit items with prepared statement
        $stmt = $db->prepare("
            INSERT INTO style_outfit_items (
                outfit_id, item_id, position, layer_order
            ) VALUES (?, ?, ?, ?)
        ");
        
        if (!$stmt) {
            throw new Exception("Failed to prepare items statement");
        }

        $layerOrder = 0;
        foreach ($data['items'] as $position => $items) {
            if (!is_array($items)) {
                throw new Exception("Invalid items data structure");
            }
            
            foreach ($items as $item) {
                if (!isset($item['id']) || !is_numeric($item['id'])) {
                    throw new Exception("Invalid item ID");
                }
                
                $itemId = (int)$item['id'];
                if (!$stmt->bind_param("iisi", $outfitId, $itemId, $position, $layerOrder)) {
                    throw new Exception("Failed to bind parameters");
                }
                
                if (!$stmt->execute()) {
                    throw new Exception("Failed to save outfit item");
                }
                
                $layerOrder++;
            }
        }

        // Calculate and store color harmony
        $colorHarmony = calculateColorHarmony($data['items']);
        if ($colorHarmony) {
            $stmt = $db->prepare("
                UPDATE style_outfits 
                SET color_harmony = ? 
                WHERE id = ? AND user_id = ?
            ");
            
            if (!$stmt) {
                throw new Exception("Failed to prepare color harmony statement");
            }
            
            if (!$stmt->bind_param("sii", $colorHarmony, $outfitId, $userId)) {
                throw new Exception("Failed to bind color harmony parameters");
            }
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to update color harmony");
            }
        }

        $db->commit();
        return [
            'success' => true,
            'outfit_id' => $outfitId,
            'message' => 'Outfit saved successfully'
        ];

    } catch (Exception $e) {
        $db->rollback();
        error_log("Error saving outfit: " . $e->getMessage());
        return [
            'success' => false,
            'message' => 'Failed to save outfit: ' . $e->getMessage()
        ];
    }
}

function calculateColorHarmony($items) {
    try {
        $colors = [];
        foreach ($items as $zoneItems) {
            if (!is_array($zoneItems)) continue;
            
            foreach ($zoneItems as $item) {
                if (isset($item['color']) && preg_match('/^#[a-fA-F0-9]{6}$/', $item['color'])) {
                    $colors[] = strtolower($item['color']);
                }
            }
        }
        
        if (count($colors) < 2) {
            return null;
        }

        // Simple color harmony check with validation
        $uniqueColors = array_unique($colors);
        
        switch (count($uniqueColors)) {
            case 1:
                return 'monochromatic';
            case 2:
                return 'complementary';
            case 3:
                return 'triadic';
            default:
                return 'mixed';
        }
    } catch (Exception $e) {
        error_log("Error calculating color harmony: " . $e->getMessage());
        return null;
    }
}

function getRecommendations($db, $userId, $currentItems) {
    try {
        if (!is_array($currentItems)) {
            throw new Exception("Invalid items data");
        }

        // Get current outfit categories
        $usedCategories = [];
        foreach ($currentItems as $zone => $items) {
            if (!is_array($items)) continue;
            
            foreach ($items as $item) {
                if (isset($item['category'])) {
                    $usedCategories[] = $item['category'];
                }
            }
        }
        
        // Find missing essential categories
        $essentialCategories = ['tops', 'bottoms', 'shoes'];
        $missingCategories = array_diff($essentialCategories, $usedCategories);
        
        if (empty($missingCategories)) {
            $missingCategories = ['accessories'];
        }
        
        // Prepare IN clause safely
        $placeholders = str_repeat('?,', count($missingCategories) - 1) . '?';
        $types = str_repeat('s', count($missingCategories));
        
        $sql = "SELECT * FROM style_wardrobe_items 
                WHERE user_id = ? 
                AND category IN ($placeholders)
                AND status = 'active'
                ORDER BY RAND() 
                LIMIT 5";
                
        $stmt = $db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Failed to prepare statement");
        }
        
        // Create parameter array with types
        $params = array_merge([$userId], $missingCategories);
        $stmt->bind_param("i" . $types, ...$params);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to execute statement");
        }
        
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
        
    } catch (Exception $e) {
        error_log("Error getting recommendations: " . $e->getMessage());
        return [];
    }
}

function validateOutfitData($data) {
    if (!is_array($data)) return false;
    
    // Validate required fields
    if (!isset($data['name']) || !isset($data['category']) || !isset($data['items'])) {
        return false;
    }
    
    // Validate name length
    if (strlen($data['name']) > 100 || strlen($data['name']) < 1) {
        return false;
    }
    
    // Validate category
    $validCategories = ['casual', 'formal', 'business', 'party'];
    if (!in_array($data['category'], $validCategories)) {
        return false;
    }
    
    // Validate items structure
    if (!is_array($data['items'])) {
        return false;
    }
    
    return true;
}

function getStyleTips($outfit) {
    try {
        if (!is_array($outfit) || !isset($outfit['items'])) {
            return ['Start by adding items to your outfit'];
        }

        $tips = [];
        
        // Check outfit balance
        $hasTop = false;
        $hasBottom = false;
        $hasDress = false;
        $hasShoes = false;
        $hasAccessories = false;
        
        foreach ($outfit['items'] as $item) {
            if (!isset($item['category'])) continue;
            
            switch ($item['category']) {
                case 'tops':
                    $hasTop = true;
                    break;
                case 'bottoms':
                    $hasBottom = true;
                    break;
                case 'dresses':
                    $hasDress = true;
                    break;
                case 'shoes':
                    $hasShoes = true;
                    break;
                case 'accessories':
                    $hasAccessories = true;
                    break;
            }
        }

        // Generate appropriate tips
        if (!$hasDress && !($hasTop && $hasBottom)) {
            $tips[] = "Complete your outfit with matching top and bottom pieces";
        }

        if (!$hasShoes) {
            $tips[] = "Don't forget to add shoes to complete your look";
        }

        if (!$hasAccessories) {
            $tips[] = "Consider adding accessories to enhance your outfit";
        }

        return $tips;
    } catch (Exception $e) {
        error_log("Error generating style tips: " . $e->getMessage());
        return ['Start by adding items to your outfit'];
    }
}