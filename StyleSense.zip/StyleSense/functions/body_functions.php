<?php
// functions/body_functions.php

function analyzeBodyType($measurements, $additionalDetails) {
    // Calculate key ratios
    $shoulderHipRatio = $measurements['shoulders'] / $measurements['hips'];
    $waistHipRatio = $measurements['waist'] / $measurements['hips'];
    $bustWaistRatio = $measurements['bust'] / $measurements['waist'];

    // Initialize scoring system
    $scores = [
        'hourglass' => 0,
        'pear' => 0,
        'apple' => 0,
        'rectangle' => 0
    ];

    // Score based on ratios
    if (abs($shoulderHipRatio - 1) < 0.05) {
        $scores['hourglass'] += 2;
        $scores['rectangle'] += 1;
    } elseif ($shoulderHipRatio < 0.9) {
        $scores['pear'] += 2;
    } elseif ($shoulderHipRatio > 1.1) {
        $scores['apple'] += 2;
    }

    if ($waistHipRatio < 0.75) {
        $scores['hourglass'] += 2;
        $scores['pear'] += 1;
    } elseif ($waistHipRatio > 0.85) {
        $scores['rectangle'] += 2;
        $scores['apple'] += 1;
    }

    // Score based on additional details
    switch ($additionalDetails['weightGain']) {
        case 'upper':
            $scores['apple'] += 2;
            break;
        case 'lower':
            $scores['pear'] += 2;
            break;
        case 'middle':
            $scores['apple'] += 1;
            break;
        case 'even':
            $scores['rectangle'] += 2;
            break;
    }

    switch ($additionalDetails['shoulderType']) {
        case 'broad':
            $scores['apple'] += 1;
            break;
        case 'narrow':
            $scores['pear'] += 1;
            break;
        case 'even':
            $scores['hourglass'] += 1;
            $scores['rectangle'] += 1;
            break;
    }

    switch ($additionalDetails['waistDefinition']) {
        case 'very':
            $scores['hourglass'] += 2;
            break;
        case 'somewhat':
            $scores['pear'] += 1;
            break;
        case 'straight':
            $scores['rectangle'] += 2;
            break;
    }

    // Determine body type with highest score
    $bodyType = array_search(max($scores), $scores);

    // Get recommendations for the determined body type
    return getBodyTypeRecommendations($bodyType);
}

function getBodyTypeRecommendations($bodyType) {
    $recommendations = [
        'hourglass' => [
            'type' => 'Hourglass',
            'description' => 'Your shoulders and hips are about the same width with a significantly smaller waist.',
            'recommendations' => 'Focus on fitted clothing that shows off your natural curves.',
            'dos' => [
                'Emphasize your waist',
                'Choose fitted styles',
                'Use belts to define your middle',
                'Wear v-neck or scoop necklines'
            ],
            'donts' => [
                'Wear boxy or shapeless clothing',
                'Choose overwhelming ruffles or volume',
                'Hide your waist',
                'Wear overly loose styles'
            ]
        ],
        'pear' => [
            'type' => 'Pear',
            'description' => 'Your hips are wider than your shoulders with a defined waist.',
            'recommendations' => 'Balance your silhouette by emphasizing your upper body while skimming over your lower half.',
            'dos' => [
                'Wear bright colors and patterns on top',
                'Choose A-line skirts and dresses',
                'Opt for boat necks and wide necklines',
                'Use structured shoulders to balance proportions'
            ],
            'donts' => [
                'Wear tight-fitting bottoms',
                'Choose pants with large patterns',
                'Wear skinny straps',
                'Add volume to your hips'
            ]
        ],
        'apple' => [
            'type' => 'Apple',
            'description' => 'Your shoulders and bust are wider than your hips with less waist definition.',
            'recommendations' => 'Create a balanced silhouette by defining your waist and elongating your figure.',
            'dos' => [
                'Wear empire waist styles',
                'Choose V-neck or deep scoop necklines',
                'Opt for flowing fabrics',
                'Create vertical lines in your outfits'
            ],
            'donts' => [
                'Wear tight-fitting waistbands',
                'Choose bulky fabrics',
                'Add volume at the midsection',
                'Wear oversized tops'
            ]
        ],
        'rectangle' => [
            'type' => 'Rectangle',
            'description' => 'Your shoulders, waist, and hips are similar in width with minimal curves.',
            'recommendations' => 'Create the illusion of curves while maintaining your balanced proportions.',
            'dos' => [
                'Use layers and ruffles to create curves',
                'Wear belts to define your waist',
                'Choose clothing with interesting details',
                'Try peplum tops and dresses'
            ],
            'donts' => [
                'Wear straight, shapeless clothing',
                'Choose plain, unstructured pieces',
                'Stick to one silhouette',
                'Wear oversized, boxy clothing'
            ]
        ]
    ];

    return $recommendations[$bodyType] ?? null;
}

function saveAnalysisResult($db, $userId, $measurements, $additionalDetails, $result) {
    try {
        // Start transaction
        $db->begin_transaction();

        // Insert measurements
        $stmt = $db->prepare("INSERT INTO body_measurements 
            (user_id, shoulders, bust, waist, hips, weight_gain_pattern, shoulder_type, waist_definition, body_type, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

        if (!$stmt) {
            throw new Exception("Database error: " . $db->error);
        }

        $bodyType = $result['type'];
        
        $stmt->bind_param("idddssss",
            $userId,
            $measurements['shoulders'],
            $measurements['bust'],
            $measurements['waist'],
            $measurements['hips'],
            $additionalDetails['weightGain'],
            $additionalDetails['shoulderType'],
            $additionalDetails['waistDefinition'],
            $bodyType
        );

        if (!$stmt->execute()) {
            throw new Exception("Error saving measurements: " . $stmt->error);
        }

        // Get the ID of the newly inserted record
        $measurementId = $db->insert_id;

        // Save recommendations separately if you want to store them
        $recommendationsJson = json_encode([
            'description' => $result['description'],
            'recommendations' => $result['recommendations'],
            'dos' => $result['dos'],
            'donts' => $result['donts']
        ]);

        $stmt = $db->prepare("UPDATE body_measurements SET recommendations = ? WHERE id = ?");
        if (!$stmt) {
            throw new Exception("Database error: " . $db->error);
        }

        $stmt->bind_param("si", $recommendationsJson, $measurementId);
        if (!$stmt->execute()) {
            throw new Exception("Error saving recommendations: " . $stmt->error);
        }

        $db->commit();
        return true;

    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }
}

function getLatestAnalysis($db, $userId) {
    $stmt = $db->prepare("
        SELECT * FROM body_measurements 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 1
    ");

    if (!$stmt) {
        throw new Exception("Database error: " . $db->error);
    }

    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return null;
    }

    return $result->fetch_assoc();
}
?>