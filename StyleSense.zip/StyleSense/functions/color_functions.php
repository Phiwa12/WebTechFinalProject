<?php
// functions/color_functions.php

function hexToHSL($hex) {
    // Remove # if present
    $hex = ltrim($hex, '#');
    
    // Convert to RGB
    $r = hexdec(substr($hex, 0, 2)) / 255;
    $g = hexdec(substr($hex, 2, 2)) / 255;
    $b = hexdec(substr($hex, 4, 2)) / 255;
    
    $max = max($r, $g, $b);
    $min = min($r, $g, $b);
    
    $h = $s = $l = ($max + $min) / 2;

    if ($max == $min) {
        $h = $s = 0;
    } else {
        $d = $max - $min;
        $s = $l > 0.5 ? $d / (2 - $max - $min) : $d / ($max + $min);
        
        switch($max) {
            case $r:
                $h = ($g - $b) / $d + ($g < $b ? 6 : 0);
                break;
            case $g:
                $h = ($b - $r) / $d + 2;
                break;
            case $b:
                $h = ($r - $g) / $d + 4;
                break;
        }
        
        $h /= 6;
    }

    return [
        'h' => round($h * 360),
        's' => round($s * 100),
        'l' => round($l * 100)
    ];
}

function HSLToHex($h, $s, $l) {
    $h /= 360;
    $s /= 100;
    $l /= 100;

    $r = $g = $b = $l;

    if ($s != 0) {
        $q = $l < 0.5 ? $l * (1 + $s) : $l + $s - $l * $s;
        $p = 2 * $l - $q;

        $r = hueToRGB($p, $q, $h + 1/3);
        $g = hueToRGB($p, $q, $h);
        $b = hueToRGB($p, $q, $h - 1/3);
    }

    return sprintf("#%02x%02x%02x", 
        round($r * 255), 
        round($g * 255), 
        round($b * 255)
    );
}

function hueToRGB($p, $q, $t) {
    if ($t < 0) $t += 1;
    if ($t > 1) $t -= 1;
    if ($t < 1/6) return $p + ($q - $p) * 6 * $t;
    if ($t < 1/2) return $q;
    if ($t < 2/3) return $p + ($q - $p) * (2/3 - $t) * 6;
    return $p;
}

function adjustHue($hex, $degrees) {
    $hsl = hexToHSL($hex);
    $hsl['h'] = ($hsl['h'] + $degrees + 360) % 360;
    return HSLToHex($hsl['h'], $hsl['s'], $hsl['l']);
}

function adjustLightness($hex, $amount) {
    $hsl = hexToHSL($hex);
    $hsl['l'] = max(0, min(100, $hsl['l'] + $amount));
    return HSLToHex($hsl['h'], $hsl['s'], $hsl['l']);
}

function getComplementary($hex) {
    $hsl = hexToHSL($hex);
    $hsl['h'] = ($hsl['h'] + 180) % 360;
    return HSLToHex($hsl['h'], $hsl['s'], $hsl['l']);
}

function generateColorCombinations($baseColor) {
    $hsl = hexToHSL($baseColor);
    
    // Generate combinations
    return [
        'monochromatic' => [
            adjustLightness($baseColor, -20),
            $baseColor,
            adjustLightness($baseColor, 20)
        ],
        'complementary' => [
            $baseColor,
            getComplementary($baseColor)
        ],
        'triadic' => [
            $baseColor,
            adjustHue($baseColor, 120),
            adjustHue($baseColor, 240)
        ],
        'analogous' => [
            adjustHue($baseColor, -30),
            $baseColor,
            adjustHue($baseColor, 30)
        ],
        'split-complementary' => [
            $baseColor,
            adjustHue(getComplementary($baseColor), -30),
            adjustHue(getComplementary($baseColor), 30)
        ]
    ];
}

function getSeasonalPalettes() {
    return [
        'spring' => [
            'warm' => ['#FFB7C5', '#FF69B4', '#98FF98', '#FFD700'],
            'light' => ['#FFE4E1', '#FFB6C1', '#98FB98', '#F0E68C'],
            'bright' => ['#FF1493', '#FF4500', '#32CD32', '#FFD700']
        ],
        'summer' => [
            'cool' => ['#87CEEB', '#E6E6FA', '#FFC0CB', '#98FB98'],
            'light' => ['#B0E0E6', '#D8BFD8', '#FFE4E1', '#E0FFFF'],
            'soft' => ['#778899', '#DDA0DD', '#F08080', '#20B2AA']
        ],
        'autumn' => [
            'warm' => ['#CD853F', '#DAA520', '#8B4513', '#D2691E'],
            'deep' => ['#8B0000', '#B8860B', '#556B2F', '#A0522D'],
            'soft' => ['#BC8F8F', '#BDB76B', '#696969', '#CD853F']
        ],
        'winter' => [
            'cool' => ['#483D8B', '#4B0082', '#800000', '#2F4F4F'],
            'deep' => ['#000080', '#8B008B', '#2F4F4F', '#191970'],
            'bright' => ['#0000FF', '#FF0000', '#00008B', '#8B0000']
        ]
    ];
}

function savePalette($db, $userId, $data) {
    $stmt = $db->prepare("
        INSERT INTO style_color_palettes 
        (user_id, palette_name, colors, season, combinations) 
        VALUES (?, ?, ?, ?, ?)
    ");

    $colors = json_encode($data['colors']);
    $combinations = json_encode($data['combinations']);
    
    $stmt->bind_param("issss", 
        $userId,
        $data['name'],
        $colors,
        $data['season'],
        $combinations
    );

    return $stmt->execute();
}

function getUserPalettes($db, $userId) {
    $stmt = $db->prepare("
        SELECT * FROM style_color_palettes 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ");
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
?>