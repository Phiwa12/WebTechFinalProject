
<?php

function requireAdmin() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
        header('Location: ../index.php');
        exit();
    }

    if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'super_admin') {
        header('Location: ../index.php');
        exit();
    }
}

function requireSuperAdmin() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'super_admin') {
        header('Location: ../views/admin_users.php');
        exit();
    }
}

function isAdmin() {
    return isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin');
}

function isSuperAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'super_admin';
}

// Your existing functions remain here...
function validateStep1($fullName, $email, $password, $confirm_password) {
    $errors = [];

    // Validate full name
    if (strlen($fullName) < 2 || strlen($fullName) > 100) {
        $errors[] = "Full name must be between 2 and 100 characters";
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    // Check if email already exists
    global $db;
    $email = mysqli_real_escape_string($db, $email);
    $check_email = mysqli_query($db, "SELECT id FROM style_users WHERE email = '$email'");
    if (mysqli_num_rows($check_email) > 0) {
        $errors[] = "This email is already registered";
    }

    // Validate password
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }

    // Check password complexity
    if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/", $password)) {
        $errors[] = "Password must contain at least one uppercase letter, one lowercase letter, and one number";
    }

    // Check if passwords match
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    return $errors;
}

// Add these new admin-related validation functions
function validateUserEdit($userData) {
    $errors = [];

    if (empty($userData['full_name']) || strlen($userData['full_name']) < 2) {
        $errors[] = "Full name must be at least 2 characters";
    }

    if (!empty($userData['email']) && !filter_var($userData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    if (!empty($userData['password']) && strlen($userData['password']) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }

    if (!in_array($userData['role'], ['user', 'admin', 'super_admin'])) {
        $errors[] = "Invalid role selected";
    }

    if (!in_array($userData['status'], ['active', 'inactive'])) {
        $errors[] = "Invalid status selected";
    }

    return $errors;
}

function updateUser($db, $userData) {
    $userId = (int)$userData['id'];
    $fullName = mysqli_real_escape_string($db, $userData['full_name']);
    $email = mysqli_real_escape_string($db, $userData['email']);
    $role = mysqli_real_escape_string($db, $userData['role']);
    $status = mysqli_real_escape_string($db, $userData['status']);

    try {
        $db->begin_transaction();

        $query = "UPDATE style_users SET 
                    full_name = ?, 
                    email = ?, 
                    role = ?, 
                    status = ?";
        $params = [$fullName, $email, $role, $status];
        $types = "ssss";

        // Add password to update if provided
        if (!empty($userData['password'])) {
            $password_hash = password_hash($userData['password'], PASSWORD_DEFAULT);
            $query .= ", password_hash = ?";
            $params[] = $password_hash;
            $types .= "s";
        }

        $query .= " WHERE id = ?";
        $params[] = $userId;
        $types .= "i";

        $stmt = $db->prepare($query);
        $stmt->bind_param($types, ...$params);
        
        if (!$stmt->execute()) {
            throw new Exception("Error updating user");
        }

        $db->commit();
        return true;

    } catch (Exception $e) {
        $db->rollback();
        error_log($e->getMessage());
        return false;
    }
}

function deleteUser($db, $userId) {
    try {
        $db->begin_transaction();

        // Delete user's data from related tables first
        $tables = [
            'style_user_preferences',
            'style_user_profiles',
            'style_wardrobe_items',
            'style_outfits',
            'user_cart',
            'user_wishlist'
        ];

        foreach ($tables as $table) {
            $stmt = $db->prepare("DELETE FROM $table WHERE user_id = ?");
            $stmt->bind_param('i', $userId);
            $stmt->execute();
        }

        // Finally delete the user
        $stmt = $db->prepare("DELETE FROM style_users WHERE id = ?");
        $stmt->bind_param('i', $userId);
        
        if (!$stmt->execute()) {
            throw new Exception("Error deleting user");
        }

        $db->commit();
        return true;

    } catch (Exception $e) {
        $db->rollback();
        error_log($e->getMessage());
        return false;
    }
}


function validateStep2($style_preferences) {
    $errors = [];
    if (empty($style_preferences)) {
        $errors[] = "Please select at least one style preference";
    }
    return $errors;
}

function validateStep3($terms) {
    $errors = [];
    if (!isset($terms) || $terms !== 'on') {
        $errors[] = "You must agree to the Terms & Conditions";
    }
    return $errors;
}

function registerUser($db, $userData) {
    $fullName = mysqli_real_escape_string($db, $userData['fullName']);
    $email = mysqli_real_escape_string($db, $userData['email']);
    $password_hash = password_hash($userData['password'], PASSWORD_DEFAULT);
    $style_preferences = json_encode($userData['style']);
    $notifications = isset($userData['notifications']) ? 1 : 0;
    $personalization = isset($userData['personalization']) ? 1 : 0;

    // Start transaction
    mysqli_begin_transaction($db);

    try {
        // Insert into style_users table
        $query = "INSERT INTO style_users (full_name, email, password_hash) 
                 VALUES ('$fullName', '$email', '$password_hash')";
        
        if (!mysqli_query($db, $query)) {
            throw new Exception("Error creating user account: " . mysqli_error($db));
        }

        $user_id = mysqli_insert_id($db);

        // Insert into style_user_profiles table
        $profile_query = "INSERT INTO style_user_profiles 
                         (user_id, style_preferences, notifications_enabled, personalization_enabled) 
                         VALUES ('$user_id', '$style_preferences', $notifications, $personalization)";
        
        if (!mysqli_query($db, $profile_query)) {
            throw new Exception("Error creating user profile: " . mysqli_error($db));
        }

        mysqli_commit($db);
        return true;

    } catch (Exception $e) {
        mysqli_rollback($db);
        error_log($e->getMessage());  // Log the error
        return false;
    }
}

function saveRegistrationStep($step, $data) {
    $_SESSION['registration_data'] = $_SESSION['registration_data'] ?? [];
    $_SESSION['registration_data'] = array_merge($_SESSION['registration_data'], $data);
    $_SESSION['registration_step'] = $step;
}

function getRegistrationData() {
    return $_SESSION['registration_data'] ?? [];
}

function getCurrentRegistrationStep() {
    return $_SESSION['registration_step'] ?? 1;
}


?>