<?php
// Database configuration
$servername = "localhost";  
$username = "phiwayinkhosi.lukhele";      
$password = "780316";                     
$dbname = "webtech_fall2024_phiwayinkhosi_lukhele"; 

// Create connection with error handling
$db = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($db->connect_error) {
    error_log("Database connection failed: " . $db->connect_error);
    
    // Handle errors based on request type
    if (php_sapi_name() === 'cli') {
        die("Database connection failed: " . $db->connect_error);
    } else {
        // For AJAX requests
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            die(json_encode([
                'success' => false,
                'errors' => ['Database connection failed. Please try again later.']
            ]));
        } else {
            // For regular web requests
            die("Database connection failed. Please try again later.");
        }
    }
}

// Set charset
$db->set_charset('utf8mb4');


date_default_timezone_set('UTC');

?>