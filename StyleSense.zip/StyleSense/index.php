<?php
session_start();

// Define features data
$features = [
    [
        'image' => 'https://tse3.mm.bing.net/th?id=OIP.SxeC8B-reuVT1e9vxuyJ4wHaHY&pid=Api&P=0&h=220',
        'title' => 'Body Type Analysis',
        'description' => 'Understand your unique shape and learn what styles work best for you.'
    ],
    [
        'image' => 'https://i.pinimg.com/originals/ae/ec/1a/aeec1a34c074f64f792b37d52032d193.jpg',
        'title' => 'Color Analysis',
        'description' => 'Discover your perfect color palette and make every outfit pop.'
    ],
    [
        'image' => 'https://plugins-media.makeupar.com/smb/blog/post/2023-08-02/0fac6b25-0d51-4f34-a5ed-7fd3f055ee06.jpg',
        'title' => 'Outfit Builder',
        'description' => 'Create stunning combinations for any occasion.'
    ]
];

$is_logged_in = isset($_SESSION['user_id']);
$userName = htmlspecialchars($_SESSION['full_name'] ?? 'Guest');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StyleSense - Your Personal Fashion Guide</title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
<div class="nav-links">
    <?php
    // Navigation links
    $nav_links = [
        'Home' => 'index.php',
        'About us' => 'view/aboutUs.php',  
        'Contact Us' => 'view/contactUs.php'  ];
    ?>
    </div>
    <nav class="navbar">
        <div class="logo">StyleSense</div>
        <div class="nav-links">
            <?php foreach($nav_links as $title => $link): ?>
                <a href="<?php echo $link; ?>" <?php echo basename($_SERVER['PHP_SELF']) == $link ? 'class="active"' : ''; ?>>
                    <?php echo $title; ?>
                </a>
            <?php endforeach; ?>
        </div>

        <div class="auth-buttons">
    <?php if($is_logged_in): ?>
        <div class="user-menu">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
            <form action="actions/logout.php" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
            <form action="view/services.php" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Services</button>
            </form>
        </div>
    <?php else: ?>
        <button class="login-btn" onclick="window.location.href='view/login.php'">Login</button>
        <button class="signup-btn" onclick="window.location.href='view/signup.php'">Sign Up</button>
    <?php endif; ?>
</div>
    </nav>

    <header class="hero">
        <h1>Discover Your Perfect Style</h1>
        <p>Personalized fashion guidance that celebrates your unique beauty</p>
    
    </header>



    <main>
        <section class="features">
            <h2>How StyleSense Helps You Shine</h2>
            <div class="feature-grid">
                <?php foreach($features as $feature): ?>
                    <div class="feature-card">
                        <img src="<?php echo htmlspecialchars($feature['image']); ?>" 
                             alt="<?php echo htmlspecialchars($feature['title']); ?>">
                        <h3><?php echo htmlspecialchars($feature['title']); ?></h3>
                        <p><?php echo htmlspecialchars($feature['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="testimonials">
            <h2>Style Success Stories</h2>
            <div class="testimonial-slider">
                <!-- Testimonials will be loaded dynamically via JavaScript -->
                <?php
                // You can also load testimonials from database here if preferred
                ?>
            </div>
        </section>
    </main>

    <?php if(!$is_logged_in): ?>
    <div class="auth-modal" id="authModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Welcome to StyleSense</h3>
                <button class="close-modal" onclick="closeAuthModal()">×</button>
            </div>
            <div class="modal-body">
                <div class="auth-options">
                    <?php
                    $auth_options = [
                        'email' => 'Continue with Email',
                        'google' => 'Continue with Google',
                        'facebook' => 'Continue with Facebook'
                    ];
                    
                    foreach($auth_options as $provider => $text): ?>
                        <div class="auth-option <?php echo $provider; ?>" 
                             onclick="redirectToAuth('<?php echo $provider; ?>')">
                            <?php echo $text; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h4>About StyleSense</h4>
                <p>Empowering women to feel confident and beautiful through personalized style guidance.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <a href="../view/aboutUs.php">About Us</a>
                    <a href="../view/contactUs.php">Contact</a>
                </ul>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script src="assets/js/auth_modal.js"></script>
</body>
</html>